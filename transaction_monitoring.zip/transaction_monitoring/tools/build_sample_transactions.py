"""Write the hand-crafted sample transaction files used in the README walkthrough.

Each country file uses its own column names (that is the point): the same P2
rules screen all of them through the schema layer.

    python tools/build_sample_transactions.py      # -> data/sample/*.csv
"""
from __future__ import annotations

import csv
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "data" / "sample"

IN_HEADER = ["MESSAGE_KEY", "VALUE_DATE", "AMOUNT", "CURRENCY", "BENEFICIARY_NAME", "BENEFICIARY_ACCOUNT",
             "ORIGINATOR_NAME", "BENEFICIARY_ADDRESS", "ORIGINATOR_ADDRESS", "PAYMENT_DETAILS"]
IN_ROWS = [
    ["IN0001", "2026-10-01", "250000.00", "INR", "ABC International Limited", "50100012345", "Rahul Sharma",
     "14 MG Road, Fort, Mumbai 400001", "22 FC Road, Pune", "INVOICE 4411 OFFICE SUPPLIES"],
    ["IN0002", "2026-10-01", "18000.00", "INR", "Ramesh Kumar", "50100023456", "Anita Desai",
     "Flat 4, 12 ABC Nagar, Pune 411014", "Kothrud, Pune", "RENT OCTOBER"],
    ["IN0003", "2026-10-01", "95000.00", "INR", "Jihad Ahmed Khan", "50100034567", "Priya Nair",
     "Andheri East, Mumbai", "Bandra West, Mumbai", "SALARY SEPT 2026"],
    ["IN0004", "2026-10-02", "500000.00", "INR", "Jihad Relief Foundation", "50100045678", "Imran Qureshi",
     "Mumbra, Thane", "Kurla, Mumbai", "DONATION"],
    ["IN0005", "2026-10-02", "30000.00", "INR", "Mohd Arif", "50100056789", "Sanjay Gupta",
     "Village Rahon, Shaheed Bhagat Singh Nagar, Punjab", "Ludhiana, Punjab", "FAMILY SUPPORT"],
    ["IN0006", "2026-10-02", "75000.00", "INR", "Shaheed Memorial Trust", "50100067890", "Vikram Singh",
     "Sector 17, Chandigarh", "Mohali, Punjab", "ANNUAL CONTRIBUTION"],
    ["IN0007", "2026-10-03", "40000.00", "INR", "Rohan Mehta", "50100078901", "Kiran Joshi",
     "Powai, Mumbai", "Thane West", "DONATION FOR AL-QAIDA SUPPORT"],
    ["IN0008", "2026-10-03", "65000.00", "INR", "Global Aid Services", "50100089012", "Asif Malik",
     "Kurla West, Mumbai", "Byculla, Mumbai", "ALQAIDA RELIEF CONTRIBUTION"],
    ["IN0009", "2026-10-03", "120000.00", "INR", "Lashkar-e-Toiba Welfare Society", "50100090123", "Unknown Sender",
     "Srinagar", "Delhi", "WELFARE"],
    ["IN0010", "2026-10-04", "15000.00", "INR", "Neha Kulkarni", "50100101234", "Deepak Rao",
     "Baner, Pune", "Aundh, Pune", "SUPPORT TO HIZBUL AL MUJAHIDEEN CAUSE"],
    ["IN0011", "2026-10-04", "310000.00", "INR", "ISIS Pharma Pvt Ltd", "50100112345", "Medplus Distributors",
     "MIDC Bhosari, Pune", "Hyderabad", "MEDICINE PURCHASE"],
    ["IN0012", "2026-10-04", "11000.00", "INR", "Kavita Iyer", "50100123456", "Suresh Pillai",
     "Chennai", "Kochi", "DONATION TO TEMPLE OF ISIS RESTORATION"],
    ["IN0013", "2026-10-05", "22000.00", "INR", "Arjun Patel", "50100134567", "Unknown Remitter",
     "Surat", "Ahmedabad", "ISIS FIGHTERS SUPPORT"],
    ["IN0014", "2026-10-05", "45000.00", "INR", "Sunita Reddy", "50100145678", "Ganesh Naik",
     "Goregaon East, Mumbai", "Vashi, Navi Mumbai", "SCHOOL FEES"],
    ["IN0015", "2026-10-05", "8000.00", "INR", "Amit Verma", "50100156789", "Pooja Bansal",
     "Indiranagar, Bengaluru", "Jayanagar, Bengaluru", "INVOICE 9921"],
    ["IN0001", "2026-10-06", "9000.00", "INR", "ABCD Traders", "50100167890", "Rahul Sharma",
     "Dadar, Mumbai", "Pune", "INVOICE 4412"],
    ["", "2026-10-06", "99000.00", "INR", "Al Qaida Brigade", "50100178901", "Unknown",
     "Unknown", "Unknown", "TRANSFER"],
    ["IN0017", "2026-10-06", "35000.00", "INR", "Mr Mujahid Hussain", "50100189012", "Farah Siddiqui",
     "Malad West, Mumbai", "Jogeshwari, Mumbai", "LOAN REPAYMENT"],
    ["IN0018", "2026-10-07", "88000.00", "INR", "Mujahid Trading Co", "50100190123", "Sameer Shaikh",
     "Masjid Bunder, Mumbai", "Dongri, Mumbai", "GOODS SUPPLY"],
    ["IN0019", "2026-10-07", "54000.00", "INR", "PQR Foods Pvt Ltd", "50100201234", "Harish Rao",
     "Hadapsar, Pune", "Wakad, Pune", "CATERING SERVICES"],
    ["IN0020", "2026-10-07", "760000.00", "INR", "PQR Holdings", "50100212345", "Mahesh Jain",
     "Nariman Point, Mumbai", "Worli, Mumbai", "ADVISORY FEES"],
    ["IN0021", "2026-10-08", "5000.00", "INR", "Ravi Das", "50100223456", "Shri ABC Kumar",
     "Malad East, Mumbai", "Borivali, Mumbai", "GIFT"],
    ["IN0022", "2026-10-08", "410000.00", "INR", "Patil Constructions", "50100234567", "Municipal Council Pune",
     "Hinjewadi, Pune", "Shivajinagar, Pune", "PAYMENT FOR XYZ ROAD PROJECT"],
    ["IN0023", "2026-10-08", "67000.00", "INR", "Gaurav Mittal", "50100245678", "Overseas Trade Co",
     "Kalbadevi, Mumbai", "Dubai", "XYZ CONSIGNMENT 778"],
    ["IN0024", "2026-10-09", "12500.00", "INR", "ABC", "50100256789", "Nikhil Pawar",
     "Bhandup, Mumbai", "Mulund, Mumbai", "TRANSFER"],
    ["IN0025", "2026-10-09", "16000.00", "INR", "Sunita Shaheed", "50100267890", "Arun Menon",
     "Kakkanad, Kochi", "Ernakulam", "TUITION"],
    ["IN0026", "2026-10-09", "26000.00", "INR", "Swati Joshi", "50100278901", "Unknown Donor",
     "Nashik", "Malegaon", "MARTYR WELFARE FUND CONTRIBUTION"],
    ["IN0027", "2026-10-09", "199000.00", "INR", "Société ABC Exports", "50100289012", "Vivek Iyengar",
     "Navi Mumbai", "Chennai", "EXPORT ADVANCE"],
    ["IN0028", "2026-10-09", "3000.00", "INR", "ABC Nagar Residents Association", "50100290123", "Seema Patil",
     "ABC Nagar, Pune", "Pune", "MAINTENANCE CHARGES"],
]

US_HEADER = ["MESSAGE_KEY", "BNF_NM", "BNF_ACCT", "ORG_NM", "BNF_ADDR", "ORG_ADDR", "OBI", "AMOUNT", "CURRENCY"]
US_ROWS = [
    ["US0001", "ABC International Limited", "000123", "Acme Corp", "100 Main St, New York NY", "Houston TX",
     "PO 5531", "125000.00", "USD"],
    ["US0002", "John Smith", "000124", "Mary Johnson", "12 ABC Nagar Lane, Edison NJ", "Chicago IL", "RENT",
     "2400.00", "USD"],
    ["US0003", "Jihad Relief Foundation", "000125", "Global Givers Inc", "Dearborn MI", "Detroit MI", "DONATION",
     "50000.00", "USD"],
    ["US0004", "Isis Travels LLC", "000126", "Robert Brown", "Miami FL", "Orlando FL", "AIR TICKETS", "3100.00",
     "USD"],
    ["US0005", "Sarah Wilson", "000127", "Unknown Party", "Dallas TX", "Austin TX", "FUNDS FOR AL QAIDA OPERATIONS",
     "9900.00", "USD"],
    ["US0006", "Lashkar e Tayyiba Fund", "000128", "Anonymous", "Unknown", "Unknown", "TRANSFER", "15000.00", "USD"],
    ["US0007", "Peter Green", "000129", "David Miller", "Boston MA", "Denver CO", "INVOICE 22", "780.00", "USD"],
    ["US0008", "Mr Isis Rahman", "000130", "Laura Davis", "Queens NY", "Newark NJ", "FAMILY SUPPORT", "1500.00",
     "USD"],
]

GB_HEADER = ["MESSAGE_KEY", "CREDITOR", "DEBTOR", "CREDITOR_ADDRESS", "DEBTOR_ADDRESS", "REMITTANCE_INFO", "AMOUNT",
             "CURRENCY"]
GB_ROWS = [
    ["GB0001", "ABC International Limited", "Tesco Stores Ltd", "1 High Street, London", "Leeds", "INV 8812",
     "42000.00", "GBP"],
    ["GB0002", "ISIS Beauty Salon", "Emma Taylor", "Cowley Road, Oxford", "Reading", "SERVICES", "120.00", "GBP"],
    ["GB0003", "Ali Hassan", "ABC Logistics Ltd", "Birmingham", "Manchester", "FREIGHT", "6600.00", "GBP"],
    ["GB0004", "Daniel Evans", "Laura Hughes", "Cardiff", "Bristol", "AL QAIDA DONATION", "900.00", "GBP"],
    ["GB0005", "Thomas Wright", "Olivia Clarke", "York", "Bath", "GIFT", "75.00", "GBP"],
    ["GB0006", "Hizbul Mujahideen Support Network", "Unknown", "Unknown", "Unknown", "TRANSFER", "3000.00", "GBP"],
]

AE_HEADER = ["MESSAGE_KEY", "BENE_NAME", "ORDERING_CUSTOMER", "BENE_ADDRESS_LINE_1", "BENE_ADDRESS_LINE_2",
             "BENE_CITY", "ORD_ADDRESS_LINE_1", "ORD_CITY", "PAYMENT_PURPOSE", "AMOUNT", "CURRENCY"]
AE_ROWS = [
    ["AE0001", "Sheikh Mujahid Al Mansoori", "Gulf Trading LLC", "Villa 12", "Al Barsha", "Dubai", "Deira", "Dubai",
     "GIFT", "20000.00", "AED"],
    ["AE0002", "Mujahid General Trading LLC", "Noor Holdings", "Warehouse 7", "Al Quoz", "Dubai", "Bur Dubai",
     "Dubai", "GOODS", "84000.00", "AED"],
    ["AE0003", "Fatima Noor", "Hassan Saleh", "Flat 5", "Shaheed Nagar", "Sharjah", "Al Nahda", "Sharjah",
     "FAMILY SUPPORT", "3500.00", "AED"],
    ["AE0004", "Al Amal Services", "Unknown Donor", "Office 3", "Musaffah", "Abu Dhabi", "Unknown", "Unknown",
     "MARTYR FUND FOR FIGHTERS", "60000.00", "AED"],
    ["AE0005", "ABC International Limited", "Emirates Steel", "Tower 2", "JLT", "Dubai", "Mussafah", "Abu Dhabi",
     "STEEL", "150000.00", "AED"],
    ["AE0006", "PQR Supermarket LLC", "Lulu Group", "Shop 4", "Karama", "Dubai", "Al Wahda", "Abu Dhabi",
     "SUPPLIES", "12000.00", "AED"],
    ["AE0007", "Omar Abdullah", "Khalid Rashid", "Villa 3", "Mirdif", "Dubai", "Jumeirah", "Dubai", "RENT",
     "9000.00", "AED"],
]

MIXED_HEADER = ["MESSAGE_KEY", "COUNTRY", "BENEFICIARY_NAME", "ORIGINATOR_NAME", "BENEFICIARY_ADDRESS",
                "ORIGINATOR_ADDRESS", "PAYMENT_DETAILS", "AMOUNT", "CURRENCY"]
MIXED_ROWS = [
    ["MX0001", "IN", "ABC International Limited", "Rahul Sharma", "Mumbai", "Pune", "INVOICE 1", "1000", "INR"],
    ["MX0002", "US", "John Smith", "Mary Johnson", "New York", "Chicago", "FUNDS FOR AL QAIDA", "2000", "USD"],
    ["MX0003", "GB", "ISIS Beauty Salon", "Emma Taylor", "Oxford", "Reading", "SERVICES", "120", "GBP"],
    ["MX0004", "UK", "ABC Logistics Ltd", "Ali Hassan", "London", "Leeds", "FREIGHT", "500", "GBP"],
    ["MX0005", "AE", "Jihad Relief Foundation", "Noor Holdings", "Dubai", "Sharjah", "DONATION", "5000", "AED"],
    ["MX0006", "JP", "Jihad Relief Foundation", "Tanaka Shoji", "Tokyo", "Osaka", "DONATION", "5000", "JPY"],
    ["MX0007", "NA", "ABC International Limited", "Namib Mining", "Windhoek", "Walvis Bay", "ORE", "7000", "NAD"],
    ["MX0008", "XX", "ABC International Limited", "Unknown", "Unknown", "Unknown", "TRANSFER", "100", "USD"],
    ["MX0009", "", "Al Qaida Brigade", "Unknown", "Unknown", "Unknown", "TRANSFER", "100", "USD"],
    ["MX0010", "in", "Shaheed Memorial Trust", "Vikram Singh", "Chandigarh", "Mohali", "CONTRIBUTION", "750", "INR"],
    ["MX0011", "SG", "Mujahid Trading Pte Ltd", "Tan Wei Ming", "Singapore", "Singapore", "GOODS", "3300", "SGD"],
    ["MX0012", "DE", "Mueller GmbH", "Schmidt AG", "Berlin", "Hamburg", "XYZ CONSIGNMENT", "4100", "EUR"],
]


def write(name: str, header, rows) -> Path:
    OUT.mkdir(parents=True, exist_ok=True)
    path = OUT / name
    with open(path, "w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle, lineterminator="\n")
        writer.writerow(header)
        writer.writerows(rows)
    return path


if __name__ == "__main__":
    for name, header, rows in [("transactions_IN.csv", IN_HEADER, IN_ROWS), ("transactions_US.csv", US_HEADER, US_ROWS),
                               ("transactions_GB.csv", GB_HEADER, GB_ROWS), ("transactions_AE.csv", AE_HEADER, AE_ROWS),
                               ("transactions_mixed.csv", MIXED_HEADER, MIXED_ROWS)]:
        print("wrote", write(name, header, rows), len(rows), "rows")

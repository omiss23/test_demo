"""Build the sample mapping workbook (P1, P2, Intelligence_Lists) and schema_mapping.xlsx.

    python tools/build_sample_config.py            # writes config/mapping.xlsx + config/schema_mapping.xlsx

The functions are reused by the tests to create small, purpose-built workbooks.
The schema workbook is generated from config/schemas/*.yaml so both formats
stay identical (a test asserts they resolve the same way).
"""
from __future__ import annotations

import sys
from pathlib import Path
from typing import Dict, List, Optional, Sequence

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

P1_ROWS = [
    {"RT TYPE": "Scenario 1", "COUNTRIES": "IN,US,GB"},
    {"RT TYPE": "Scenario 2", "COUNTRIES": "AE,IN,SG"},
    {"RT TYPE": "Scenario 3", "COUNTRIES": "DE,FR,IT"},
]

P2_COLUMNS = ["Rule_ID", "RT TYPE", "Keyword", "Message", "Rules", "Status", "Match_Type", "Fuzzy_Threshold"]
P2_ROWS = [
    ["S1-001", "Scenario 1", "ABC", "BENEFICIARY,ORIGINATOR,ADDRESS", "EXCL_INDV,EXCL_TOPONYM", "ACTIVE", "TOKEN", ""],
    ["S1-002", "Scenario 1", "XYZ", "DESCRIPTION", "EXCL_TOPONYM", "ACTIVE", "TOKEN", ""],
    ["S1-003", "Scenario 1", "AL QAIDA", "BENEFICIARY,ORIGINATOR,DESCRIPTION", "", "ACTIVE", "TOKEN", ""],
    ["S1-004", "Scenario 1", "LASHKAR E TAIBA", "BENEFICIARY,ORIGINATOR,DESCRIPTION", "", "ACTIVE", "FUZZY", "88"],
    ["S1-005", "Scenario 1", "ISIS", "BENEFICIARY,ORIGINATOR,DESCRIPTION", "EXCL_INDV,EXCL_SECULAR,EXCL_RELIGIOUS",
     "ACTIVE", "TOKEN", ""],
    ["S1-006", "Scenario 1", "HIZBUL MUJAHIDEEN", "BENEFICIARY,ORIGINATOR,DESCRIPTION", "", "ACTIVE", "PHRASE", ""],
    ["S1-007", "Scenario 1", "DEF", "BENEFICIARY", "EXCL_INDV", "INACTIVE", "TOKEN", ""],
    ["S2-001", "Scenario 2", "PQR", "BENEFICIARY,ADDRESS", "EXCL_SECULAR", "ACTIVE", "TOKEN", ""],
    ["S2-002", "Scenario 2", "JIHAD", "BENEFICIARY,ORIGINATOR,DESCRIPTION", "EXCL_INDV,EXCL_RELIGIOUS", "ACTIVE",
     "TOKEN", ""],
    ["S2-003", "Scenario 2", "SHAHEED", "BENEFICIARY,ORIGINATOR,ADDRESS,DESCRIPTION", "EXCL_INDV,EXCL_TOPONYM",
     "ACTIVE", "TOKEN", ""],
    ["S2-004", "Scenario 2", "MUJAHID", "BENEFICIARY,ORIGINATOR", "EXCL_INDV", "ACTIVE", "TOKEN", ""],
    ["S2-005", "Scenario 2", "MARTYR FUND", "DESCRIPTION", "", "ACTIVE", "PHRASE", ""],
    ["S3-001", "Scenario 3", "XYZ", "DESCRIPTION", "EXCL_TOPONYM", "ACTIVE", "TOKEN", ""],
    ["S3-002", "Scenario 3", "ABC", "BENEFICIARY", "EXCL_INDV", "ACTIVE", "EXACT", ""],
]

INTEL_ROWS = [
    ["Toponym", "ABC Nagar", "ACTIVE"],
    ["Toponym", "ABC Colony", "INACTIVE"],
    ["Toponym", "XYZ Road", "ACTIVE"],
    ["Toponym", "XYZ Strasse", "ACTIVE"],
    ["Toponym", "Shaheed Nagar", "ACTIVE"],
    ["Toponym", "Shaheed Bhagat Singh Nagar", "ACTIVE"],
    ["Toponym", "Shaheed Marg", "ACTIVE"],
    ["Toponym", "Shaheed Chowk", "ACTIVE"],
    ["Secular", "PQR Foods", "ACTIVE"],
    ["Secular", "PQR Supermarket", "ACTIVE"],
    ["Secular", "ISIS Pharma", "ACTIVE"],
    ["Secular", "ISIS Travels", "ACTIVE"],
    ["Secular", "ISIS Beauty Salon", "ACTIVE"],
    ["Religious", "Temple of Isis", "ACTIVE"],
    ["Religious", "Jihad al-Nafs", "ACTIVE"],
]

README_ROWS = [
    ["Sheet", "Column", "Meaning"],
    ["P1", "RT TYPE", "Scenario name. Must match the RT TYPE used in P2."],
    ["P1", "COUNTRIES", "ISO 3166-1 alpha-2 codes, comma separated (IN,US,GB). * = all countries."],
    ["P2", "Rule_ID", "Optional stable id used in every alert/audit record. Blank = P2-R<excel row>."],
    ["P2", "RT TYPE", "Scenario this keyword belongs to (eligibility comes from P1)."],
    ["P2", "Keyword", "Text to search. Case, punctuation and accents are ignored."],
    ["P2", "Message", "LOGICAL fields to search (BENEFICIARY, ORIGINATOR, ADDRESS, DESCRIPTION ...), comma "
                      "separated. Mapped to each country's real columns by the schema configuration."],
    ["P2", "Rules", "Exclusion rules, comma separated: EXCL_INDV, EXCL_TOPONYM, EXCL_SECULAR, EXCL_RELIGIOUS or "
                    "EXCL_<any Intelligence_Lists list>. The hit is excluded when ANY listed rule applies."],
    ["P2", "Status", "ACTIVE or INACTIVE (INACTIVE rows are ignored - use instead of deleting)."],
    ["P2", "Match_Type", "Optional: TOKEN (default), EXACT, PHRASE, FUZZY, SUBSTRING."],
    ["P2", "Fuzzy_Threshold", "Optional, FUZZY only: 0-100 similarity (default from settings, 90)."],
    ["Intelligence_Lists", "List", "List name: Toponym, Secular, Religious or a new list (gets EXCL_<LIST>)."],
    ["Intelligence_Lists", "Value", "Phrase that explains a keyword occurrence (e.g. ABC NAGAR)."],
    ["Intelligence_Lists", "Status", "ACTIVE or INACTIVE."],
]


def build_mapping_workbook(path: Path, p1_rows: Optional[Sequence[Dict]] = None,
                           p2_rows: Optional[Sequence[Sequence]] = None, p2_columns: Optional[List[str]] = None,
                           intel_rows: Optional[Sequence[Sequence]] = None, version: Optional[str] = "2026.10",
                           sheet_names: Optional[Dict[str, str]] = None, readme: bool = True) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    names = {"P1": "P1", "P2": "P2", "INTEL": "Intelligence_Lists"}
    names.update(sheet_names or {})
    p1 = pd.DataFrame(list(p1_rows if p1_rows is not None else P1_ROWS))
    p2 = pd.DataFrame(list(p2_rows if p2_rows is not None else P2_ROWS), columns=p2_columns or P2_COLUMNS)
    intel = pd.DataFrame(list(intel_rows if intel_rows is not None else INTEL_ROWS), columns=["List", "Value",
                                                                                               "Status"])
    with pd.ExcelWriter(path, engine="openpyxl") as writer:
        p1.to_excel(writer, sheet_name=names["P1"], index=False)
        p2.to_excel(writer, sheet_name=names["P2"], index=False)
        intel.to_excel(writer, sheet_name=names["INTEL"], index=False)
        if version:
            pd.DataFrame([["VERSION", version], ["OWNER", "Financial Crime Compliance"],
                          ["DESCRIPTION", "Sample CTF keyword screening configuration"]],
                         columns=["KEY", "VALUE"]).to_excel(writer, sheet_name="Metadata", index=False)
        if readme:
            pd.DataFrame(README_ROWS[1:], columns=README_ROWS[0]).to_excel(writer, sheet_name="README", index=False)
        _format(writer, {names["P2"]: {"Status": ["ACTIVE", "INACTIVE"],
                                       "Match_Type": ["TOKEN", "EXACT", "PHRASE", "FUZZY", "SUBSTRING"]},
                         names["INTEL"]: {"Status": ["ACTIVE", "INACTIVE"]}})
    return path


def schema_rows_from_profiles(profile_dir: Path) -> List[Dict]:
    from src.schema.schema_registry import load_schema_registry

    registry, _ = load_schema_registry(profile_dir)
    rows = []
    for profile_id in ["DEFAULT"] + sorted(p for p in registry.profiles if p != "DEFAULT"):
        profile = registry.profiles.get(profile_id)
        if profile is None:
            continue
        for logical, mapping in profile.fields.items():
            for priority, column in enumerate(mapping.candidates, start=1):
                rows.append({"COUNTRY": profile_id, "LOGICAL_FIELD": logical, "PHYSICAL_COLUMN": column,
                             "PRIORITY": priority, "RESOLUTION": mapping.resolution, "STATUS": "ACTIVE"})
    return rows


def build_schema_workbook(path: Path, rows: Sequence[Dict], version: Optional[str] = "2026.10") -> Path:
    path = Path(path)
    with pd.ExcelWriter(path, engine="openpyxl") as writer:
        pd.DataFrame(list(rows), columns=["COUNTRY", "LOGICAL_FIELD", "PHYSICAL_COLUMN", "PRIORITY", "RESOLUTION",
                                          "STATUS"]).to_excel(writer, sheet_name="Schema_Mapping", index=False)
        if version:
            pd.DataFrame([["VERSION", version]], columns=["KEY", "VALUE"]).to_excel(writer, sheet_name="Metadata",
                                                                                    index=False)
        _format(writer, {"Schema_Mapping": {"STATUS": ["ACTIVE", "INACTIVE"], "RESOLUTION": ["ALL", "FIRST"]}})
    return path


def _format(writer, validations: Dict[str, Dict[str, List[str]]]) -> None:
    from openpyxl.styles import Font, PatternFill
    from openpyxl.utils import get_column_letter
    from openpyxl.worksheet.datavalidation import DataValidation

    for sheet_name, sheet in writer.sheets.items():
        sheet.freeze_panes = "A2"
        for cell in sheet[1]:
            cell.font = Font(bold=True, color="FFFFFF")
            cell.fill = PatternFill("solid", fgColor="1F4E79")
        for idx, column in enumerate(sheet.columns, start=1):
            width = max((len(str(c.value)) for c in column if c.value is not None), default=8)
            sheet.column_dimensions[get_column_letter(idx)].width = min(max(10, width + 2), 70)
        headers = {str(c.value): c.column_letter for c in sheet[1]}
        for column, options in validations.get(sheet_name, {}).items():
            if column in headers:
                dv = DataValidation(type="list", formula1='"' + ",".join(options) + '"', allow_blank=True)
                sheet.add_data_validation(dv)
                dv.add(f"{headers[column]}2:{headers[column]}5000")


if __name__ == "__main__":
    config = ROOT / "config"
    print("wrote", build_mapping_workbook(config / "mapping.xlsx"))
    print("wrote", build_schema_workbook(config / "schema_mapping.xlsx", schema_rows_from_profiles(config / "schemas")))

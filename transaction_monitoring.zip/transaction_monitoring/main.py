#!/usr/bin/env python
"""Command-line entry point.

    python main.py --input data/sample/transactions_IN.csv \
                   --mapping config/mapping.xlsx \
                   --schema config/schema_mapping.xlsx \
                   --country IN \
                   --output data/output/

Exit codes: 0 completed (warnings allowed) | 2 completed with errors (see errors.csv /
validation reports) | 3 stopped by a FAIL_FILE policy | 1 fatal error.
"""
from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src import __version__  # noqa: E402
from src.exceptions import MonitoringError  # noqa: E402
from src.monitoring_engine import MonitoringEngine  # noqa: E402
from src.settings import Settings  # noqa: E402

DEFAULT_SETTINGS = ROOT / "config" / "settings.yaml"


def parse_args(argv=None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Configuration-driven transaction monitoring (P1/P2/Intelligence_Lists)")
    p.add_argument("--input", required=True, help="transaction CSV file")
    p.add_argument("--mapping", default=str(ROOT / "config" / "mapping.xlsx"), help="mapping workbook (P1, P2, "
                                                                                   "Intelligence_Lists)")
    p.add_argument("--schema", default=str(ROOT / "config" / "schema_mapping.xlsx"),
                   help="schema mapping: .xlsx/.csv table, a .yaml/.json file, or a directory of profiles")
    p.add_argument("--output", default=str(ROOT / "data" / "output"), help="output directory")
    p.add_argument("--country", help="ISO country of the file (overrides detection when 'cli' is first in "
                                     "country_resolution.order)")
    p.add_argument("--settings", default=str(DEFAULT_SETTINGS) if DEFAULT_SETTINGS.exists() else None,
                   help="settings.yaml (default: config/settings.yaml)")
    p.add_argument("--chunk-size", type=int, help="rows per chunk, e.g. 50000, 100000, 250000, 500000")
    p.add_argument("--duplicate-policy", choices=["WARN_AND_PROCESS", "REJECT_DUPLICATES", "FAIL_FILE"])
    p.add_argument("--backend", choices=["auto", "aho_corasick", "pure_python"], help="candidate generation backend")
    p.add_argument("--reader", choices=["auto", "pyarrow", "pandas"], help="CSV reader backend")
    p.add_argument("--no-run-subdir", action="store_true", help="write directly into --output (overwrites)")
    p.add_argument("--ledger", action="store_true", help="also write screened_transactions.csv (one row per input)")
    p.add_argument("--validate-only", action="store_true",
                   help="validate configuration, schema and data quality and build the search plan; no screening")
    p.add_argument("--log-level", default="INFO", choices=["DEBUG", "INFO", "WARNING", "ERROR"])
    p.add_argument("--log-file", help="optional log file")
    p.add_argument("--version", action="version", version=f"tm-framework {__version__}")
    return p.parse_args(argv)


def main(argv=None) -> int:
    args = parse_args(argv)
    handlers = [logging.StreamHandler(sys.stdout)]
    if args.log_file:
        handlers.append(logging.FileHandler(args.log_file, encoding="utf-8"))
    logging.basicConfig(level=getattr(logging, args.log_level), handlers=handlers,
                        format="%(asctime)s %(levelname)-7s %(message)s", datefmt="%H:%M:%S")
    log = logging.getLogger("tm")
    try:
        settings = Settings.load(Path(args.settings) if args.settings else None, base_dir=ROOT / "config")
        if args.duplicate_policy:
            settings.data_quality.duplicate_message_key_policy = args.duplicate_policy
        if args.backend:
            settings.matching.candidate_backend = args.backend
        if args.reader:
            settings.input.reader_backend = args.reader
        if args.no_run_subdir:
            settings.output.run_subdirectory = False
        if args.ledger:
            settings.output.write_screening_ledger = True
        for issue in settings.issues:
            log.warning("settings: %s - %s", issue.code, issue.detail)
        engine = MonitoringEngine(Path(args.mapping), Path(args.schema), settings=settings)
        result = engine.run(Path(args.input), Path(args.output), country=args.country, chunk_size=args.chunk_size,
                            validate_only=args.validate_only)
    except MonitoringError as exc:
        log.error("%s", exc)
        return 1
    s = result.summary
    p = s.get("processing", {})
    perf = s.get("performance", {})
    print()
    print(f"Status        : {result.status} (exit code {result.exit_code})")
    if result.error:
        print(f"Reason        : {result.error}")
    print(f"Output        : {result.output_dir}")
    if p:
        print(f"Rows          : {p.get('rows_read', 0):,} read | {p.get('rows_screened', 0):,} screened | "
              f"{p.get('rows_not_eligible', 0):,} not eligible (P1)")
        print(f"Decisions     : {p.get('alerts', 0):,} alerts | {p.get('exclusions', 0):,} exclusions | "
              f"{p.get('alerted_transactions', 0):,} alerted transactions | {p.get('errors', 0):,} errors")
        print(f"Performance   : {perf.get('rows_per_second')} rows/s | peak memory {perf.get('peak_memory_mb')} MB")
    return result.exit_code


if __name__ == "__main__":
    sys.exit(main())

"""Compare candidate technologies for the two expensive stages (spec section 36).

  1. CSV ingestion of a large file in bounded-memory batches
       pandas C parser (chunksize) | pyarrow.csv streaming reader | polars batched reader | DuckDB
  2. Candidate generation for ~10,000 keywords over the distinct values of one column
       pyahocorasick batch scan | pure-Python token index | polars str.extract_many (Rust Aho-Corasick)
       | Python `re` alternation (shown to justify NOT using regex for large keyword lists)

    python benchmarks/backend_comparison.py --input benchmarks/work/bench_1000000_IN.csv

Each measurement is wall-clock on the same machine; results are written to
benchmarks/results/backend_comparison.csv and printed as a table.
"""
from __future__ import annotations

import argparse
import csv
import json
import re
import sys
import time
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.matching.candidate_generator import (KIND_TOKEN, AhoCorasickGenerator, Probe,  # noqa: E402
                                              TokenIndexGenerator, ValueBatch)
from src.normalization.text_normalizer import TextNormalizer  # noqa: E402

COLUMNS = ["MESSAGE_KEY", "BENEFICIARY_NAME", "ORIGINATOR_NAME", "BENEFICIARY_ADDRESS", "ORIGINATOR_ADDRESS",
           "PAYMENT_DETAILS"]


def timed(fn):
    t = time.perf_counter()
    result = fn()
    return time.perf_counter() - t, result


def read_pandas(path: Path, chunk: int):
    rows = 0
    for frame in pd.read_csv(path, dtype=str, na_filter=False, usecols=COLUMNS, chunksize=chunk):
        rows += len(frame)
    return rows


def read_pyarrow(path: Path, chunk: int):
    import pyarrow as pa
    import pyarrow.csv as pacsv

    convert = pacsv.ConvertOptions(include_columns=COLUMNS, column_types={c: pa.string() for c in COLUMNS},
                                   strings_can_be_null=False, quoted_strings_can_be_null=False)
    reader = pacsv.open_csv(path, read_options=pacsv.ReadOptions(block_size=16 << 20), convert_options=convert)
    rows = 0
    for batch in reader:
        rows += len(batch.to_pandas())
    return rows


def read_polars(path: Path, chunk: int):
    import polars as pl

    rows = 0
    lazy = pl.scan_csv(path, infer_schema=False).select(COLUMNS)
    if hasattr(lazy, "collect_batches"):          # polars >= 1.3x / 2.x (streaming, marked unstable)
        for frame in lazy.collect_batches(chunk_size=chunk):
            rows += len(frame.to_pandas())
    else:                                         # older polars
        reader = pl.read_csv_batched(path, columns=COLUMNS, infer_schema=False, batch_size=chunk)
        while True:
            batches = reader.next_batches(1)
            if not batches:
                break
            rows += len(batches[0].to_pandas())
    return rows


def read_duckdb(path: Path, chunk: int):
    import duckdb

    con = duckdb.connect()
    cols = ", ".join(COLUMNS)
    rel = con.execute(f"SELECT {cols} FROM read_csv('{path}', all_varchar=true)")
    rows = 0
    while True:
        frame = rel.fetch_df_chunk(max(1, chunk // 2048))
        if frame is None or frame.empty:
            break
        rows += len(frame)
    return rows


def candidate_benchmarks(values, keywords):
    normalizer = TextNormalizer()
    norm = normalizer.normalize_many(values)
    probes = [Probe(normalizer.normalize(k), KIND_TOKEN, i, 0) for i, k in enumerate(keywords)]
    results = []

    t, ac = timed(lambda: AhoCorasickGenerator(probes))
    t_scan, hits = timed(lambda: ac.scan_batch(ValueBatch(norm)))
    results.append(("candidate_generation", "pyahocorasick (batch, chosen)", t_scan, len(hits), f"build {t:.2f}s"))

    t, ti = timed(lambda: TokenIndexGenerator(probes))
    t_scan, hits_py = timed(lambda: ti.scan_batch(ValueBatch(norm)))
    results.append(("candidate_generation", "pure-Python token index (fallback)", t_scan, len(hits_py),
                    f"build {t:.2f}s"))

    try:
        import polars as pl

        patterns = [f" {p.text} " for p in probes]
        series = pl.Series([f" {v} " for v in norm])
        t_scan, found = timed(lambda: series.str.extract_many(patterns, overlapping=True))
        count = int(found.list.len().sum())
        results.append(("candidate_generation", "polars str.extract_many (Rust AC)", t_scan, count,
                        "returns matched strings only, positions recomputed separately"))
    except Exception as exc:  # pragma: no cover
        results.append(("candidate_generation", "polars str.extract_many", float("nan"), 0, f"unavailable: {exc}"))

    sample = norm[:5000]
    rx = re.compile(r"(?<![^ ])(?:" + "|".join(re.escape(p.text) for p in
                                              sorted(probes, key=lambda p: -len(p.text))) + r")(?![^ ])")
    t_scan, found = timed(lambda: sum(1 for v in sample for _ in rx.finditer(v)))
    results.append(("candidate_generation", "Python re alternation (5,000-value sample)", t_scan, found,
                    f"extrapolated to all values: {t_scan * len(norm) / len(sample):.1f}s"))
    return results


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", default=str(ROOT / "benchmarks" / "work" / "bench_1000000_IN.csv"))
    parser.add_argument("--chunk", type=int, default=100_000)
    args = parser.parse_args()
    path = Path(args.input)
    out_rows = []
    for name, fn in [("pandas C parser, chunksize (fallback)", read_pandas),
                     ("pyarrow.csv streaming reader -> pandas (chosen when installed)", read_pyarrow),
                     ("polars streaming batches -> pandas", read_polars),
                     ("duckdb read_csv -> pandas chunks", read_duckdb)]:
        try:
            seconds, rows = timed(lambda: fn(path, args.chunk))
            out_rows.append(("csv_ingestion", name, seconds, rows, f"{rows / seconds:,.0f} rows/s"))
        except Exception as exc:
            out_rows.append(("csv_ingestion", name, float("nan"), 0, f"failed: {exc}"))
        print(out_rows[-1])
    frame = pd.read_csv(path, dtype=str, na_filter=False, usecols=["BENEFICIARY_ADDRESS"], nrows=args.chunk)
    values = pd.unique(frame["BENEFICIARY_ADDRESS"]).tolist()
    kw = json.load(open(ROOT / "benchmarks" / "work" / "benchmark_keywords.json"))["keywords"]
    # make sure some keywords occur
    values = values + [f"12 {k} NAGAR PUNE" for k in kw[:200]]
    for row in candidate_benchmarks(values, kw):
        out_rows.append(row)
        print(row)
    results = ROOT / "benchmarks" / "results"
    results.mkdir(parents=True, exist_ok=True)
    with open(results / "backend_comparison.csv", "w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["stage", "technology", "seconds", "count", "note"])
        for stage, name, seconds, count, note in out_rows:
            writer.writerow([stage, name, f"{seconds:.3f}", count, note])
    print(f"\nwritten {results / 'backend_comparison.csv'} ({len(values):,} distinct values, {len(kw):,} keywords)")


if __name__ == "__main__":
    main()

"""Synthetic benchmark data: a 10,000-row P2 mapping and transaction files of any size.

    python benchmarks/synthetic.py config  --out benchmarks/work --keywords 10000
    python benchmarks/synthetic.py data    --out benchmarks/work --rows 5000000

Keywords are generated from syllables so they do not collide with the person /
company / address vocabulary - the hit rate is therefore controlled by
injection (default 0.5% of rows), which mirrors production where real keyword
hits are rare. Counterparty names repeat (as in real payment data) while
addresses and payment references are mostly unique, so the benchmark exercises
both the value cache and the full matching path.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path
from typing import List

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from tools.build_sample_config import build_mapping_workbook  # noqa: E402

SYLLABLES = ["za", "ro", "qu", "vim", "tel", "mar", "ix", "ko", "lu", "ne", "dra", "shi", "pol", "tak", "ven", "yur",
             "bex", "ga", "fen", "dor", "lin", "sar", "qa", "mo", "zu", "kri", "tor", "wen", "ul", "ash", "pre", "vok",
             "jin", "hel", "tro", "nax", "pi", "sel", "gor", "fa"]
GIVEN = ["RAHUL", "AMIT", "PRIYA", "NEHA", "SUNIL", "ANITA", "RAJESH", "KAVITA", "VIKRAM", "POOJA", "ARJUN", "SNEHA",
         "IMRAN", "FARAH", "ASIF", "AYESHA", "JOHN", "MARY", "DAVID", "SARAH", "MOHAMMED", "FATIMA", "OMAR", "LAYLA",
         "SURESH", "DEEPA", "KIRAN", "MANOJ", "SEEMA", "VIJAY", "ROHAN", "ANJALI", "KARAN", "NISHA", "GAURAV", "SWATI",
         "HARISH", "MEENA", "PETER", "EMMA", "CARLOS", "MARIA", "HANS", "ANNA", "YUSUF", "SANA", "TARIQ", "HIBA"]
SURNAMES = ["SHARMA", "VERMA", "PATEL", "SHAH", "MEHTA", "JOSHI", "SINGH", "KUMAR", "REDDY", "RAO", "NAIR", "IYER",
            "KHAN", "SHAIKH", "QURESHI", "ANSARI", "SMITH", "BROWN", "TAYLOR", "WILSON", "GUPTA", "JAIN", "DAS",
            "GHOSH", "PATIL", "PAWAR", "JADHAV", "DESAI", "KULKARNI", "MALIK", "SIDDIQUI", "RAHMAN", "GARCIA",
            "MULLER", "ROSSI", "MARTIN", "MENON", "PILLAI", "BOSE", "ROY"]
COMPANY_WORDS = ["SUNRISE", "GLOBAL", "ORIENT", "APEX", "PRIME", "METRO", "CITY", "STAR", "UNITED", "PIONEER", "ROYAL",
                 "GREEN", "BLUE", "SILVER", "GOLDEN", "OCEAN", "DELTA", "OMEGA", "ALPHA", "NOVA", "VERTEX", "ZENITH",
                 "SUMMIT", "HORIZON", "CRESCENT", "EAGLE", "FALCON", "LOTUS", "TULIP", "CEDAR", "MAPLE", "RIVER",
                 "VALLEY", "HIGHLAND", "COASTAL", "EASTERN", "WESTERN", "NORTHERN", "SOUTHERN", "CENTRAL", "UNIVERSAL",
                 "DYNAMIC", "SMART", "BRIGHT", "TRUST", "CROWN", "EMPIRE", "LEGACY", "VISION", "FUTURE"]
COMPANY_SUFFIX = ["LTD", "PVT LTD", "LLC", "INC", "TRADING CO", "ENTERPRISES", "INDUSTRIES", "SERVICES", "EXPORTS",
                  "HOLDINGS", "TECHNOLOGIES", "LOGISTICS", "FOODS", "TEXTILES", "PHARMA"]
STREETS = ["MG ROAD", "LINK ROAD", "STATION ROAD", "MAIN STREET", "HIGH STREET", "PARK AVENUE", "LAKE ROAD", "FC ROAD",
           "SV ROAD", "LBS MARG", "RING ROAD", "CANAL ROAD", "TEMPLE STREET", "MARKET YARD", "INDUSTRIAL AREA",
           "SECTOR 17", "PHASE 2", "BLOCK B", "NEHRU NAGAR", "GANDHI NAGAR"]
CITIES = ["MUMBAI", "PUNE", "DELHI", "BENGALURU", "CHENNAI", "KOLKATA", "HYDERABAD", "AHMEDABAD", "SURAT", "JAIPUR",
          "LUCKNOW", "NAGPUR", "INDORE", "BHOPAL", "PATNA", "SOLAPUR", "NASHIK", "THANE", "KOCHI", "MYSURU"]
PURPOSES = ["INVOICE", "SALARY", "RENT", "SCHOOL FEES", "TRANSFER", "GOODS SUPPLY", "ADVANCE", "LOAN REPAYMENT",
            "CONSULTANCY FEES", "FAMILY SUPPORT", "MEDICAL BILL", "INSURANCE PREMIUM", "MAINTENANCE", "EMI",
            "COMMISSION", "REFUND"]
IN_COLUMNS = ["MESSAGE_KEY", "VALUE_DATE", "AMOUNT", "CURRENCY", "BENEFICIARY_NAME", "BENEFICIARY_ACCOUNT",
              "ORIGINATOR_NAME", "BENEFICIARY_ADDRESS", "ORIGINATOR_ADDRESS", "PAYMENT_DETAILS"]


def make_keywords(n: int, rng: np.random.Generator) -> List[str]:
    vocabulary = set(GIVEN + SURNAMES + COMPANY_WORDS + CITIES + [w for s in STREETS + PURPOSES + COMPANY_SUFFIX
                                                                  for w in s.split()])
    words = set()
    while len(words) < n:
        word = "".join(rng.choice(SYLLABLES, size=int(rng.integers(2, 5))))
        if len(word) >= 5 and word.upper() not in vocabulary:
            words.add(word.upper())
    words = sorted(words)
    rng.shuffle(words)
    out = []
    for i, w in enumerate(words):
        if rng.random() < 0.15 and i + 1 < len(words):
            out.append(f"{w} {words[(i * 7 + 3) % len(words)]}")     # multi-token keyword
        else:
            out.append(w)
    return list(dict.fromkeys(out))[:n]


def build_config(out_dir: Path, n_rules: int = 10_000, seed: int = 7) -> Path:
    rng = np.random.default_rng(seed)
    out_dir.mkdir(parents=True, exist_ok=True)
    keywords = make_keywords(int(n_rules * 0.95), rng)
    fields = ["BENEFICIARY", "ORIGINATOR", "ADDRESS", "DESCRIPTION"]
    excl = ["EXCL_INDV", "EXCL_TOPONYM", "EXCL_SECULAR", "EXCL_RELIGIOUS"]
    p2 = []
    for i in range(n_rules):
        kw = keywords[i % len(keywords)]
        scenario = "Scenario 1" if i % 3 == 0 else ("Scenario 2" if i % 3 == 1 else "Scenario 3")
        k = int(rng.integers(1, 5))
        msg = ",".join(sorted(rng.choice(fields, size=k, replace=False), key=fields.index))
        rules = ",".join(sorted(rng.choice(excl, size=int(rng.integers(0, 3)), replace=False), key=excl.index))
        r = rng.random()
        mtype = "TOKEN" if r < 0.92 else ("PHRASE" if r < 0.95 else ("EXACT" if r < 0.99 else "FUZZY"))
        if mtype == "PHRASE" and " " not in kw:
            mtype = "TOKEN"
        threshold = "88" if mtype == "FUZZY" else ""
        status = "ACTIVE" if rng.random() < 0.97 else "INACTIVE"
        p2.append([f"B-{i + 1:05d}", scenario, kw, msg, rules, status, mtype, threshold])
    intel = []
    for kw in keywords[: int(len(keywords) * 0.3)]:
        intel.append(["Toponym", f"{kw} NAGAR", "ACTIVE"])
    for kw in keywords[int(len(keywords) * 0.3): int(len(keywords) * 0.4)]:
        intel.append(["Secular", f"{kw} PHARMA", "ACTIVE"])
    for kw in keywords[int(len(keywords) * 0.4): int(len(keywords) * 0.45)]:
        intel.append(["Religious", f"TEMPLE OF {kw}", "ACTIVE"])
    p1 = [{"RT TYPE": "Scenario 1", "COUNTRIES": "IN,US,GB"}, {"RT TYPE": "Scenario 2", "COUNTRIES": "AE,IN,SG"},
          {"RT TYPE": "Scenario 3", "COUNTRIES": "DE,FR,IT"}]
    path = build_mapping_workbook(out_dir / "benchmark_mapping.xlsx", p1, p2, None, intel, version="bench-1",
                                  readme=False)
    fuzzy = [row[2] for row in p2 if row[6] == "FUZZY" and row[5] == "ACTIVE"]
    with open(out_dir / "benchmark_keywords.json", "w") as handle:
        json.dump({"keywords": keywords, "fuzzy": fuzzy}, handle)
    return path


def _typo(word: str, rng: np.random.Generator) -> str:
    if len(word) < 5:
        return word
    i = int(rng.integers(1, len(word) - 1))
    return word[:i] + ("A" if word[i] != "A" else "E") + word[i + 1:]


def generate(path: Path, rows: int, keywords: List[str], fuzzy: List[str], seed: int = 11, hit_rate: float = 0.005,
             dup_rate: float = 0.0001, null_rate: float = 0.00005, chunk: int = 500_000) -> Path:
    rng = np.random.default_rng(seed)
    path.parent.mkdir(parents=True, exist_ok=True)
    started = time.perf_counter()
    with open(path, "w", encoding="utf-8", newline="") as handle:
        handle.write(",".join(IN_COLUMNS) + "\n")
        for offset in range(0, rows, chunk):
            n = min(chunk, rows - offset)
            person = rng.random(n) < 0.6
            persons = pd.Series(rng.choice(GIVEN, n)) + " " + pd.Series(rng.choice(SURNAMES, n))
            companies = (pd.Series(rng.choice(COMPANY_WORDS, n)) + " " + pd.Series(rng.choice(COMPANY_WORDS, n)) +
                         " " + pd.Series(rng.choice(COMPANY_SUFFIX, n)))
            bene = persons.where(person, companies)
            orig = (pd.Series(rng.choice(GIVEN, n)) + " " + pd.Series(rng.choice(SURNAMES, n))).where(
                rng.random(n) < 0.7, pd.Series(rng.choice(COMPANY_WORDS, n)) + " " +
                pd.Series(rng.choice(COMPANY_SUFFIX, n)))

            def address():
                return (pd.Series(rng.integers(1, 999, n).astype(str)) + " " + pd.Series(rng.choice(STREETS, n)) +
                        ", " + pd.Series(rng.choice(CITIES, n)) + " " +
                        pd.Series(rng.integers(400001, 499999, n).astype(str)))

            frame = pd.DataFrame({
                "MESSAGE_KEY": [f"MSG{offset + i:010d}" for i in range(n)],
                "VALUE_DATE": "2026-10-01",
                "AMOUNT": pd.Series(np.round(rng.lognormal(9, 1.2, n), 2).astype(str)),
                "CURRENCY": "INR",
                "BENEFICIARY_NAME": bene,
                "BENEFICIARY_ACCOUNT": pd.Series(rng.integers(10 ** 10, 10 ** 11, n).astype(str)),
                "ORIGINATOR_NAME": orig,
                "BENEFICIARY_ADDRESS": address(),
                "ORIGINATOR_ADDRESS": address(),
                "PAYMENT_DETAILS": pd.Series(rng.choice(PURPOSES, n)) + " " +
                pd.Series(rng.integers(1000, 999999, n).astype(str)),
            })
            frame = frame.astype(object)
            hits = np.flatnonzero(rng.random(n) < hit_rate)
            for i in hits.tolist():
                kw = keywords[int(rng.integers(0, len(keywords)))]
                kind = rng.random()
                if kind < 0.35:
                    frame.at[i, "BENEFICIARY_NAME"] = f"{kw} {rng.choice(COMPANY_SUFFIX)}"
                elif kind < 0.50:
                    frame.at[i, "BENEFICIARY_NAME"] = f"MR {kw} {rng.choice(SURNAMES)}"
                elif kind < 0.75:
                    frame.at[i, "PAYMENT_DETAILS"] = f"DONATION FOR {kw} {int(rng.integers(100, 999))}"
                elif kind < 0.90:
                    frame.at[i, "BENEFICIARY_ADDRESS"] = f"{int(rng.integers(1, 99))} {kw} NAGAR, {rng.choice(CITIES)}"
                elif fuzzy:
                    f = fuzzy[int(rng.integers(0, len(fuzzy)))]
                    frame.at[i, "ORIGINATOR_NAME"] = f"{_typo(f, rng)} WELFARE"
            dups = np.flatnonzero(rng.random(n) < dup_rate)
            for i in dups.tolist():
                frame.at[i, "MESSAGE_KEY"] = f"MSG{max(0, offset + i - 1):010d}"
            nulls = np.flatnonzero(rng.random(n) < null_rate)
            for i in nulls.tolist():
                frame.at[i, "MESSAGE_KEY"] = ""
            frame.to_csv(handle, header=False, index=False, lineterminator="\n")
    print(f"generated {rows:,} rows -> {path} ({path.stat().st_size / 1e6:.0f} MB) in "
          f"{time.perf_counter() - started:.1f}s")
    return path


def main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="cmd", required=True)
    c = sub.add_parser("config")
    c.add_argument("--out", default=str(ROOT / "benchmarks" / "work"))
    c.add_argument("--keywords", type=int, default=10_000)
    d = sub.add_parser("data")
    d.add_argument("--out", default=str(ROOT / "benchmarks" / "work"))
    d.add_argument("--rows", type=int, required=True)
    d.add_argument("--hit-rate", type=float, default=0.005)
    args = parser.parse_args()
    out = Path(args.out)
    if args.cmd == "config":
        print("wrote", build_config(out, args.keywords))
    else:
        kw = json.load(open(out / "benchmark_keywords.json"))
        generate(out / f"bench_{args.rows}_IN.csv", args.rows, kw["keywords"], kw["fuzzy"], hit_rate=args.hit_rate)


if __name__ == "__main__":
    main()

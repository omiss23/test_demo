"""Performance benchmark (spec section 35).

    python benchmarks/run_benchmark.py                       # 100K, 500K, 1M, 5M rows
    python benchmarks/run_benchmark.py --sizes 1000000 --chunk-sizes 50000 100000 250000 500000
    python benchmarks/run_benchmark.py --sizes 1000000 --variants default pure_python pandas_reader

Every run is a separate `python main.py` process, so peak memory is the true
high-water mark of that run alone. Results: benchmarks/results/benchmark_results.csv
"""
from __future__ import annotations

import argparse
import csv
import json
import platform
import re
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / "benchmarks" / "work"
RESULTS = ROOT / "benchmarks" / "results"
sys.path.insert(0, str(ROOT))

VARIANTS = {
    "default": [],                                              # pyarrow reader + pyahocorasick (auto)
    "pure_python": ["--backend", "pure_python"],                # no pyahocorasick
    "pandas_reader": ["--reader", "pandas"],                    # no pyarrow
    "minimal_deps": ["--backend", "pure_python", "--reader", "pandas"],
}

FIELDS = ["variant", "rows", "chunk_size", "status", "total_seconds", "streaming_seconds", "prepass_seconds",
          "config_load_seconds", "rows_per_second", "end_to_end_rows_per_second", "peak_memory_mb",
          "active_rules", "keyword_specs", "distinct_keywords", "fuzzy_specs", "candidate_matches", "verified_hits",
          "decisions", "alerts", "exclusions", "alerted_transactions", "errors", "reader", "candidate_backend"]


def ensure_inputs(sizes):
    from benchmarks.synthetic import build_config, generate

    if not (WORK / "benchmark_mapping.xlsx").exists():
        build_config(WORK)
    keywords = json.load(open(WORK / "benchmark_keywords.json"))
    for rows in sizes:
        path = WORK / f"bench_{rows}_IN.csv"
        if not path.exists():
            generate(path, rows, keywords["keywords"], keywords["fuzzy"])


def run_one(rows: int, chunk: int, variant: str) -> dict:
    out = WORK / "runs"
    cmd = [sys.executable, str(ROOT / "main.py"), "--input", str(WORK / f"bench_{rows}_IN.csv"),
           "--mapping", str(WORK / "benchmark_mapping.xlsx"), "--schema", str(ROOT / "config" / "schemas"),
           "--country", "IN", "--output", str(out), "--chunk-size", str(chunk), "--log-level", "WARNING"]
    cmd += VARIANTS[variant]
    started = time.perf_counter()
    proc = subprocess.run(cmd, capture_output=True, text=True)
    wall = time.perf_counter() - started
    match = re.search(r"Output\s+:\s+(.+)", proc.stdout)
    if not match:
        raise RuntimeError(f"run failed:\n{proc.stdout}\n{proc.stderr}")
    summary = json.load(open(Path(match.group(1).strip()) / "run_summary.json"))
    perf, proc_stats, cfg = summary["performance"], summary["processing"], summary["configuration"]
    stages = perf["stage_seconds"]
    return {
        "variant": variant, "rows": proc_stats["rows_read"], "chunk_size": chunk, "status": summary["status"],
        "total_seconds": round(wall, 2), "streaming_seconds": stages.get("streaming_pass"),
        "prepass_seconds": stages.get("prepass"), "config_load_seconds": stages.get("configuration_load"),
        "rows_per_second": perf.get("rows_per_second"),
        "end_to_end_rows_per_second": round(proc_stats["rows_read"] / wall, 1),
        "peak_memory_mb": perf.get("peak_memory_mb"), "active_rules": cfg["p2_active_rules"],
        "keyword_specs": cfg["keyword_specs"], "distinct_keywords": cfg["distinct_keywords"],
        "fuzzy_specs": cfg["keyword_specs_by_match_type"].get("FUZZY", 0),
        "candidate_matches": proc_stats["stage2_candidates"], "verified_hits": proc_stats["verified_hits"],
        "decisions": proc_stats["decisions"], "alerts": proc_stats["alerts"], "exclusions": proc_stats["exclusions"],
        "alerted_transactions": proc_stats["alerted_transactions"], "errors": proc_stats["errors"],
        "reader": summary["input"].get("reader_backend", ""), "candidate_backend": perf.get("candidate_backend"),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--sizes", type=int, nargs="+", default=[100_000, 500_000, 1_000_000, 5_000_000])
    parser.add_argument("--chunk-sizes", type=int, nargs="+", default=[100_000])
    parser.add_argument("--variants", nargs="+", default=["default"], choices=list(VARIANTS))
    parser.add_argument("--output", default=str(RESULTS / "benchmark_results.csv"))
    args = parser.parse_args()
    ensure_inputs(args.sizes)
    RESULTS.mkdir(parents=True, exist_ok=True)
    rows = []
    for variant in args.variants:
        for size in args.sizes:
            for chunk in args.chunk_sizes:
                result = run_one(size, chunk, variant)
                rows.append(result)
                print(f"{variant:14s} rows={result['rows']:>9,} chunk={chunk:>7,} total={result['total_seconds']:>7.1f}s "
                      f"stream={result['streaming_seconds']:>6.1f}s rows/s={result['rows_per_second']:>10,.0f} "
                      f"peak={result['peak_memory_mb']:>6.0f}MB alerts={result['alerts']:,} "
                      f"excl={result['exclusions']:,} errors={result['errors']:,}", flush=True)
    output = Path(args.output)
    with open(output, "w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(rows)
    machine = {"python": platform.python_version(), "platform": platform.platform(),
               "cpu_count": __import__("os").cpu_count()}
    with open(output.with_suffix(".machine.json"), "w") as handle:
        json.dump(machine, handle, indent=2)
    print("written", output)


if __name__ == "__main__":
    main()

# Transaction Monitoring Framework

Configuration-driven, multi-country keyword screening for payment transactions —
built for files of 5 million+ rows on an ordinary workstation.

* **Schema-flexible** – P2 rules name *logical* fields (BENEFICIARY, ADDRESS…); a schema layer maps them to each
  country's real columns (`BENEFICIARY_NAME`, `BNF_NM`, `CREDITOR`…). No column name is hard-coded.
* **Scalable** – streaming chunks, one Aho-Corasick automaton per column, C-level batch processing:
  **5,000,000 rows × 9,704 active rules in 45 s end to end, 0.7 GB peak RAM** (2 CPU cores, see
  `docs/BENCHMARK.md`).
* **Explainable and auditable** – every match carries MESSAGE_KEY, the P2 rule, logical and physical column,
  match type/score, every exclusion rule evaluated with confidence + reason + source, the final decision, and the
  mapping/schema/settings versions (file hashes).
* **Safe by default** – nothing is skipped silently: unresolved columns, blank or duplicate keys, malformed
  records, unknown rule codes and classifier errors are all reported; an exclusion that cannot be evaluated never
  suppresses an alert.

> Design document (requirements analysis, assumptions, architecture, data flow, matching and exclusion logic,
> limitations): **[docs/ARCHITECTURE.md](docs/ARCHITECTURE.md)** · Performance results: **[docs/BENCHMARK.md](docs/BENCHMARK.md)**

---

## 1. Quick start

```bash
pip install -r requirements.txt          # pandas, numpy, openpyxl, pyyaml (+ optional accelerators)

# India file - country taken from the command line
python main.py --input data/sample/transactions_IN.csv \
               --mapping config/mapping.xlsx \
               --schema config/schema_mapping.xlsx \
               --country IN \
               --output data/output/

# Mixed-country file - country read from its COUNTRY column, schema from YAML profiles
python main.py --input data/sample/transactions_mixed.csv \
               --mapping config/mapping.xlsx \
               --schema config/schemas/ \
               --output data/output/
```

Console summary:

```
Status        : COMPLETED_WITH_ERRORS (exit code 2)
Output        : data/output/run_20261009_013506_transactions_IN_14e839ec
Rows          : 29 read | 28 screened | 0 not eligible (P1)
Decisions     : 14 alerts | 12 exclusions | 14 alerted transactions | 1 errors
```

(The sample deliberately contains a blank MESSAGE_KEY, so the run reports one error.)

### CLI options

| Option | Purpose |
|---|---|
| `--input` | transaction CSV (required) |
| `--mapping` | mapping workbook with P1, P2, Intelligence_Lists (default `config/mapping.xlsx`) |
| `--schema` | schema configuration: `.xlsx`/`.csv` table, `.yaml`/`.json` file, a folder of profiles, or `.db` (SQLite) |
| `--country` | file country (used first when `cli` leads `country_resolution.order`) |
| `--output` | output folder; each run writes into its own `run_<timestamp>_<file>_<id>/` sub-folder |
| `--settings` | engine settings (default `config/settings.yaml`) |
| `--chunk-size` | rows per chunk – 50 000 / 100 000 / 250 000 / 500 000 … |
| `--duplicate-policy` | `WARN_AND_PROCESS` (default) · `REJECT_DUPLICATES` · `FAIL_FILE` |
| `--backend` / `--reader` | force `pure_python` matching / `pandas` CSV reader (fallbacks for minimal environments) |
| `--validate-only` | validate config, schema and data quality and write the search plan, without screening |
| `--ledger` | also write `screened_transactions.csv` (one row per input transaction – proof of coverage) |
| `--no-run-subdir` | write directly into `--output` |
| `--log-level`, `--log-file` | logging |

**Exit codes:** `0` completed (warnings allowed) · `2` completed with errors (see `errors.csv` and the validation
reports) · `3` stopped by a `FAIL_FILE` policy · `1` fatal error (unreadable config or input).

---

## 2. Outputs (per run folder)

| File | Content |
|---|---|
| `alerts.csv` | one row per keyword occurrence × P2 rule with final decision **ALERT** |
| `excluded_matches.csv` | occurrences suppressed by an exclusion rule, with the evidence (list, value, confidence) |
| `monitoring_audit.csv` | every decision (alerts + exclusions) with the full audit record |
| `alerted_transactions.csv` | one investigation record per alerted MESSAGE_KEY (scenarios, keywords, columns, max confidence) |
| `errors.csv` | transactions that could not be screened (blank key, rejected duplicate, unresolved country, malformed record, schema error) and file-level errors |
| `data_quality_report.csv` | summary checks + per-row details (duplicate keys with row numbers and counts, blank keys, malformed records, empty-value rates, country issues) |
| `schema_validation_report.csv` | how every logical field needed by the ACTIVE rules was resolved per country (method, columns, missing candidates, suggestions) |
| `config_validation_report.csv` | P1 / P2 / Intelligence_Lists / settings issues with Excel row numbers |
| `search_plan.txt` | the plan built before the first chunk: country → RT TYPE → keyword → logical field → physical columns |
| `run_summary.json` / `.csv` | versions and SHA-256 hashes of every input, counts, per-scenario/rule/country breakdowns, timings, peak memory |
| `_SUCCESS` / `_FAILED` | completion marker; output files are written as `.part` and renamed only on success |

Every decision row carries: `DECISION_ID, MESSAGE_KEY, ROW_NUMBER, COUNTRY, RT_TYPE, P2_RULE_ID, KEYWORD,
NORMALIZED_KEYWORD, LOGICAL_FIELD, PHYSICAL_COLUMN, ORIGINAL_VALUE, NORMALIZED_VALUE, MATCHED_TEXT, MATCH_START,
MATCH_END, MATCH_TYPE, MATCH_VARIANT, MATCH_SCORE, CONFIDENCE_SCORE, RULES, RULES_EVALUATED,
INDIVIDUAL_CLASSIFICATION, INDIVIDUAL_CONFIDENCE, EXCLUSION_RULE, INTELLIGENCE_LIST, INTELLIGENCE_VALUE,
FINAL_DECISION, REASON, CLASSIFICATION_DETAILS, MAPPING_VERSION, SCHEMA_VERSION, SETTINGS_VERSION, ENGINE_VERSION,
RUN_ID, PROCESSING_TIMESTAMP`.

Example `REASON` (alert):

> Keyword 'ABC' matched as TOKEN in BENEFICIARY_NAME (logical field BENEFICIARY): 'abc' at [0:3], score 100.
> Country IN is eligible for Scenario 1 (P1); P2 rule S1-001. EXCL_INDV did not apply: BUSINESS_ENTITY:
> p(individual)=0.00 vs threshold 0.75 [organisation suffix 'limited' (-6.0); organisation word(s) international
> (-3.5)…] mode=FIELD. EXCL_TOPONYM did not apply: No active Toponym value occurs in BENEFICIARY_NAME. No exclusion
> applied; final decision ALERT.

Example `REASON` (exclusion):

> Keyword 'ABC' matched as TOKEN in BENEFICIARY_ADDRESS (logical field ADDRESS)… EXCL_TOPONYM applied: Active
> Toponym value 'ABC Nagar' (Intelligence_Lists row 2) contains the matched text 'abc' in BENEFICIARY_ADDRESS.
> Final decision EXCLUDED by EXCL_TOPONYM.

Outputs of the bundled sample files are in `data/output/<IN, US, GB, AE, mixed>/`; `mixed_with_ledger/` adds the optional screening ledger.

---

## 3. Configuration

### 3.1 Mapping workbook (`config/mapping.xlsx`) — maintained by compliance

| Sheet | Columns | Notes |
|---|---|---|
| **P1** | `RT TYPE`, `COUNTRIES` | ISO alpha-2 codes, comma-separated; `*` = all countries |
| **P2** | `RT TYPE`, `Keyword`, `Message`, `Rules`, `Status` + optional `Rule_ID`, `Match_Type`, `Fuzzy_Threshold` | `Message` = logical fields; `Rules` = exclusion rule codes (OR) |
| **Intelligence_Lists** | `List`, `Value`, `Status` | Toponym, Secular, Religious – or any new list (gets `EXCL_<LIST>` automatically) |
| Metadata (optional) | `KEY`, `VALUE` | `VERSION` is stamped on every output row together with the file hash |

Only `Status = ACTIVE` rows are used. Sheet and column names are matched case/space-insensitively
(`RT TYPE` = `rt_type`). A README sheet inside the workbook explains each column; Status and Match_Type have
drop-down validation.

### 3.2 Schema mapping — maintained by data engineering

Table form (`config/schema_mapping.xlsx`, also `.csv` or a database table):

| COUNTRY | LOGICAL_FIELD | PHYSICAL_COLUMN | PRIORITY | RESOLUTION | STATUS |
|---|---|---|---|---|---|
| IN | BENEFICIARY | BENEFICIARY_NAME | 1 | ALL | ACTIVE |
| US | BENEFICIARY | BNF_NM | 1 | ALL | ACTIVE |
| GB | BENEFICIARY | CREDITOR | 1 | ALL | ACTIVE |
| AE | ADDRESS | BENE_ADDRESS_LINE_1 | 1 | ALL | ACTIVE |
| AE | ADDRESS | BENE_ADDRESS_LINE_2 | 2 | ALL | ACTIVE |
| DEFAULT | BENEFICIARY | BENEFICIARY_NAME | 1 | ALL | ACTIVE |

Profile form (`config/schemas/*.yaml`, also JSON):

```yaml
country: AE
extends: DEFAULT
fields:
  BENEFICIARY: [BENE_NAME]
  ADDRESS:
    columns: [BENE_ADDRESS_LINE_1, BENE_ADDRESS_LINE_2, BENE_CITY, BENE_POSTAL_CODE]
    resolution: ALL          # ALL = search every listed column present (default) | FIRST
```

Resolution order: country profile → exact column name → canonical name (`Beneficiary Name` = `BENEFICIARY_NAME`)
→ DEFAULT-profile aliases (reported) → identity (column named exactly like the logical field, reported) →
`SCHEMA_MAPPING_ERROR` with *suggestions only*. Fuzzy column matching is never applied automatically, so
`BENEFICIARY_ACCOUNT` can never stand in for `BENEFICIARY`.

### 3.3 Engine settings (`config/settings.yaml`)

Chunk size, reader/matcher backends, duplicate/null-key/schema-error policies, country-resolution order and
file-name patterns, default match type, fuzzy thresholds, the individual-name lexicon, scoring weights, output
options and the rule registry (`EXCL_*` code → classifier). Unknown keys are reported, never ignored silently.

### 3.4 Person-name lexicon (`config/reference/individual_indicators.yaml`)

Titles, relationship markers (S/O, D/O, BIN…), legal-form suffixes, organisation words, given names, surnames,
country-specific additions and the evidence weights used by `EXCL_INDV`. The bundled lists are samples — extend
them with the bank's reference data before production use.

---

## 4. Extending without code changes

| Change | Where |
|---|---|
| New keyword / RT TYPE / country eligibility | P2 / P1 rows |
| Switch a keyword on/off | P2 `Status` |
| New country file layout | add a schema profile (YAML file or rows in the schema table) |
| Address split across more columns | add the columns to the logical field (`resolution: ALL`) |
| New intelligence values | Intelligence_Lists rows |
| New exclusion list, e.g. bank names | add rows with `List = Bank`, use `EXCL_BANK` in P2 (auto-registered) |
| Stricter person exclusion | `individual.threshold`, lexicon weights, or `min_confidence` on the rule |
| Fuzzy matching for one keyword | P2 `Match_Type = FUZZY`, `Fuzzy_Threshold = 88` |
| Country column name / file naming convention | `country_resolution.country_columns` / `file_patterns` |

Code changes are only needed for a new *kind* of classifier (e.g. an NER model), which plugs in through
`IndividualClassifier(extra_signal_providers=[...])` or a new entry in `rules/rule_registry.py`.

---

## 5. Project layout

```
config/            mapping.xlsx · schema_mapping.xlsx · schemas/*.yaml · settings.yaml · reference/
src/
  ingestion/       transaction_reader (pyarrow / pandas chunked) · mapping_reader
  validation/      mapping_validator · schema_validator · data_quality
  schema/          schema_registry (Excel/CSV/YAML/JSON/SQL) · column_resolver · country_resolver
  normalization/   text_normalizer (per-value and batch)
  matching/        candidate_generator (Aho-Corasick / token index) · exact · token · phrase · fuzzy ·
                   substring · keyword_registry · matching_engine (ColumnMatcher)
  context/         individual · toponym · secular · religious · intelligence_list · context_engine
  rules/           rule_registry · rule_engine · exclusion_engine
  scenarios/       scenario_engine (P1 eligibility, P2 indexes)
  scoring/         scoring_engine
  pipeline/        search_plan · chunk_processor · decision_maker
  output/          alert / exclusion / audit / summary writers
  monitoring_engine.py
tests/             153 pytest tests
benchmarks/        synthetic data generator · run_benchmark.py · backend_comparison.py · results/
tools/             build_sample_config.py · build_sample_transactions.py
data/sample/       IN, US, GB, AE and mixed-country sample files
data/output/       outputs of the sample runs
docs/              ARCHITECTURE.md · BENCHMARK.md
```

---

## 6. Requirements and environments

`requirements.txt` lists the core (pandas, numpy, openpyxl, pyyaml) and the optional accelerators:

| Package | Used for | Without it |
|---|---|---|
| pyarrow | 6× faster streaming CSV reader | pandas C parser (slower; cannot flag rows with too *few* fields) |
| pyahocorasick | keyword automaton | pure-Python token index (same results, ~2.5× slower matching) |
| rapidfuzz | FUZZY match type, schema suggestions | FUZZY rules fail at start-up, or are downgraded to TOKEN and reported if `fuzzy_unavailable_policy: DOWNGRADE_TO_TOKEN` |
| psutil | memory figures on Windows | memory reported from the OS where available |

The test suite passes on Python 3.13 + pandas 3.0, Python 3.11 + pandas 2.2 + pyarrow 17, and on a minimal
Python 3.9 + pandas 1.5 environment with **none** of the optional packages (fuzzy/pyarrow-specific tests skipped).

For an air-gapped machine: push this folder to the internal GitHub repository and install the wheels available
on the internal package mirror; everything else is plain Python.

---

## 7. Tests and benchmarks

```bash
python -m pytest                                   # 153 tests (~3 minutes)
python benchmarks/run_benchmark.py                 # 100K, 500K, 1M, 5M rows (generates data on first run)
python benchmarks/backend_comparison.py            # pandas vs pyarrow vs polars vs duckdb; AC vs regex
```

Regenerate the samples: `python tools/build_sample_config.py` and `python tools/build_sample_transactions.py`.

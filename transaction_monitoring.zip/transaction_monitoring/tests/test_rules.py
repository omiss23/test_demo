"""Rules and exclusions end to end: EXCL_INDV, EXCL_TOPONYM, EXCL_SECULAR, EXCL_RELIGIOUS, combinations,
fail-safe behaviour and configuration-only extension."""
from __future__ import annotations

import json

import pytest

from conftest import load_settings, make_mapping, p2_row, read_out, run_engine, write_csv

HEADER = ["MESSAGE_KEY", "BENEFICIARY_NAME", "ORIGINATOR_NAME", "BENEFICIARY_ADDRESS", "PAYMENT_DETAILS"]
P1 = [{"RT TYPE": "S1", "COUNTRIES": "IN"}]
INTEL = [["Toponym", "ABC Nagar", "ACTIVE"], ["Secular", "ABC Pharma", "ACTIVE"],
         ["Religious", "Temple of ABC", "ACTIVE"], ["Bank", "ABC Bank", "ACTIVE"]]


def screen(tmp_path, rows, rules, message="BENEFICIARY,ADDRESS,DESCRIPTION", intel=INTEL, settings=None):
    mapping = make_mapping(tmp_path, p1=P1, p2=[p2_row("S1", "ABC", message, rules=rules)], intel=intel)
    data = write_csv(tmp_path / "tx.csv", HEADER, rows)
    result = run_engine(tmp_path, data, mapping=mapping, country="IN", settings=settings)
    audit = read_out(result, "monitoring_audit.csv")
    return result, {(r.MESSAGE_KEY, r.PHYSICAL_COLUMN): r for r in audit.itertuples()}


def test_excl_indv(tmp_path):
    _, d = screen(tmp_path, [["K1", "ABC S/O Ramesh Kumar", "", "", ""],
                             ["K2", "ABC Holdings Ltd", "", "", ""]], "EXCL_INDV")
    assert d[("K1", "BENEFICIARY_NAME")].FINAL_DECISION == "EXCLUDED"
    assert d[("K1", "BENEFICIARY_NAME")].INDIVIDUAL_CLASSIFICATION == "INDIVIDUAL"
    assert d[("K2", "BENEFICIARY_NAME")].FINAL_DECISION == "ALERT"
    assert d[("K2", "BENEFICIARY_NAME")].INDIVIDUAL_CLASSIFICATION == "BUSINESS_ENTITY"


def test_excl_toponym(tmp_path):
    _, d = screen(tmp_path, [["K1", "", "", "12 ABC Nagar, Pune", ""],
                             ["K2", "", "", "ABC Tower, Mumbai", ""]], "EXCL_TOPONYM")
    k1 = d[("K1", "BENEFICIARY_ADDRESS")]
    assert k1.FINAL_DECISION == "EXCLUDED" and k1.EXCLUSION_RULE == "EXCL_TOPONYM"
    assert k1.INTELLIGENCE_LIST == "Toponym" and k1.INTELLIGENCE_VALUE == "ABC Nagar"
    assert d[("K2", "BENEFICIARY_ADDRESS")].FINAL_DECISION == "ALERT"


def test_excl_secular(tmp_path):
    _, d = screen(tmp_path, [["K1", "ABC Pharma Pvt Ltd", "", "", ""], ["K2", "ABC Capital", "", "", ""]],
                  "EXCL_SECULAR")
    assert d[("K1", "BENEFICIARY_NAME")].FINAL_DECISION == "EXCLUDED"
    assert d[("K1", "BENEFICIARY_NAME")].INTELLIGENCE_LIST == "Secular"
    assert d[("K2", "BENEFICIARY_NAME")].FINAL_DECISION == "ALERT"


def test_excl_religious(tmp_path):
    _, d = screen(tmp_path, [["K1", "", "", "", "Donation to Temple of ABC"], ["K2", "", "", "", "ABC fighters"]],
                  "EXCL_RELIGIOUS")
    assert d[("K1", "PAYMENT_DETAILS")].FINAL_DECISION == "EXCLUDED"
    assert d[("K2", "PAYMENT_DETAILS")].FINAL_DECISION == "ALERT"


def test_multiple_exclusions_are_or_and_all_are_evaluated(tmp_path):
    rules = "EXCL_INDV,EXCL_TOPONYM,EXCL_SECULAR,EXCL_RELIGIOUS"
    _, d = screen(tmp_path, [["K1", "", "", "12 ABC Nagar", ""],             # toponym only
                             ["K2", "Mr ABC Sharma", "", "", ""],            # individual only
                             ["K3", "ABC Trading LLC", "", "", ""]], rules)  # none
    k1, k2, k3 = d[("K1", "BENEFICIARY_ADDRESS")], d[("K2", "BENEFICIARY_NAME")], d[("K3", "BENEFICIARY_NAME")]
    assert (k1.FINAL_DECISION, k1.EXCLUSION_RULE) == ("EXCLUDED", "EXCL_TOPONYM")
    assert (k2.FINAL_DECISION, k2.EXCLUSION_RULE) == ("EXCLUDED", "EXCL_INDV")
    assert k3.FINAL_DECISION == "ALERT"
    for record in (k1, k2, k3):
        assert record.RULES_EVALUATED.count("=") == 4                      # all four rules evaluated
        details = json.loads(record.CLASSIFICATION_DETAILS)
        assert all({"confidence", "reason", "source"} <= set(item) for item in details)


def test_unknown_rule_is_fail_safe(tmp_path):
    result, d = screen(tmp_path, [["K1", "Mr ABC Sharma", "", "", ""]], "EXCL_TYPO,EXCL_INDV")
    record = d[("K1", "BENEFICIARY_NAME")]
    assert record.FINAL_DECISION == "EXCLUDED"                                # EXCL_INDV still applies
    assert "EXCL_TYPO=UNKNOWN_RULE" in record.RULES_EVALUATED
    errors = read_out(result, "errors.csv")
    assert "RULE_UNKNOWN_RULE" in set(errors.ERROR_CODE)
    config = read_out(result, "config_validation_report.csv")
    assert "UNKNOWN_RULE_CODE" in set(config.ISSUE_CODE)


def test_classifier_error_never_excludes(tmp_path, monkeypatch):
    from src.context import toponym_classifier

    def boom(self, ctx):
        raise RuntimeError("lookup failed")

    monkeypatch.setattr(toponym_classifier.ToponymClassifier, "classify", boom)
    result, d = screen(tmp_path, [["K1", "", "", "12 ABC Nagar", ""]], "EXCL_TOPONYM")
    record = d[("K1", "BENEFICIARY_ADDRESS")]
    assert record.FINAL_DECISION == "ALERT" and "EXCL_TOPONYM=ERROR" in record.RULES_EVALUATED
    assert "RULE_ERROR" in set(read_out(result, "errors.csv").ERROR_CODE)


def test_new_list_and_rule_through_configuration_only(tmp_path):
    _, d = screen(tmp_path, [["K1", "ABC Bank Ltd", "", "", ""], ["K2", "ABC Exchange", "", "", ""]], "EXCL_BANK")
    assert d[("K1", "BENEFICIARY_NAME")].FINAL_DECISION == "EXCLUDED"
    assert d[("K1", "BENEFICIARY_NAME")].INTELLIGENCE_LIST == "Bank"
    assert d[("K2", "BENEFICIARY_NAME")].FINAL_DECISION == "ALERT"


def test_min_confidence_in_rule_definition(tmp_path):
    settings = load_settings()
    settings.rules["EXCL_INDV"]["min_confidence"] = 0.999
    _, d = screen(tmp_path, [["K1", "ABC S/O Ramesh Kumar", "", "", ""]], "EXCL_INDV", settings=settings)
    assert d[("K1", "BENEFICIARY_NAME")].FINAL_DECISION == "ALERT"            # 0.98 < 0.999


def test_no_rules_means_every_hit_alerts(tmp_path):
    _, d = screen(tmp_path, [["K1", "Mr ABC Sharma", "", "12 ABC Nagar", ""]], "")
    assert {r.FINAL_DECISION for r in d.values()} == {"ALERT"}
    assert {r.RULES_EVALUATED for r in d.values()} == {"NONE"}


@pytest.mark.parametrize("value", ["ABC", "abc", " ABC ", "A.B.C"])
def test_scores_and_reason_present(tmp_path, value):
    _, d = screen(tmp_path, [["K1", value, "", "", ""]], "EXCL_INDV")
    if value == "A.B.C":
        assert d == {}
        return
    record = d[("K1", "BENEFICIARY_NAME")]
    assert float(record.MATCH_SCORE) == 100 and 0 < float(record.CONFIDENCE_SCORE) <= 1
    assert "Country IN is eligible for S1" in record.REASON

"""End to end: CSV -> country -> schema -> P1 -> P2 -> matching -> intelligence lists -> rules -> decision -> output."""
from __future__ import annotations

import pytest

from conftest import CONFIG, HAS_RAPIDFUZZ, SAMPLES, decisions, load_settings, read_out, run_engine
from src.output.columns import DECISION_COLUMNS

SPEC_AUDIT_FIELDS = ["MESSAGE_KEY", "RT_TYPE", "COUNTRY", "KEYWORD", "LOGICAL_FIELD", "PHYSICAL_COLUMN",
                     "ORIGINAL_VALUE", "NORMALIZED_VALUE", "MATCH_TYPE", "MATCH_SCORE", "CONFIDENCE_SCORE", "RULES",
                     "RULES_EVALUATED", "EXCLUSION_RULE", "INTELLIGENCE_LIST", "INTELLIGENCE_VALUE",
                     "FINAL_DECISION", "REASON", "MAPPING_VERSION", "SCHEMA_VERSION", "PROCESSING_TIMESTAMP"]

EXPECTED_IN = {
    ("IN0001", "ABC", "BENEFICIARY_NAME"): "ALERT",          # business entity -> EXCL_INDV does not apply
    ("IN0002", "ABC", "BENEFICIARY_ADDRESS"): "EXCLUDED",    # ABC NAGAR toponym
    ("IN0003", "JIHAD", "BENEFICIARY_NAME"): "EXCLUDED",     # personal name
    ("IN0004", "JIHAD", "BENEFICIARY_NAME"): "ALERT",        # foundation
    ("IN0005", "SHAHEED", "BENEFICIARY_ADDRESS"): "EXCLUDED",
    ("IN0006", "SHAHEED", "BENEFICIARY_NAME"): "ALERT",
    ("IN0007", "AL QAIDA", "PAYMENT_DETAILS"): "ALERT",
    ("IN0008", "AL QAIDA", "PAYMENT_DETAILS"): "ALERT",      # compact variant ALQAIDA
    ("IN0009", "LASHKAR E TAIBA", "BENEFICIARY_NAME"): "ALERT",  # fuzzy
    ("IN0010", "HIZBUL MUJAHIDEEN", "PAYMENT_DETAILS"): "ALERT",  # phrase with a gap
    ("IN0011", "ISIS", "BENEFICIARY_NAME"): "EXCLUDED",      # secular
    ("IN0012", "ISIS", "PAYMENT_DETAILS"): "EXCLUDED",       # religious
    ("IN0013", "ISIS", "PAYMENT_DETAILS"): "ALERT",
    ("IN0017", "MUJAHID", "BENEFICIARY_NAME"): "EXCLUDED",
    ("IN0018", "MUJAHID", "BENEFICIARY_NAME"): "ALERT",
    ("IN0019", "PQR", "BENEFICIARY_NAME"): "EXCLUDED",
    ("IN0020", "PQR", "BENEFICIARY_NAME"): "ALERT",
    ("IN0021", "ABC", "ORIGINATOR_NAME"): "EXCLUDED",        # 'Shri' -> Indian title
    ("IN0022", "XYZ", "PAYMENT_DETAILS"): "EXCLUDED",
    ("IN0023", "XYZ", "PAYMENT_DETAILS"): "ALERT",
    ("IN0024", "ABC", "BENEFICIARY_NAME"): "ALERT",
    ("IN0025", "SHAHEED", "BENEFICIARY_NAME"): "EXCLUDED",
    ("IN0026", "MARTYR FUND", "PAYMENT_DETAILS"): "ALERT",
    ("IN0027", "ABC", "BENEFICIARY_NAME"): "ALERT",          # Unicode: Societe
    ("IN0028", "ABC", "BENEFICIARY_NAME"): "EXCLUDED",
    ("IN0028", "ABC", "BENEFICIARY_ADDRESS"): "EXCLUDED",
}


FUZZY_ROWS = {"IN0009", "US0006"}          # only found with rapidfuzz (FUZZY rule S1-004)


def as_dict(result):
    found = {(k, kw, col): d for k, kw, col, d in decisions(result)}
    if not HAS_RAPIDFUZZ:      # minimal environment: FUZZY downgraded to TOKEN, spelling variants not found
        found = {k: v for k, v in found.items() if k[0] not in FUZZY_ROWS}
    return found


def expected(table):
    return table if HAS_RAPIDFUZZ else {k: v for k, v in table.items() if k[0] not in FUZZY_ROWS}


def test_india_sample_full_pipeline(tmp_path):
    result = run_engine(tmp_path, SAMPLES / "transactions_IN.csv")
    assert as_dict(result) == expected(EXPECTED_IN)
    errors = read_out(result, "errors.csv")
    assert errors.ERROR_CODE.tolist() == ["NULL_MESSAGE_KEY"]
    config = read_out(result, "config_validation_report.csv")
    assert config.empty if HAS_RAPIDFUZZ else set(config.ISSUE_CODE) == {"FUZZY_DOWNGRADED"}
    assert result.summary["country_resolution"]["rows_resolved_by"] == {"file_pattern": 29}


def test_same_rules_screen_us_gb_ae_schemas(tmp_path):
    us = as_dict(run_engine(tmp_path, SAMPLES / "transactions_US.csv"))
    assert us == expected({("US0001", "ABC", "BNF_NM"): "ALERT", ("US0002", "ABC", "BNF_ADDR"): "EXCLUDED",
                           ("US0004", "ISIS", "BNF_NM"): "EXCLUDED", ("US0005", "AL QAIDA", "OBI"): "ALERT",
                           ("US0006", "LASHKAR E TAIBA", "BNF_NM"): "ALERT", ("US0008", "ISIS", "BNF_NM"): "EXCLUDED"})
    gb = as_dict(run_engine(tmp_path, SAMPLES / "transactions_GB.csv"))
    assert gb == {("GB0001", "ABC", "CREDITOR"): "ALERT", ("GB0002", "ISIS", "CREDITOR"): "EXCLUDED",
                  ("GB0003", "ABC", "DEBTOR"): "ALERT", ("GB0004", "AL QAIDA", "REMITTANCE_INFO"): "ALERT",
                  ("GB0006", "HIZBUL MUJAHIDEEN", "CREDITOR"): "ALERT"}
    ae = as_dict(run_engine(tmp_path, SAMPLES / "transactions_AE.csv"))
    assert ae == {("AE0001", "MUJAHID", "BENE_NAME"): "EXCLUDED", ("AE0002", "MUJAHID", "BENE_NAME"): "ALERT",
                  ("AE0003", "SHAHEED", "BENE_ADDRESS_LINE_2"): "EXCLUDED",
                  ("AE0004", "MARTYR FUND", "PAYMENT_PURPOSE"): "ALERT", ("AE0006", "PQR", "BENE_NAME"): "EXCLUDED"}


def test_mixed_country_file(tmp_path):
    result = run_engine(tmp_path, SAMPLES / "transactions_mixed.csv")
    found = as_dict(result)
    assert found[("MX0004", "ABC", "BENEFICIARY_NAME")] == "ALERT"           # 'UK' -> GB
    assert found[("MX0005", "JIHAD", "BENEFICIARY_NAME")] == "ALERT"         # AE in Scenario 2
    assert found[("MX0011", "MUJAHID", "BENEFICIARY_NAME")] == "ALERT"       # SG -> DEFAULT profile
    assert not any(k[0] in ("MX0006", "MX0007") for k in found)             # JP and NA: not in P1
    errors = read_out(result, "errors.csv")
    assert sorted(errors.MESSAGE_KEY) == ["MX0008", "MX0009"]


@pytest.mark.parametrize("chunk", [1, 3, 7, 1000])
def test_results_do_not_depend_on_chunk_size(tmp_path, chunk):
    baseline = read_out(run_engine(tmp_path, SAMPLES / "transactions_IN.csv"), "monitoring_audit.csv")
    other = read_out(run_engine(tmp_path, SAMPLES / "transactions_IN.csv", chunk_size=chunk), "monitoring_audit.csv")
    keep = ["DECISION_ID", "MESSAGE_KEY", "ROW_NUMBER", "P2_RULE_ID", "PHYSICAL_COLUMN", "MATCH_START",
            "FINAL_DECISION", "REASON", "CONFIDENCE_SCORE"]
    assert (baseline[keep].sort_values("DECISION_ID").reset_index(drop=True)
            .equals(other[keep].sort_values("DECISION_ID").reset_index(drop=True)))


@pytest.mark.parametrize("override", [{"matching.candidate_backend": "pure_python"},
                                      {"input.reader_backend": "pandas"}])
def test_backends_give_identical_results(tmp_path, override):
    for name in ("transactions_IN.csv", "transactions_mixed.csv", "transactions_AE.csv"):
        default = decisions(run_engine(tmp_path, SAMPLES / name))
        alternative = decisions(run_engine(tmp_path, SAMPLES / name, settings=load_settings(**override)))
        assert default == alternative, name


def test_schema_formats_give_identical_results(tmp_path):
    excel = decisions(run_engine(tmp_path, SAMPLES / "transactions_AE.csv", schema=CONFIG / "schema_mapping.xlsx"))
    yaml_dir = decisions(run_engine(tmp_path, SAMPLES / "transactions_AE.csv", schema=CONFIG / "schemas"))
    assert excel == yaml_dir and excel


def test_audit_record_contract(tmp_path):
    result = run_engine(tmp_path, SAMPLES / "transactions_IN.csv")
    audit = read_out(result, "monitoring_audit.csv")
    assert list(audit.columns) == DECISION_COLUMNS
    assert set(SPEC_AUDIT_FIELDS) <= set(audit.columns)
    assert (audit.MESSAGE_KEY != "").all() and (audit.REASON != "").all()
    assert audit.MAPPING_VERSION.str.startswith("2026.10|sha256:").all()
    alerts, excluded = read_out(result, "alerts.csv"), read_out(result, "excluded_matches.csv")
    assert len(alerts) + len(excluded) == len(audit)
    assert set(alerts.FINAL_DECISION) == {"ALERT"} and set(excluded.FINAL_DECISION) == {"EXCLUDED"}
    rollup = read_out(result, "alerted_transactions.csv")
    assert sorted(rollup.MESSAGE_KEY) == sorted(set(alerts.MESSAGE_KEY))
    for name in ("data_quality_report.csv", "schema_validation_report.csv", "config_validation_report.csv",
                 "run_summary.json", "search_plan.txt", "_SUCCESS"):
        assert (result.output_dir / name).exists(), name
    assert not list(result.output_dir.glob("*.part"))


def test_decision_ids_are_stable_across_runs(tmp_path):
    first = read_out(run_engine(tmp_path, SAMPLES / "transactions_IN.csv"), "monitoring_audit.csv")
    second = read_out(run_engine(tmp_path, SAMPLES / "transactions_IN.csv"), "monitoring_audit.csv")
    assert sorted(first.DECISION_ID) == sorted(second.DECISION_ID)
    assert first.RUN_ID.iloc[0] != second.RUN_ID.iloc[0]


def test_validate_only_builds_plan_without_screening(tmp_path):
    result = run_engine(tmp_path, SAMPLES / "transactions_US.csv", validate_only=True)
    assert result.status == "VALIDATED"
    assert not (result.output_dir / "alerts.csv").exists()
    plan = (result.output_dir / "search_plan.txt").read_text()
    assert "BENEFICIARY    -> BNF_NM" in plan and "Scenario 2" not in plan


def test_screening_ledger(tmp_path):
    settings = load_settings(**{"output.write_screening_ledger": True})
    result = run_engine(tmp_path, SAMPLES / "transactions_mixed.csv", settings=settings)
    ledger = read_out(result, "screened_transactions.csv")
    assert len(ledger) == 12
    status = dict(zip(ledger.MESSAGE_KEY, ledger.SCREENING_STATUS))
    assert status["MX0001"] == "ALERTED" and status["MX0003"] == "ALL_HITS_EXCLUDED"
    assert status["MX0006"] == "NOT_ELIGIBLE" and status["MX0008"] == "COUNTRY_UNRESOLVED"

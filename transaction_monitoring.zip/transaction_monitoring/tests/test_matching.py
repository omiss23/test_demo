"""Matching engine: EXACT, TOKEN, PHRASE, FUZZY, SUBSTRING, Unicode, large keyword sets, backend parity."""
from __future__ import annotations

import random
import re
import time

import pytest

from conftest import needs_rapidfuzz
from src.exceptions import ConfigurationError
from src.matching import fuzzy_matcher
from src.matching.keyword_registry import KeywordRegistry
from src.matching.matching_engine import ColumnMatcher
from src.normalization.text_normalizer import TextNormalizer
from src.settings import MatchingSettings

N = TextNormalizer()


def matcher(specs, backend="auto", **settings_kw):
    settings = MatchingSettings(candidate_backend=backend, **settings_kw)
    registry = KeywordRegistry(settings)
    ids = [registry.register(N.normalize(kw), mtype, thr) for kw, mtype, thr in specs]
    return ColumnMatcher([registry.specs[i] for i in sorted(set(ids))], N, settings), registry


def hits_for(m, registry, values):
    out = {}
    for index, (normalized, hits) in m.match_values(values).items():
        out[values[index]] = sorted((registry.specs[h.spec_id].keyword, normalized[h.start:h.end],
                                     registry.specs[h.spec_id].match_type, h.variant, round(h.score, 1)) for h in hits)
    return out


def test_exact_matches_whole_value_only():
    m, reg = matcher([("ABC", "EXACT", None)])
    found = hits_for(m, reg, ["ABC", " abc. ", "ABC LTD", "XABC"])
    assert set(found) == {"ABC", " abc. "}


@pytest.mark.parametrize("value, expected", [
    ("ABC LTD", True), ("PAID TO ABC.", True), ("abc", True), ("(ABC)", True),
    ("ABCD TRADING", False), ("XABC", False), ("A B C", False), ("", False),
])
def test_token_word_boundaries(value, expected):
    m, reg = matcher([("ABC", "TOKEN", None)])
    assert (value in hits_for(m, reg, [value])) is expected


def test_token_multiword_and_compact_variant():
    m, reg = matcher([("AL QAIDA", "TOKEN", None), ("AB C", "TOKEN", None)])
    found = hits_for(m, reg, ["DONATION FOR AL-QAIDA", "ALQAIDA RELIEF", "AL QAIDAH", "ABC"])
    assert found["DONATION FOR AL-QAIDA"] == [("al qaida", "al qaida", "TOKEN", "", 100.0)]
    assert found["ALQAIDA RELIEF"] == [("al qaida", "alqaida", "TOKEN", "COMPACT", 100.0)]
    assert "AL QAIDAH" not in found          # TOKEN is precise: a spelling variant needs FUZZY
    assert "ABC" not in found                # compact 'abc' (3 chars) is below compact_variant_min_length


def test_compact_variants_can_be_disabled():
    m, reg = matcher([("AL QAIDA", "TOKEN", None)], compact_variants=False)
    assert hits_for(m, reg, ["ALQAIDA"]) == {}


@pytest.mark.parametrize("value, score", [
    ("ISLAMIC STATE OF IRAQ", 100.0),
    ("ISLAMIC REVIVAL STATE", 95.0),
    ("ISLAMIC A B STATE", 90.0),
    ("ISLAMIC A B C STATE", None),           # gap 3 > phrase_max_gap 2
    ("STATE ISLAMIC", None),                 # order matters
])
def test_phrase_with_gaps(value, score):
    m, reg = matcher([("ISLAMIC STATE", "PHRASE", None)])
    found = hits_for(m, reg, [value])
    if score is None:
        assert value not in found
    else:
        assert found[value][0][4] == score


@needs_rapidfuzz
@pytest.mark.parametrize("value, expected", [
    ("Lashkar-e-Toiba Welfare Society", True),
    ("LASHKAR E TAYYIBA FUND", True),
    ("LASHKARETAIBA", True),                 # compact comparison catches missing spaces
    ("Lakshmi Traders", False),
    ("LASHKAR ROAD", False),
])
def test_fuzzy(value, expected):
    m, reg = matcher([("LASHKAR E TAIBA", "FUZZY", 88.0)])
    found = hits_for(m, reg, [value])
    assert (value in found) is expected
    if expected:
        assert all(88 <= h[4] <= 100 for h in found[value])


def test_fuzzy_downgrade_policy_when_rapidfuzz_is_missing(monkeypatch):
    from src.matching import keyword_registry

    monkeypatch.setattr(keyword_registry, "rapidfuzz_available", lambda: False)
    with pytest.raises(ConfigurationError, match="rapidfuzz"):
        matcher([("LASHKAR E TAIBA", "FUZZY", 88.0)])
    m, reg = matcher([("LASHKAR E TAIBA", "FUZZY", 88.0)], fuzzy_unavailable_policy="DOWNGRADE_TO_TOKEN")
    assert [s.match_type for s in reg.specs.values()] == ["TOKEN"]
    assert reg.issues[0].code == "FUZZY_DOWNGRADED"
    assert "LASHKAR E TAIBA" in hits_for(m, reg, ["LASHKAR E TAIBA"])


def test_fuzzy_is_only_used_where_configured():
    m, reg = matcher([("LASHKAR E TAIBA", "TOKEN", None)])
    assert hits_for(m, reg, ["LASHKAR E TOIBA"]) == {}


@needs_rapidfuzz
def test_fuzzy_without_rapidfuzz_fails_loudly(monkeypatch):
    monkeypatch.setattr(fuzzy_matcher, "rapidfuzz_available", lambda: False)
    with pytest.raises(ConfigurationError, match="rapidfuzz"):
        matcher([("LASHKAR E TAIBA", "FUZZY", 88.0)])


def test_substring_is_opt_in_and_scored_by_coverage():
    m, reg = matcher([("ISIS", "SUBSTRING", None)])
    found = hits_for(m, reg, ["ISISWORLD TRAVEL", "PAID ISIS"])
    assert found["ISISWORLD TRAVEL"][0][4] < 100 and found["PAID ISIS"][0][4] == 100.0


def test_unicode_punctuation_and_case():
    m, reg = matcher([("Société Générale", "TOKEN", None), ("Qa'ida", "TOKEN", None)])
    found = hits_for(m, reg, ["SOCIETE GENERALE S.A.", "société-générale", "al QAIDA"])
    assert set(found) == {"SOCIETE GENERALE S.A.", "société-générale", "al QAIDA"}


def test_hit_offsets_point_at_the_keyword():
    m, reg = matcher([("ABC", "TOKEN", None), ("XYZ ROAD", "TOKEN", None)])
    values = ["12, ABC Nagar - XYZ Road; ABC"]
    (normalized, hits), = m.match_values(values).values()
    assert [normalized[h.start:h.end] for h in hits] == ["abc", "xyz road", "abc"]


def _random_word(rng):
    return "".join(rng.choice("bcdfghjklmnpqrstvwxz") + rng.choice("aeiou") for _ in range(rng.randint(2, 4)))


def test_large_keyword_set_backend_parity_and_reference(tmp_path):
    """10,000 keywords: automaton and pure-Python index agree with a regex reference implementation."""
    rng = random.Random(42)
    keywords = sorted({_random_word(rng) for _ in range(12_000)})[:10_000]
    multi = [f"{keywords[i]} {keywords[i + 1]}" for i in range(0, 400, 2)]
    specs = [(k, "TOKEN", None) for k in keywords] + [(k, "TOKEN", None) for k in multi]
    filler = ["payment", "invoice", "mumbai", "trading", "ltd", "road", "12", "a"]
    values = []
    for _ in range(3_000):
        words = [rng.choice(filler) for _ in range(rng.randint(1, 6))]
        if rng.random() < 0.3:
            words.insert(rng.randint(0, len(words)), rng.choice(keywords + multi).upper())
        values.append(" ".join(words) + rng.choice(["", ".", " LLC", "-x"]))
    m_ac, reg = matcher(specs, backend="aho_corasick")
    m_py, _ = matcher(specs, backend="pure_python", )
    started = time.perf_counter()
    ac = hits_for(m_ac, reg, values)
    elapsed = time.perf_counter() - started
    assert hits_for(m_py, reg, values) == ac
    assert elapsed < 5.0
    # reference: brute-force regex word-boundary search on the normalised text, sample of values
    for value in values[:400]:
        norm = N.normalize(value)
        expected = sorted(k for k in set(keywords + multi) if re.search(rf"(?<![^ ]){re.escape(k)}(?![^ ])", norm))
        got = sorted({h[0] for h in ac.get(value, []) if h[3] == ""})
        assert got == expected, value

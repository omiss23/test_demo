"""Mapping workbook: P1, P2 and Intelligence_Lists parsing and validation."""
from __future__ import annotations

import pandas as pd
import pytest

from conftest import load_settings, make_mapping, p2_row
from src.exceptions import ConfigurationError
from src.ingestion.mapping_reader import MappingReader
from src.matching.keyword_registry import KeywordRegistry
from src.normalization.text_normalizer import TextNormalizer
from src.scenarios.scenario_engine import ScenarioEngine
from src.validation.mapping_validator import MappingValidator


def load(path, **settings_overrides):
    settings = load_settings(**settings_overrides)
    config = MappingValidator(settings, TextNormalizer()).validate(MappingReader(path).read())
    return config, settings


def codes(config):
    return {(i.source, i.code) for i in config.issues}


# --------------------------------------------------------------------------- P1
def test_p1_multiple_countries_with_mixed_separators_and_case(tmp_path):
    path = make_mapping(tmp_path, p1=[{"RT TYPE": "Scenario 1", "COUNTRIES": " in, us ;GB "}],
                        p2=[p2_row("Scenario 1", "ABC", "BENEFICIARY")])
    config, _ = load(path)
    assert config.p1["SCENARIO 1"] == frozenset({"IN", "US", "GB"})


def test_p1_invalid_country_is_reported_and_ignored(tmp_path):
    path = make_mapping(tmp_path, p1=[{"RT TYPE": "Scenario 1", "COUNTRIES": "IN,XX"}],
                        p2=[p2_row("Scenario 1", "ABC", "BENEFICIARY")])
    config, _ = load(path)
    assert config.p1["SCENARIO 1"] == frozenset({"IN"})
    issue = next(i for i in config.issues if i.code == "INVALID_COUNTRY_CODE")
    assert issue.row == 2 and issue.value == "XX"


def test_p1_alias_and_namibia_na_is_not_treated_as_missing(tmp_path):
    path = make_mapping(tmp_path, p1=[{"RT TYPE": "Scenario 1", "COUNTRIES": "UK,NA"}],
                        p2=[p2_row("Scenario 1", "ABC", "BENEFICIARY")])
    config, _ = load(path)
    assert config.p1["SCENARIO 1"] == frozenset({"GB", "NA"})
    assert ("P1", "COUNTRY_ALIAS_APPLIED") in codes(config)


def test_p1_wildcard_and_duplicate_rt_type_merge(tmp_path):
    path = make_mapping(tmp_path, p1=[{"RT TYPE": "Scenario 1", "COUNTRIES": "IN"},
                                      {"RT TYPE": "scenario  1", "COUNTRIES": "US"},
                                      {"RT TYPE": "Scenario 2", "COUNTRIES": "*"}],
                        p2=[p2_row("Scenario 1", "ABC", "BENEFICIARY"), p2_row("Scenario 2", "XYZ", "BENEFICIARY")])
    config, settings = load(path)
    assert config.p1["SCENARIO 1"] == frozenset({"IN", "US"})
    assert ("P1", "DUPLICATE_RT_TYPE") in codes(config)
    scenarios = ScenarioEngine(config, KeywordRegistry(settings.matching))
    assert scenarios.is_eligible("Scenario 2", "JP")
    assert not scenarios.is_eligible("Scenario 1", "JP")


# --------------------------------------------------------------------------- P2
def test_p2_only_active_rows_are_loaded(tmp_path):
    path = make_mapping(tmp_path, p2=[
        p2_row("Scenario 1", "ABC", "BENEFICIARY", status="ACTIVE"),
        p2_row("Scenario 1", "DEF", "BENEFICIARY", status="INACTIVE"),
        p2_row("Scenario 1", "GHI", "BENEFICIARY", status=" active "),
        p2_row("Scenario 1", "JKL", "BENEFICIARY", status="Pending"),
    ])
    config, _ = load(path)
    assert sorted(r.keyword for r in config.rules) == ["ABC", "GHI"]
    assert config.stats["p2_inactive_rows"] == 2
    assert ("P2", "INVALID_STATUS") in codes(config)


def test_p2_multiple_rules_and_logical_fields(tmp_path):
    path = make_mapping(tmp_path, p2=[p2_row("Scenario 1", "ABC", "Beneficiary, originator ,ADDRESS",
                                             rules="excl_indv, EXCL_TOPONYM")])
    rule = load(path)[0].rules[0]
    assert rule.logical_fields == ("BENEFICIARY", "ORIGINATOR", "ADDRESS")
    assert rule.exclusion_rules == ("EXCL_INDV", "EXCL_TOPONYM")
    assert rule.normalized_keyword == "abc"


def test_p2_unknown_rule_code_is_reported_but_keyword_still_screened(tmp_path):
    path = make_mapping(tmp_path, p2=[p2_row("Scenario 1", "ABC", "BENEFICIARY", rules="EXCL_TYPO")])
    config, _ = load(path)
    assert [r.keyword for r in config.rules] == ["ABC"]
    assert ("P2", "UNKNOWN_RULE_CODE") in codes(config)


def test_p2_invalid_rows_are_rejected_with_row_numbers(tmp_path):
    path = make_mapping(tmp_path, p2=[
        p2_row("Scenario 1", "", "BENEFICIARY"),
        p2_row("Scenario 1", "ABC", ""),
        p2_row("", "ABC", "BENEFICIARY"),
        p2_row("Scenario 1", "!!!", "BENEFICIARY"),
    ])
    config, _ = load(path)
    assert config.rules == []
    found = {(i.code, i.row) for i in config.issues}
    assert {("MISSING_KEYWORD", 2), ("MISSING_MESSAGE_FIELDS", 3), ("MISSING_RT_TYPE", 4),
            ("EMPTY_NORMALIZED_KEYWORD", 5)} <= found


def test_p2_duplicate_rows_are_deduplicated_with_warning(tmp_path):
    path = make_mapping(tmp_path, p2=[p2_row("Scenario 1", "ABC", "BENEFICIARY"),
                                      p2_row("Scenario 1", "abc", "BENEFICIARY")])
    config, _ = load(path)
    assert len(config.rules) == 1
    assert ("P2", "DUPLICATE_P2_ROW") in codes(config)


def test_p2_optional_columns_absent_defaults_to_token(tmp_path):
    path = make_mapping(tmp_path, p2=[["Scenario 1", "ABC", "BENEFICIARY", "", "ACTIVE"]],
                        p2_columns=["RT TYPE", "Keyword", "Message", "Rules", "Status"])
    rule = load(path)[0].rules[0]
    assert rule.match_type == "TOKEN" and rule.rule_id == "P2-R2"


def test_p2_invalid_match_type_and_threshold(tmp_path):
    path = make_mapping(tmp_path, p2=[p2_row("Scenario 1", "ABC", "BENEFICIARY", match_type="FUZY"),
                                      p2_row("Scenario 1", "LASHKAR", "BENEFICIARY", match_type="FUZZY",
                                             threshold="150")])
    config, _ = load(path)
    by_kw = {r.keyword: r for r in config.rules}
    assert by_kw["ABC"].match_type == "TOKEN"
    assert by_kw["LASHKAR"].fuzzy_threshold == 90.0
    assert {("P2", "INVALID_MATCH_TYPE"), ("P2", "INVALID_FUZZY_THRESHOLD")} <= codes(config)


def test_p2_rule_ids_explicit_and_duplicate(tmp_path):
    path = make_mapping(tmp_path, p2=[p2_row("Scenario 1", "ABC", "BENEFICIARY", rule_id="R-1"),
                                      p2_row("Scenario 1", "XYZ", "BENEFICIARY", rule_id="R-1")])
    config, _ = load(path)
    assert [r.rule_id for r in config.rules] == ["R-1", "R-1-R3"]
    assert ("P2", "DUPLICATE_RULE_ID") in codes(config)


def test_orphan_rt_type_warning(tmp_path):
    path = make_mapping(tmp_path, p2=[p2_row("Scenario 9", "ABC", "BENEFICIARY")])
    assert ("P2", "ORPHAN_RT_TYPE") in codes(load(path)[0])


def test_rule_indexes(tmp_path):
    path = make_mapping(tmp_path)
    config, settings = load(path)
    scenarios = ScenarioEngine(config, KeywordRegistry(settings.matching))
    assert {r.keyword for r in scenarios.rules_by_rt_type["SCENARIO 1"]} >= {"ABC", "XYZ", "AL QAIDA"}
    assert {r.rt_type for r in scenarios.rules_by_keyword["xyz"]} == {"Scenario 1", "Scenario 3"}
    assert all("DESCRIPTION" in r.logical_fields for r in scenarios.rules_by_logical_field["DESCRIPTION"])
    in_rules = scenarios.rules_for_country("IN")
    assert {r.rt_type for r in in_rules} == {"Scenario 1", "Scenario 2"}
    assert scenarios.rules_for_country("JP") == []


# --------------------------------------------------------------------------- Intelligence lists
def test_intelligence_lists_active_only_normalised_and_validated(tmp_path):
    path = make_mapping(tmp_path, intel=[
        ["Toponym", "ABC-Nagar", "ACTIVE"],
        ["Toponym", "abc nagar", "ACTIVE"],       # duplicate after normalisation
        ["Toponym", "XYZ Road", "INACTIVE"],
        ["Secular", "", "ACTIVE"],
        ["Religious", "Temple of Isis", "active"],
    ])
    config, _ = load(path)
    assert [e.normalized_value for e in config.intelligence["TOPONYM"]] == ["abc nagar"]
    assert [e.value for e in config.intelligence["RELIGIOUS"]] == ["Temple of Isis"]
    assert "SECULAR" not in config.intelligence
    found = codes(config)
    assert ("Intelligence_Lists", "DUPLICATE_VALUE") in found
    assert ("Intelligence_Lists", "MISSING_VALUE") in found


def test_new_intelligence_list_auto_registers_rule(tmp_path):
    path = make_mapping(tmp_path, p2=[p2_row("Scenario 1", "ABC", "BENEFICIARY", rules="EXCL_BANK")],
                        intel=[["Bank", "ABC Bank", "ACTIVE"]])
    config, _ = load(path)
    assert config.registry.get("EXCL_BANK").list_key == "BANK"
    assert ("P2", "UNKNOWN_RULE_CODE") not in codes(config)


# --------------------------------------------------------------------------- Workbook structure
def test_missing_sheet_raises(tmp_path):
    path = tmp_path / "bad.xlsx"
    with pd.ExcelWriter(path) as writer:
        pd.DataFrame({"RT TYPE": ["Scenario 1"], "COUNTRIES": ["IN"]}).to_excel(writer, sheet_name="P1", index=False)
    with pytest.raises(ConfigurationError, match="P2"):
        MappingReader(path).read()


def test_sheet_and_header_names_are_matched_canonically(tmp_path):
    path = tmp_path / "loose.xlsx"
    with pd.ExcelWriter(path) as writer:
        pd.DataFrame({"rt type": ["Scenario 1"], "Countries": ["IN"]}).to_excel(writer, sheet_name="p1", index=False)
        pd.DataFrame({"Rt_Type": ["Scenario 1"], "KEYWORDS": ["ABC"], "message": ["BENEFICIARY"],
                      "rules": [""], "STATUS": ["ACTIVE"]}).to_excel(writer, sheet_name="P2", index=False)
        pd.DataFrame({"List": ["Toponym"], "Value": ["ABC Nagar"], "Status": ["ACTIVE"]}).to_excel(
            writer, sheet_name="Intelligence Lists", index=False)
    config, _ = load(path)
    assert [r.keyword for r in config.rules] == ["ABC"]


def test_mapping_version_comes_from_metadata_and_hash(tmp_path):
    path = make_mapping(tmp_path, version="2026.11")
    config, _ = load(path)
    assert config.version.startswith("2026.11|sha256:")
    unversioned = make_mapping(tmp_path, version=None, name="nov.xlsx")
    assert load(unversioned)[0].version.startswith("sha256:")

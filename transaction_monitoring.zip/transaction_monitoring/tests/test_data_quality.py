"""Data quality: MESSAGE_KEY handling, duplicates policies, nulls, encodings, malformed rows, missing values."""
from __future__ import annotations

import pytest

from conftest import HAS_RAPIDFUZZ, load_settings, needs_pyarrow, read_out, run_engine, write_csv

HEADER = ["MESSAGE_KEY", "BENEFICIARY_NAME", "ORIGINATOR_NAME", "BENEFICIARY_ADDRESS", "ORIGINATOR_ADDRESS",
          "PAYMENT_DETAILS", "AMOUNT"]


def rows_with_duplicate():
    return [["K1", "ABC International Limited", "Rahul", "Mumbai", "Pune", "INV 1", "10"],
            ["K2", "Ravi Das", "Anita", "Delhi", "Pune", "INV 2", "20"],
            ["K1", "AL QAIDA BRIGADE", "Unknown", "Unknown", "Unknown", "TRANSFER", "30"],
            ["K3", "Clean Name", "Other", "Chennai", "Pune", "INV 3", "40"]]


def test_duplicates_warn_and_process(tmp_path):
    data = write_csv(tmp_path / "dups.csv", HEADER, rows_with_duplicate())
    result = run_engine(tmp_path, data, country="IN")
    alerts = read_out(result, "alerts.csv")
    assert set(alerts.MESSAGE_KEY) == {"K1"} and len(alerts) == 2          # both K1 rows screened
    dq = read_out(result, "data_quality_report.csv")
    dup = dq[dq.CHECK == "DUPLICATE_MESSAGE_KEY"]
    assert sorted(dup.ROW_NUMBER.astype(int)) == [1, 3]
    assert set(dup.MESSAGE_KEY) == {"K1"} and set(dup.COUNT) == {"2"}
    assert dq[dq.CHECK == "MESSAGE_KEY_UNIQUE"].STATUS.item() == "WARN"
    if HAS_RAPIDFUZZ:     # without rapidfuzz the sample config reports FUZZY_DOWNGRADED errors as well
        assert result.status == "COMPLETED_WITH_WARNINGS" and result.exit_code == 0


def test_duplicates_rejected(tmp_path):
    data = write_csv(tmp_path / "dups.csv", HEADER, rows_with_duplicate())
    settings = load_settings(**{"data_quality.duplicate_message_key_policy": "REJECT_DUPLICATES"})
    result = run_engine(tmp_path, data, country="IN", settings=settings)
    assert read_out(result, "alerts.csv").empty
    errors = read_out(result, "errors.csv")
    rejected = errors[errors.ERROR_CODE == "DUPLICATE_MESSAGE_KEY_REJECTED"]
    assert sorted(rejected.ROW_NUMBER.astype(int)) == [1, 3] and set(rejected.MESSAGE_KEY) == {"K1"}
    assert result.summary["processing"]["rows_screened"] == 2


def test_duplicates_fail_file(tmp_path):
    data = write_csv(tmp_path / "dups.csv", HEADER, rows_with_duplicate())
    settings = load_settings(**{"data_quality.duplicate_message_key_policy": "FAIL_FILE"})
    result = run_engine(tmp_path, data, country="IN", settings=settings)
    assert result.status == "FAILED_POLICY" and result.exit_code == 3
    assert not (result.output_dir / "alerts.csv").exists()
    assert (result.output_dir / "_FAILED").exists()
    dq = read_out(result, "data_quality_report.csv")
    assert len(dq[dq.CHECK == "DUPLICATE_MESSAGE_KEY"]) == 2


def test_null_message_key_rows_are_not_screened_but_reported(tmp_path):
    data = write_csv(tmp_path / "nulls.csv", HEADER, [["", "AL QAIDA", "", "", "", "", ""],
                                                      ["  ", "ABC Ltd", "", "", "", "", ""],
                                                      ["K9", "Ravi Das", "", "", "", "", ""]])
    result = run_engine(tmp_path, data, country="IN")
    errors = read_out(result, "errors.csv")
    nulls = errors[errors.ERROR_CODE == "NULL_MESSAGE_KEY"]
    assert sorted(nulls.ROW_NUMBER.astype(int)) == [1, 2]
    assert read_out(result, "alerts.csv").empty
    assert result.status == "COMPLETED_WITH_ERRORS" and result.exit_code == 2


def test_null_key_fail_file_policy(tmp_path):
    data = write_csv(tmp_path / "nulls.csv", HEADER, [["", "AL QAIDA", "", "", "", "", ""]])
    settings = load_settings(**{"data_quality.null_message_key_policy": "FAIL_FILE"})
    assert run_engine(tmp_path, data, country="IN", settings=settings).status == "FAILED_POLICY"


def test_missing_message_key_column_fails_cleanly(tmp_path):
    data = write_csv(tmp_path / "nokey.csv", ["TXN_ID", "BENEFICIARY_NAME"], [["1", "ABC"]])
    result = run_engine(tmp_path, data, country="IN")
    assert result.status == "FAILED" and result.exit_code == 1 and "MESSAGE_KEY" in result.error


def test_message_key_header_matched_canonically(tmp_path):
    data = write_csv(tmp_path / "loose.csv", [" Message Key", "BENEFICIARY_NAME"], [["K1", "ABC Ltd"]])
    result = run_engine(tmp_path, data, country="IN")
    assert read_out(result, "alerts.csv").MESSAGE_KEY.tolist() == ["K1"]


def test_unexpected_columns_are_ignored_and_reported(tmp_path):
    data = write_csv(tmp_path / "extra.csv", ["MESSAGE_KEY", "BENEFICIARY_NAME", "SOMETHING_ELSE", "ABC"],
                     [["K1", "Ravi", "ABC", "ABC"]])
    result = run_engine(tmp_path, data, country="IN")
    assert read_out(result, "alerts.csv").empty                     # ABC only in unmapped columns
    schema = read_out(result, "schema_validation_report.csv")
    assert {"SOMETHING_ELSE", "ABC"} <= set(schema[schema.STATUS == "UNMAPPED_COLUMN"].PHYSICAL_COLUMNS)


def test_missing_values_in_searched_columns(tmp_path):
    data = write_csv(tmp_path / "gaps.csv", HEADER, [["K1", "", "", "", "", "", ""],
                                                     ["K2", "ABC Ltd", "", "", "", "", ""]])
    result = run_engine(tmp_path, data, country="IN")
    assert read_out(result, "alerts.csv").MESSAGE_KEY.tolist() == ["K2"]
    dq = read_out(result, "data_quality_report.csv")
    rate = dq[(dq.CHECK == "SEARCHED_COLUMN_EMPTY_RATE") & (dq.COLUMN == "BENEFICIARY_NAME")]
    assert rate.COUNT.item() == "1"


def test_cp1252_file_is_decoded(tmp_path):
    data = write_csv(tmp_path / "latin.csv", HEADER, [["K1", "Société ABC Exports", "", "", "", "", ""]],
                     encoding="cp1252")
    result = run_engine(tmp_path, data, country="IN")
    alerts = read_out(result, "alerts.csv")
    assert alerts.ORIGINAL_VALUE.tolist() == ["Société ABC Exports"]
    assert result.summary["input"]["encoding"] == "cp1252"


def test_late_decoding_error_falls_back(tmp_path):
    good = [["K%d" % i, "Ravi Das", "", "", "", "", ""] for i in range(5000)]
    path = write_csv(tmp_path / "late.csv", HEADER, good)
    with open(path, "ab") as handle:                      # invalid UTF-8 far beyond the 4 MB sniff window
        handle.write(b"K9999,ABC \xe9tudes,,,,,\n")
    settings = load_settings(**{"input.encoding_fallbacks": ["utf-8", "cp1252"]})
    result = run_engine(tmp_path, path, country="IN", settings=settings)
    assert result.status.startswith("COMPLETED")
    assert result.summary["processing"]["rows_read"] == 5001


@pytest.mark.parametrize("reader", ["pyarrow", "pandas"])
def test_malformed_records_are_reported_not_dropped_silently(tmp_path, reader):
    path = tmp_path / "bad.csv"
    path.write_text("MESSAGE_KEY,BENEFICIARY_NAME\nK1,ABC Ltd\nK2,too,many,fields\nK3,Ravi\n", encoding="utf-8")
    settings = load_settings(**{"input.reader_backend": reader})
    result = run_engine(tmp_path, path, country="IN", settings=settings)
    errors = read_out(result, "errors.csv")
    assert (errors.ERROR_CODE == "MALFORMED_RECORD").sum() == 1
    assert result.summary["processing"]["rows_read"] == 2
    dq = read_out(result, "data_quality_report.csv")
    assert dq[dq.CHECK == "MALFORMED_RECORDS"].COUNT.item() == "1"


@needs_pyarrow
def test_short_rows_are_flagged_by_the_default_reader(tmp_path):
    path = tmp_path / "short.csv"
    path.write_text("MESSAGE_KEY,BENEFICIARY_NAME,PAYMENT_DETAILS\nK1,ABC Ltd,X\nK2,AL QAIDA\nK3,Ravi,\n",
                    encoding="utf-8")
    result = run_engine(tmp_path, path, country="IN", settings=load_settings(**{"input.reader_backend": "pyarrow"}))
    errors = read_out(result, "errors.csv")
    assert (errors.ERROR_CODE == "MALFORMED_RECORD").sum() == 1
    assert "K2,AL QAIDA" in errors[errors.ERROR_CODE == "MALFORMED_RECORD"].DETAIL.item()


def test_headers_written_exactly_once_across_many_chunks(tmp_path):
    rows = [[f"K{i}", "ABC Ltd" if i % 2 else "Ravi Das", "", "", "", "", ""] for i in range(25)]
    data = write_csv(tmp_path / "many.csv", HEADER, rows)
    result = run_engine(tmp_path, data, country="IN", chunk_size=4)
    for name in ("alerts.csv", "monitoring_audit.csv", "alerted_transactions.csv"):
        lines = (result.output_dir / name).read_text().splitlines()
        assert sum(1 for line in lines if line.startswith("DECISION_ID") or line.startswith("MESSAGE_KEY,ROW")) == 1
    assert len(read_out(result, "alerts.csv")) == 12
    assert result.summary["input"]["chunks"] == 7


def test_every_output_record_carries_message_key(tmp_path):
    data = write_csv(tmp_path / "keys.csv", HEADER, rows_with_duplicate())
    result = run_engine(tmp_path, data, country="IN")
    for name in ("alerts.csv", "excluded_matches.csv", "monitoring_audit.csv", "alerted_transactions.csv"):
        frame = read_out(result, name)
        assert frame.empty or (frame.MESSAGE_KEY != "").all()

"""Shared fixtures and helpers for the test suite."""
from __future__ import annotations

import csv
import logging
import sys
from pathlib import Path
from typing import Iterable, List, Optional, Sequence

import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.ingestion.transaction_reader import pyarrow_available  # noqa: E402
from src.matching.fuzzy_matcher import rapidfuzz_available  # noqa: E402
from src.monitoring_engine import MonitoringEngine, RunResult  # noqa: E402
from src.settings import Settings  # noqa: E402
from tools.build_sample_config import (INTEL_ROWS, P1_ROWS, P2_COLUMNS, P2_ROWS,  # noqa: E402
                                       build_mapping_workbook)

CONFIG = ROOT / "config"
SAMPLES = ROOT / "data" / "sample"
SCHEMAS = CONFIG / "schemas"

logging.getLogger("tm").setLevel(logging.WARNING)

HAS_RAPIDFUZZ = rapidfuzz_available()
HAS_PYARROW = pyarrow_available()
needs_rapidfuzz = pytest.mark.skipif(not HAS_RAPIDFUZZ, reason="rapidfuzz not installed (FUZZY matching)")
needs_pyarrow = pytest.mark.skipif(not HAS_PYARROW, reason="pyarrow not installed (strict CSV reader)")


def load_settings(**overrides) -> Settings:
    """Project settings with dotted overrides, e.g. load_settings(**{"input.chunk_size": 3})."""
    settings = Settings.load(CONFIG / "settings.yaml")
    if not HAS_RAPIDFUZZ:     # minimal environments: run the sample config with FUZZY rules downgraded
        settings.matching.fuzzy_unavailable_policy = "DOWNGRADE_TO_TOKEN"
    for dotted, value in overrides.items():
        section, _, key = dotted.partition(".")
        target = getattr(settings, section) if key else settings
        setattr(target, key or section, value)
    return settings


def write_csv(path: Path, header: Sequence[str], rows: Iterable[Sequence], encoding: str = "utf-8") -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding=encoding, newline="") as handle:
        writer = csv.writer(handle, lineterminator="\n")
        writer.writerow(header)
        writer.writerows(rows)
    return path


def make_mapping(tmp_path: Path, p1=None, p2=None, intel=None, p2_columns=None, name="mapping.xlsx", **kw) -> Path:
    return build_mapping_workbook(tmp_path / name, p1 if p1 is not None else P1_ROWS,
                                  p2 if p2 is not None else P2_ROWS, p2_columns or P2_COLUMNS,
                                  intel if intel is not None else INTEL_ROWS, **kw)


def p2_row(rt, keyword, message, rules="", status="ACTIVE", match_type="TOKEN", threshold="", rule_id=""):
    return [rule_id, rt, keyword, message, rules, status, match_type, threshold]


def run_engine(tmp_path: Path, input_csv: Path, mapping: Optional[Path] = None, schema: Path = SCHEMAS,
               settings: Optional[Settings] = None, country: Optional[str] = None, **run_kw) -> RunResult:
    settings = settings or load_settings()
    settings.output.run_subdirectory = False
    engine = MonitoringEngine(mapping or (CONFIG / "mapping.xlsx"), schema, settings=settings)
    out = tmp_path / f"out_{input_csv.stem}_{len(list(tmp_path.glob('out_*')))}"
    return engine.run(input_csv, out, country=country, **run_kw)


def read_out(result: RunResult, name: str) -> pd.DataFrame:
    path = result.output_dir / name
    if not path.exists():
        return pd.DataFrame()
    return pd.read_csv(path, dtype=str, keep_default_na=False)


def decisions(result: RunResult) -> List[tuple]:
    """(MESSAGE_KEY, KEYWORD, PHYSICAL_COLUMN, FINAL_DECISION) sorted - easy to assert on."""
    audit = read_out(result, "monitoring_audit.csv")
    if audit.empty:
        return []
    return sorted(zip(audit.MESSAGE_KEY, audit.KEYWORD, audit.PHYSICAL_COLUMN, audit.FINAL_DECISION))


@pytest.fixture
def settings() -> Settings:
    return load_settings()

"""Country resolution strategies and P1 eligibility filtering."""
from __future__ import annotations

from pathlib import Path

import pandas as pd
import pytest

from conftest import read_out, run_engine, write_csv
from src.exceptions import ConfigurationError
from src.schema.country_resolver import CountryResolver
from src.settings import CountryResolutionSettings

HEADER = ["MESSAGE_KEY", "COUNTRY", "BENEFICIARY_NAME"]


def resolver(header=HEADER, path="file.csv", cli=None, **kw):
    return CountryResolver(CountryResolutionSettings(**kw), header, Path(path), cli)


def resolve(r, values):
    return r.resolve_chunk(pd.DataFrame({"COUNTRY": values, "MESSAGE_KEY": "k"})).tolist()


def test_cli_country_wins_and_conflicts_are_reported():
    r = resolver(cli="in")
    assert resolve(r, ["IN", "US", ""]) == ["IN", "IN", "IN"]
    assert r.conflicts == {"US->IN": 1}


def test_column_strategy_with_aliases_and_namibia():
    r = resolver()
    assert resolve(r, ["IN", " us", "UK", "NA", "XX", ""]) == ["IN", "US", "GB", "NA", "", ""]
    assert r.invalid_values == {"XX": 1}


def test_file_pattern_strategy():
    r = resolver(header=["MESSAGE_KEY", "BENEFICIARY_NAME"], path="/data/india_transactions.csv",
                 file_patterns=[{"pattern": "india_*.csv", "country": "IN"}])
    assert r.available_strategies() == ["file_pattern"] and r.is_file_level()


def test_column_then_fallback_fills_blanks():
    r = resolver(path="usa_2026.csv", file_patterns=[{"pattern": "usa_*.csv", "country": "US"}])
    assert resolve(r, ["GB", "", "XX"]) == ["GB", "US", "US"]


def test_order_is_configurable():
    r = resolver(cli="IN", order=["column", "cli"])
    assert resolve(r, ["GB", ""]) == ["GB", "IN"]


def test_default_country_and_unresolvable_configuration():
    assert resolver(header=["MESSAGE_KEY"], default_country="AE").available_strategies() == ["default"]
    with pytest.raises(ConfigurationError):
        resolver(header=["MESSAGE_KEY"]).ensure_resolvable()
    with pytest.raises(ConfigurationError):
        resolver(cli="ZZ")


def test_p1_filtering_end_to_end(tmp_path):
    rows = [["M1", "IN", "Jihad Relief Foundation"],      # Scenario 2 eligible for IN
            ["M2", "US", "Jihad Relief Foundation"],      # Scenario 2 not configured for US
            ["M3", "JP", "ABC International Limited"],    # no scenario for JP
            ["M4", "XX", "ABC International Limited"]]    # unresolvable
    data = write_csv(tmp_path / "mixed.csv", HEADER, rows)
    result = run_engine(tmp_path, data)
    alerts = read_out(result, "alerts.csv")
    assert alerts.MESSAGE_KEY.tolist() == ["M1"]
    p = result.summary["processing"]
    assert (p["rows_screened"], p["rows_not_eligible"], p["rows_country_unresolved"]) == (2, 1, 1)
    errors = read_out(result, "errors.csv")
    assert errors[errors.ERROR_CODE == "COUNTRY_UNRESOLVED"].MESSAGE_KEY.tolist() == ["M4"]


def test_country_only_on_command_line(tmp_path):
    data = write_csv(tmp_path / "nocountry.csv", ["MESSAGE_KEY", "BENEFICIARY_NAME"], [["K1", "ABC Ltd"]])
    assert read_out(run_engine(tmp_path, data, country="IN"), "alerts.csv").MESSAGE_KEY.tolist() == ["K1"]
    failed = run_engine(tmp_path, data)
    assert failed.status == "FAILED" and "country" in failed.error.lower()

"""Context classifiers: IndividualClassifier and intelligence-list classifiers."""
from __future__ import annotations

import pytest

from conftest import CONFIG
from src.context.individual_classifier import IndividualClassifier
from src.context.intelligence_classifier import IntelligenceListClassifier
from src.context.toponym_classifier import ToponymClassifier
from src.models import IntelligenceEntry, MatchContext
from src.normalization.text_normalizer import TextNormalizer
from src.settings import IndividualSettings

N = TextNormalizer()


@pytest.fixture(scope="module")
def individual():
    return IndividualClassifier.from_file(CONFIG / "reference" / "individual_indicators.yaml", N,
                                          IndividualSettings())


def ctx(value, keyword, field="BENEFICIARY", country="IN", column="BENEFICIARY_NAME"):
    norm = N.normalize(value)
    kw = N.normalize(keyword)
    start = f" {norm} ".index(f" {kw} ")
    return MatchContext(country, "Scenario 1", kw, field, column, value, norm, start, start + len(kw))


@pytest.mark.parametrize("value, keyword, expected", [
    ("Jihad Ahmed Khan", "JIHAD", "INDIVIDUAL"),
    ("Mr Mujahid Hussain", "MUJAHID", "INDIVIDUAL"),
    ("Sunita Shaheed", "SHAHEED", "INDIVIDUAL"),
    ("Jihad Relief Foundation", "JIHAD", "BUSINESS_ENTITY"),
    ("ABC International Limited", "ABC", "BUSINESS_ENTITY"),
    ("Mujahid Trading Co", "MUJAHID", "BUSINESS_ENTITY"),
    ("ABC", "ABC", "NOT_INDIVIDUAL"),
])
def test_individual_classification(individual, value, keyword, expected):
    result = individual.classify(ctx(value, keyword))
    assert result.classification == expected
    assert result.matched is (expected == "INDIVIDUAL")
    assert 0.0 <= result.confidence <= 1.0 and result.reason and result.source


def test_first_name_last_name_shape_alone_is_not_definitive(individual):
    result = individual.classify(ctx("ABC Kumar", "ABC"))
    assert not result.matched
    assert result.evidence["p_individual"] < 0.75


def test_country_specific_titles(individual):
    india = individual.classify(ctx("Shri ABC Kumar", "ABC", country="IN"))
    uk = individual.classify(ctx("Shri ABC Kumar", "ABC", country="GB"))
    gulf = individual.classify(ctx("Sheikh Mujahid Al Mansoori", "MUJAHID", country="AE"))
    assert india.matched and not uk.matched and gulf.matched
    assert "title 'shri'" in india.reason


def test_free_text_fields_need_strong_person_evidence(individual):
    titled = individual.classify(ctx("PAYMENT TO MR JIHAD KHAN FOR RENT", "JIHAD", field="DESCRIPTION",
                                     column="PAYMENT_DETAILS"))
    bare = individual.classify(ctx("DONATION FOR JIHAD", "JIHAD", field="DESCRIPTION", column="PAYMENT_DETAILS"))
    assert titled.matched and titled.evidence["mode"] == "WINDOW"
    assert not bare.matched


def test_relationship_marker(individual):
    result = individual.classify(ctx("ABC S/O RAMESH KUMAR", "ABC"))
    assert result.matched and "relationship marker" in result.reason


def test_explanation_lists_every_signal(individual):
    result = individual.classify(ctx("ABC International Limited", "ABC"))
    signals = {s["signal"] for s in result.evidence["signals"]}
    assert {"organisation_suffix", "organisation_keyword"} <= signals
    assert "limited" in result.reason


# --------------------------------------------------------------------------- intelligence lists
def entries(*values, list_name="Toponym"):
    return [IntelligenceEntry(list_name, v, N.normalize(v), i + 2) for i, v in enumerate(values)]


def test_toponym_contains_policy():
    clf = ToponymClassifier(entries("ABC Nagar", "XYZ Road"), "TOPONYM", "Toponym", "CONTAINS")
    covered = clf.classify(ctx("Flat 4, 12 ABC Nagar, Pune", "ABC", field="ADDRESS"))
    assert covered.matched and covered.classification == "TOPONYM"
    assert covered.evidence["intelligence_value"] == "ABC Nagar" and covered.evidence["intelligence_row"] == 2
    assert covered.confidence == 1.0


def test_only_the_covered_occurrence_is_excluded():
    clf = ToponymClassifier(entries("ABC Nagar"), "TOPONYM", "Toponym", "CONTAINS")
    value = "ABC TRADING, ABC NAGAR"
    norm = N.normalize(value)
    first = MatchContext("IN", "S1", "abc", "ADDRESS", "ADDR", value, norm, 0, 3)
    second_start = norm.index("abc nagar")
    second = MatchContext("IN", "S1", "abc", "ADDRESS", "ADDR", value, norm, second_start, second_start + 3)
    assert not clf.classify(first).matched
    assert clf.classify(second).matched


@pytest.mark.parametrize("policy, value_list, expected", [
    ("CONTAINS", ["ABC Nagar"], True),
    ("EXACT_SPAN", ["ABC Nagar"], False),
    ("EXACT_SPAN", ["ABC"], True),
    ("OVERLAPS", ["NAGAR ABC"], False),
])
def test_span_policies(policy, value_list, expected):
    clf = IntelligenceListClassifier(entries(*value_list), "TOPONYM", "Toponym", policy)
    assert clf.classify(ctx("12 ABC Nagar Pune", "ABC", field="ADDRESS")).matched is expected


def test_overlap_policy_is_looser_than_contains():
    contains = IntelligenceListClassifier(entries("STATE STREET"), "TOPONYM", "Toponym", "CONTAINS")
    overlaps = IntelligenceListClassifier(entries("STATE STREET"), "TOPONYM", "Toponym", "OVERLAPS")
    c = ctx("ISLAMIC STATE STREET", "ISLAMIC STATE", field="ADDRESS")
    assert not contains.classify(c).matched
    assert overlaps.classify(c).matched

"""100,000-row file: chunked processing at scale, large chunks, and chunk-size invariance."""
from __future__ import annotations

import json

import pytest

from conftest import read_out, run_engine
from benchmarks.synthetic import build_config, generate


@pytest.fixture(scope="module")
def synthetic(tmp_path_factory):
    work = tmp_path_factory.mktemp("synthetic")
    mapping = build_config(work, n_rules=2_000)
    keywords = json.load(open(work / "benchmark_keywords.json"))
    data = generate(work / "tx_100000_IN.csv", 100_000, keywords["keywords"], keywords["fuzzy"], hit_rate=0.01)
    return mapping, data


def test_100k_rows_end_to_end(tmp_path, synthetic):
    mapping, data = synthetic
    result = run_engine(tmp_path, data, mapping=mapping, country="IN", chunk_size=25_000)
    p = result.summary["processing"]
    assert p["rows_read"] == 100_000 and result.summary["input"]["chunks"] == 4
    assert p["alerts"] > 100 and p["exclusions"] > 0
    assert result.summary["performance"]["rows_per_second"] > 5_000      # very loose floor (CI machines vary)


def test_large_chunk_gives_same_decisions(tmp_path, synthetic):
    mapping, data = synthetic
    small = read_out(run_engine(tmp_path, data, mapping=mapping, country="IN", chunk_size=25_000),
                     "monitoring_audit.csv")
    large = read_out(run_engine(tmp_path, data, mapping=mapping, country="IN", chunk_size=500_000),
                     "monitoring_audit.csv")
    assert sorted(zip(small.DECISION_ID, small.FINAL_DECISION)) == sorted(zip(large.DECISION_ID,
                                                                              large.FINAL_DECISION))

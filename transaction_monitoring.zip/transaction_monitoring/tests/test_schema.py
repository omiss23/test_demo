"""Dynamic schema layer: profiles, ColumnResolver and the four configuration formats."""
from __future__ import annotations

import json
import sqlite3

import pandas as pd
import pytest
import yaml

from conftest import SCHEMAS
from src.schema.column_resolver import ColumnResolver
from src.schema.schema_registry import SqlSchemaLoader, load_schema_registry
from src.settings import SchemaSettings
from tools.build_sample_config import build_schema_workbook, schema_rows_from_profiles

IN_HEADER = ["MESSAGE_KEY", "BENEFICIARY_NAME", "BENEFICIARY_ACCOUNT", "ORIGINATOR_NAME", "BENEFICIARY_ADDRESS",
             "ORIGINATOR_ADDRESS", "PAYMENT_DETAILS"]
US_HEADER = ["MESSAGE_KEY", "BNF_NM", "BNF_ACCT", "ORG_NM", "BNF_ADDR", "ORG_ADDR", "OBI"]
GB_HEADER = ["MESSAGE_KEY", "CREDITOR", "DEBTOR", "CREDITOR_ADDRESS", "DEBTOR_ADDRESS", "REMITTANCE_INFO"]
AE_HEADER = ["MESSAGE_KEY", "BENE_NAME", "ORDERING_CUSTOMER", "BENE_ADDRESS_LINE_1", "BENE_ADDRESS_LINE_2",
             "BENE_CITY", "ORD_ADDRESS_LINE_1", "ORD_CITY", "PAYMENT_PURPOSE"]


@pytest.fixture(scope="module")
def registry():
    reg, issues = load_schema_registry(SCHEMAS)
    assert issues == []
    return reg


@pytest.fixture
def resolver(registry):
    return ColumnResolver(registry, SchemaSettings())


def test_india_schema(resolver):
    assert resolver.resolve("IN", "BENEFICIARY", IN_HEADER) == ["BENEFICIARY_NAME"]
    assert resolver.resolve("IN", "ORIGINATOR", IN_HEADER) == ["ORIGINATOR_NAME"]
    assert resolver.resolve("IN", "ADDRESS", IN_HEADER) == ["BENEFICIARY_ADDRESS", "ORIGINATOR_ADDRESS"]


def test_us_schema(resolver):
    assert resolver.resolve("US", "BENEFICIARY", US_HEADER) == ["BNF_NM"]
    assert resolver.resolve("US", "ADDRESS", US_HEADER) == ["BNF_ADDR", "ORG_ADDR"]
    assert resolver.resolve("US", "DESCRIPTION", US_HEADER) == ["OBI"]


def test_gb_schema(resolver):
    assert resolver.resolve("GB", "BENEFICIARY", GB_HEADER) == ["CREDITOR"]
    assert resolver.resolve("GB", "ORIGINATOR", GB_HEADER) == ["DEBTOR"]


def test_multiple_physical_columns_per_logical_field(resolver):
    assert resolver.resolve("AE", "ADDRESS", AE_HEADER) == [
        "BENE_ADDRESS_LINE_1", "BENE_ADDRESS_LINE_2", "BENE_CITY", "ORD_ADDRESS_LINE_1", "ORD_CITY"]
    res = resolver.resolve_detailed("AE", "ADDRESS", AE_HEADER)
    assert res.missing_candidates == ["BENE_STATE", "BENE_POSTAL_CODE", "ORD_ADDRESS_LINE_2"]


def test_automatic_discovery_from_alias_list(resolver):
    """DEFAULT lists several aliases; whichever exists is found (here SG has no own profile)."""
    assert resolver.resolve("SG", "BENEFICIARY", ["MESSAGE_KEY", "BNF_NM"]) == ["BNF_NM"]


def test_missing_columns_raise_schema_mapping_error_with_suggestions(registry):
    resolver = ColumnResolver(registry, SchemaSettings(fallback_to_default_profile=False))
    res = resolver.resolve_detailed("US", "BENEFICIARY", ["MESSAGE_KEY", "BNF_NAME", "ORG_NM"])
    assert res.status == "SCHEMA_MAPPING_ERROR" and res.physical_columns == []
    assert any(s.startswith("BNF_NAME") for s in res.suggestions)


def test_fuzzy_suggestions_are_never_applied(resolver):
    """BENEFICIARY_ACCOUNT / BENEFICIARY_BANK must never stand in for BENEFICIARY."""
    header = ["MESSAGE_KEY", "BENEFICIARY_ACCOUNT", "BENEFICIARY_BANK"]
    res = resolver.resolve_detailed("IN", "BENEFICIARY", header)
    assert res.physical_columns == [] and res.status == "SCHEMA_MAPPING_ERROR"


def test_unknown_logical_field_reported_with_suggestion(resolver):
    res = resolver.resolve_detailed("IN", "BENEFICARY", IN_HEADER)
    assert res.status == "UNKNOWN_LOGICAL_FIELD"
    assert res.suggestions and res.suggestions[0].startswith("BENEFICIARY")


def test_identity_mapping_is_exact_and_switchable(registry):
    header = IN_HEADER + ["SWIFT_NARRATIVE"]
    on = ColumnResolver(registry, SchemaSettings(allow_identity_mapping=True)).resolve_detailed(
        "IN", "SWIFT_NARRATIVE", header)
    assert on.physical_columns == ["SWIFT_NARRATIVE"] and on.methods == ["IDENTITY"]
    off = ColumnResolver(registry, SchemaSettings(allow_identity_mapping=False)).resolve_detailed(
        "IN", "SWIFT_NARRATIVE", header)
    assert off.status == "UNKNOWN_LOGICAL_FIELD"


def test_canonical_header_matching(resolver):
    res = resolver.resolve_detailed("IN", "BENEFICIARY", ["MESSAGE_KEY", "Beneficiary Name"])
    assert res.physical_columns == ["Beneficiary Name"] and res.methods == ["CANONICAL"]


def test_ambiguous_canonical_headers_are_not_guessed(resolver):
    res = resolver.resolve_detailed("US", "BENEFICIARY", ["MESSAGE_KEY", "Bnf Nm", "BNF-NM"])
    assert res.status == "AMBIGUOUS_COLUMN" and res.physical_columns == []


def test_default_fallback_is_reported(resolver):
    res = resolver.resolve_detailed("US", "BENEFICIARY", ["MESSAGE_KEY", "BENEFICIARY_NAME"])
    assert res.physical_columns == ["BENEFICIARY_NAME"]
    assert res.methods == ["EXACT+DEFAULT_FALLBACK"] and "DEFAULT" in res.detail


def test_first_resolution_mode(tmp_path):
    (tmp_path / "IN.yaml").write_text(yaml.safe_dump({
        "country": "IN", "fields": {"BENEFICIARY": {"columns": ["BENE_A", "BENE_B"], "resolution": "FIRST"}}}))
    registry, _ = load_schema_registry(tmp_path)
    resolver = ColumnResolver(registry, SchemaSettings())
    assert resolver.resolve("IN", "BENEFICIARY", ["BENE_B", "BENE_A"]) == ["BENE_A"]


def test_excel_yaml_json_and_sql_sources_are_equivalent(tmp_path, registry):
    rows = schema_rows_from_profiles(SCHEMAS)
    excel, _ = load_schema_registry(build_schema_workbook(tmp_path / "schema.xlsx", rows))
    profiles = [{"country": pid, "fields": {lf: {"columns": list(m.candidates), "resolution": m.resolution}
                                            for lf, m in p.fields.items()}}
                for pid, p in registry.profiles.items()]
    (tmp_path / "schema.json").write_text(json.dumps({"profiles": profiles}))
    js, _ = load_schema_registry(tmp_path / "schema.json")
    conn = sqlite3.connect(":memory:")
    pd.DataFrame(rows).to_sql("schema_mapping", conn, index=False)
    sql, _ = SqlSchemaLoader(conn).load()
    for other in (excel, js, sql):
        for header, country in [(IN_HEADER, "IN"), (US_HEADER, "US"), (GB_HEADER, "GB"), (AE_HEADER, "AE")]:
            for logical in ("BENEFICIARY", "ORIGINATOR", "ADDRESS", "DESCRIPTION"):
                assert (ColumnResolver(other).resolve(country, logical, header) ==
                        ColumnResolver(registry).resolve(country, logical, header)), (country, logical)


def test_invalid_schema_rows_are_reported(tmp_path):
    rows = [{"COUNTRY": "IN", "LOGICAL_FIELD": "BENEFICIARY", "PHYSICAL_COLUMN": "", "PRIORITY": 1,
             "RESOLUTION": "ALL", "STATUS": "ACTIVE"},
            {"COUNTRY": "IN", "LOGICAL_FIELD": "ADDRESS", "PHYSICAL_COLUMN": "ADDR1", "PRIORITY": 1,
             "RESOLUTION": "ALL", "STATUS": "ACTIVE"},
            {"COUNTRY": "IN", "LOGICAL_FIELD": "ADDRESS", "PHYSICAL_COLUMN": "ADDR2", "PRIORITY": 2,
             "RESOLUTION": "FIRST", "STATUS": "ACTIVE"},
            {"COUNTRY": "IN", "LOGICAL_FIELD": "ORIGINATOR", "PHYSICAL_COLUMN": "ORG", "PRIORITY": "x",
             "RESOLUTION": "", "STATUS": "INACTIVE"}]
    registry, issues = load_schema_registry(build_schema_workbook(tmp_path / "bad.xlsx", rows))
    found = {i.code for i in issues}
    assert {"INCOMPLETE_SCHEMA_ROW", "CONFLICTING_RESOLUTION"} <= found
    assert "ORIGINATOR" not in registry.profiles["IN"].fields      # INACTIVE row ignored

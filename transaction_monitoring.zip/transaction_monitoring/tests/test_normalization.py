"""Stage-1 normalisation: case, punctuation, accents, Unicode, batch equivalence."""
from __future__ import annotations

import math
import random
import string

import pytest

from src.normalization.text_normalizer import TextNormalizer

N = TextNormalizer()


@pytest.mark.parametrize("raw, expected", [
    ("ABC International Limited", "abc international limited"),
    ("  ABC,   Intl.\tLtd\n", "abc intl ltd"),
    ("AL-QAIDA", "al qaida"),
    ("Al_Qaida/Support", "al qaida support"),
    ("S/O RAMESH", "s o ramesh"),
    ("Qa'ida", "qaida"),
    ("Qa’ida", "qaida"),
    ("Société Générale", "societe generale"),
    ("STRASSE Ä", "strasse a"),
    ("Straße", "strasse"),
    ("ﬁnance", "finance"),
    ("جِهَاد", "جهاد"),   # Arabic harakat removed, letters kept
    ("", ""),
    ("---", ""),
])
def test_normalize(raw, expected):
    assert N.normalize(raw) == expected


def test_none_and_nan():
    assert N.normalize(None) == ""
    assert N.normalize(math.nan) == ""
    assert N.normalize(12345) == "12345"


def test_token_spans():
    assert TextNormalizer.token_spans("abc de f") == [(0, 3), (4, 6), (7, 8)]


def test_batch_normalisation_matches_per_value():
    rng = random.Random(7)
    alphabet = string.printable + "éÉçßİ’‘`'\x00ـّﬁ  "
    for _ in range(200):
        values = ["".join(rng.choice(alphabet) for _ in range(rng.randint(0, 30)))
                  for _ in range(rng.randint(1, 50))]
        assert N.normalize_many(values) == [N.normalize(v) for v in values]


def test_batch_with_only_ascii_fast_path():
    values = ["ABC Ltd", "", "  x  ", "A-B", "123"]
    assert N.normalize_many(values) == ["abc ltd", "", "x", "a b", "123"]

"""Chunked, memory-bounded CSV reader.

* Never loads the whole file: `iter_chunks` yields DataFrames of `chunk_size` rows.
* Reads only the columns the search plan needs (`usecols`).
* Everything is read as text with NA-detection switched off, so values like
  'NA' (Namibia), 'NULL' or '0012' arrive exactly as written; empty cells are ''.
* Encoding: BOM detection, then a strict trial decode of the first 4 MB; the
  engine falls back through `encoding_fallbacks` if a later byte fails.
* Malformed records (wrong number of fields) are skipped by the parser but
  captured and reported - never silently dropped.
"""
from __future__ import annotations

import codecs
import contextlib
import csv
import io
import re
import warnings
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterator, List, Optional, Sequence, Tuple

import pandas as pd

from ..exceptions import InputFileError
from ..settings import InputSettings

_BAD_LINE_RE = re.compile(r"Skipping line (\d+): (.+)")


@dataclass
class MalformedRecord:
    parser_line: int
    detail: str


@dataclass
class ReaderInfo:
    path: Path
    encoding: str
    delimiter: str
    header: List[str] = field(default_factory=list)
    duplicate_header_names: List[str] = field(default_factory=list)
    size_bytes: int = 0


class TransactionReader:
    def __init__(self, path: Path, settings: InputSettings):
        self.path = Path(path)
        self.settings = settings
        if not self.path.exists():
            raise InputFileError(f"Input file not found: {self.path}")
        if self.path.stat().st_size == 0:
            raise InputFileError(f"Input file is empty: {self.path}")
        self.encoding = self.detect_encoding()
        self.info = ReaderInfo(self.path, self.encoding, settings.delimiter, size_bytes=self.path.stat().st_size)
        self._read_header()

    # ------------------------------------------------------------------ #
    def detect_encoding(self) -> str:
        if self.settings.encoding and self.settings.encoding.lower() != "auto":
            return self.settings.encoding
        with open(self.path, "rb") as handle:
            sample = handle.read(4 * 1024 * 1024)
        if sample.startswith(codecs.BOM_UTF8):
            return "utf-8-sig"
        if sample.startswith(codecs.BOM_UTF16_LE) or sample.startswith(codecs.BOM_UTF16_BE):
            return "utf-16"
        for encoding in self.settings.encoding_fallbacks:
            try:
                codecs.getincrementaldecoder(encoding)().decode(sample, final=False)
                return encoding
            except (UnicodeDecodeError, LookupError):
                continue
        return "latin-1"   # decodes any byte sequence

    def set_encoding(self, encoding: str) -> None:
        self.encoding = encoding
        self.info.encoding = encoding
        self._read_header()

    def _read_header(self) -> None:
        try:
            with open(self.path, "r", encoding=self.encoding, newline="") as handle:
                first = next(csv.reader(handle, delimiter=self.settings.delimiter), [])
        except UnicodeDecodeError as exc:
            raise InputFileError(f"Header of {self.path} cannot be decoded as {self.encoding}: {exc}") from exc
        raw = [h.strip() for h in first]
        seen, dups = set(), []
        for name in raw:
            if name in seen and name not in dups:
                dups.append(name)
            seen.add(name)
        # pandas' own view of the header (duplicate names are mangled to NAME.1)
        frame = pd.read_csv(self.path, nrows=0, encoding=self.encoding, sep=self.settings.delimiter, dtype=str)
        self.info.header = [str(c) for c in frame.columns]
        self.info.duplicate_header_names = dups

    @property
    def header(self) -> List[str]:
        return self.info.header

    # ------------------------------------------------------------------ #
    @property
    def backend(self) -> str:
        """pyarrow (multi-threaded C++ streaming parser, ~6x faster - see docs/BENCHMARK.md) when
        installed, else the pandas C parser. Both yield identical DataFrames (tested)."""
        wanted = (self.settings.reader_backend or "auto").lower()
        if wanted in ("auto", "pyarrow") and pyarrow_available() and not self.info.duplicate_header_names:
            return "pyarrow"
        return "pandas"

    def iter_chunks(self, usecols: Optional[Sequence[str]] = None, chunk_size: Optional[int] = None,
                    ) -> Iterator[Tuple[pd.DataFrame, List[MalformedRecord]]]:
        """Yield (chunk, malformed_records_seen_while_reading_this_chunk); exactly chunk_size rows per chunk."""
        if self.backend == "pyarrow":
            return self._iter_pyarrow(usecols, chunk_size)
        return self._iter_pandas(usecols, chunk_size)

    def _iter_pyarrow(self, usecols, chunk_size) -> Iterator[Tuple[pd.DataFrame, List[MalformedRecord]]]:
        import pyarrow as pa
        import pyarrow.csv as pacsv

        size = int(chunk_size or self.settings.chunk_size)
        columns = list(usecols) if usecols is not None else list(self.header)
        bad: List[MalformedRecord] = []

        def on_invalid(row) -> str:
            line = row.number if row.number is not None else -1
            text = (row.text or "")[:120]
            bad.append(MalformedRecord(line, f"expected {row.expected_columns} fields, saw {row.actual_columns}: "
                                             f"{text}"))
            return "skip"

        encoding = {"utf-8": "utf8", "utf-8-sig": "utf8", "utf8": "utf8"}.get(self.encoding.lower(), self.encoding)
        reader = pacsv.open_csv(
            self.path,
            read_options=pacsv.ReadOptions(encoding=encoding, block_size=8 << 20),
            parse_options=pacsv.ParseOptions(delimiter=self.settings.delimiter, newlines_in_values=True,
                                             invalid_row_handler=on_invalid),
            convert_options=pacsv.ConvertOptions(include_columns=columns,
                                                 column_types={c: pa.string() for c in columns},
                                                 strings_can_be_null=False, quoted_strings_can_be_null=False,
                                                 null_values=[]),
        )
        buffer: List = []
        buffered = 0
        try:
            for batch in reader:
                buffer.append(batch)
                buffered += batch.num_rows
                while buffered >= size:
                    table = pa.Table.from_batches(buffer)
                    head, rest = table.slice(0, size), table.slice(size)
                    records, bad[:] = list(bad), []
                    yield head.to_pandas(), records
                    buffer, buffered = rest.to_batches(), rest.num_rows
        except pa.ArrowInvalid as exc:
            if "utf8" in str(exc).lower() or "utf-8" in str(exc).lower():
                raise UnicodeDecodeError(self.encoding, b"", 0, 1, str(exc)) from exc
            raise
        if buffered or bad:
            table = pa.Table.from_batches(buffer) if buffer else None
            frame = table.to_pandas() if table is not None else pd.DataFrame(columns=columns)
            yield frame, list(bad)

    def _iter_pandas(self, usecols, chunk_size) -> Iterator[Tuple[pd.DataFrame, List[MalformedRecord]]]:
        """pandas C parser fallback.

        `usecols` is deliberately NOT passed to read_csv: with usecols, pandas silently
        accepts rows that have too many fields (it truncates them), which would screen a
        corrupted record. All columns are parsed so the field-count check applies, and the
        needed columns are selected afterwards. Known limitation: pandas pads rows with
        too FEW fields with blanks instead of flagging them (the pyarrow reader flags them).
        """
        size = int(chunk_size or self.settings.chunk_size)
        columns = list(usecols) if usecols is not None else None
        reader = pd.read_csv(
            self.path,
            sep=self.settings.delimiter,
            encoding=self.encoding,
            dtype=str,
            na_filter=False,          # 'NA', 'NULL', 'N/A' stay as text; empty -> ''
            chunksize=size,
            on_bad_lines="warn",
            engine="c",
        )
        with reader:
            while True:
                bad: List[MalformedRecord] = []
                stderr = io.StringIO()
                with warnings.catch_warnings(record=True) as caught, contextlib.redirect_stderr(stderr):
                    warnings.simplefilter("always")
                    try:
                        chunk = next(reader)
                    except StopIteration:
                        chunk = None
                for item in caught:
                    if issubclass(item.category, pd.errors.ParserWarning) or "Skipping line" in str(item.message):
                        bad.extend(_parse_bad_lines(str(item.message)))
                    else:  # unrelated warnings are re-emitted untouched
                        warnings.warn_explicit(item.message, item.category, item.filename, item.lineno)
                bad.extend(_parse_bad_lines(stderr.getvalue()))
                if chunk is None:
                    if bad:
                        yield pd.DataFrame(columns=columns or self.header), bad
                    return
                yield (chunk[columns] if columns is not None else chunk), bad


def pyarrow_available() -> bool:
    try:
        import pyarrow.csv  # noqa: F401

        return True
    except ImportError:
        return False


def _parse_bad_lines(text: str) -> List[MalformedRecord]:
    records = []
    for line in str(text).splitlines():
        match = _BAD_LINE_RE.search(line)
        if match:
            records.append(MalformedRecord(int(match.group(1)), match.group(2).strip()))
    return records

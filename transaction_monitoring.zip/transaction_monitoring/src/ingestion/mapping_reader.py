"""Read the mapping workbook (P1, P2, Intelligence_Lists) - I/O only.

Sheet and column names are matched canonically ('RT TYPE' == 'RT_TYPE' ==
'rt type'), every cell is read as text ('NA' for Namibia stays 'NA'), and the
Excel row number of every record is kept for traceability. Semantic checks
happen in validation/mapping_validator.py.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Optional

import pandas as pd

from ..exceptions import ConfigurationError
from ..utils import canonical_name, sha256_file, version_label

SHEET_ALIASES = {
    "P1": ("P1",),
    "P2": ("P2",),
    "INTELLIGENCE_LISTS": ("INTELLIGENCE_LISTS", "INTELLIGENCE_LIST", "INTELLIGENCE"),
}

COLUMN_ALIASES = {
    "P1": {"RT_TYPE": ("RT_TYPE", "RTTYPE", "SCENARIO"), "COUNTRIES": ("COUNTRIES", "COUNTRY", "ISO_CODES")},
    "P2": {
        "RT_TYPE": ("RT_TYPE", "RTTYPE", "SCENARIO"),
        "KEYWORD": ("KEYWORD", "KEYWORDS"),
        "MESSAGE": ("MESSAGE", "MESSAGE_FIELDS", "FIELDS", "LOGICAL_FIELDS"),
        "RULES": ("RULES", "RULE", "EXCLUSION_RULES"),
        "STATUS": ("STATUS",),
        # optional extensions
        "MATCH_TYPE": ("MATCH_TYPE", "MATCHTYPE"),
        "FUZZY_THRESHOLD": ("FUZZY_THRESHOLD", "THRESHOLD"),
        "RULE_ID": ("RULE_ID", "RULEID", "ID"),
    },
    "INTELLIGENCE_LISTS": {
        "LIST": ("LIST", "LIST_TYPE", "LIST_NAME"),
        "VALUE": ("VALUE", "VALUES"),
        "STATUS": ("STATUS",),
    },
}

REQUIRED_COLUMNS = {
    "P1": ("RT_TYPE", "COUNTRIES"),
    "P2": ("RT_TYPE", "KEYWORD", "MESSAGE", "RULES", "STATUS"),
    "INTELLIGENCE_LISTS": ("LIST", "VALUE", "STATUS"),
}


@dataclass
class RawMapping:
    path: Path
    sha256: str
    version: str
    declared_version: Optional[str]
    p1: pd.DataFrame                 # canonical columns + EXCEL_ROW
    p2: pd.DataFrame
    intelligence: pd.DataFrame
    sheet_names: Dict[str, str]      # logical sheet -> actual sheet name


class MappingReader:
    def __init__(self, path: Path):
        self.path = Path(path)

    def read(self) -> RawMapping:
        if not self.path.exists():
            raise ConfigurationError(f"Mapping workbook not found: {self.path}")
        try:
            book = pd.read_excel(self.path, sheet_name=None, dtype=str, keep_default_na=False)
        except Exception as exc:
            raise ConfigurationError(f"Cannot read mapping workbook {self.path}: {exc}") from exc
        by_canon = {canonical_name(name): (name, frame) for name, frame in book.items()}

        frames: Dict[str, pd.DataFrame] = {}
        sheet_names: Dict[str, str] = {}
        for logical, aliases in SHEET_ALIASES.items():
            found = next((by_canon[a] for a in aliases if a in by_canon), None)
            if found is None:
                raise ConfigurationError(
                    f"{self.path.name}: required sheet '{logical}' not found (sheets: {list(book)})")
            sheet_names[logical] = found[0]
            frames[logical] = self._canonical_frame(logical, found[0], found[1])

        declared = _metadata_version(by_canon.get("METADATA", (None, None))[1])
        sha = sha256_file(self.path)
        return RawMapping(self.path, sha, version_label(declared, sha), declared,
                          frames["P1"], frames["P2"], frames["INTELLIGENCE_LISTS"], sheet_names)

    def _canonical_frame(self, logical: str, sheet: str, frame: pd.DataFrame) -> pd.DataFrame:
        frame = frame.copy()
        renamed = {}
        canon_cols = {canonical_name(c): c for c in frame.columns}
        for target, aliases in COLUMN_ALIASES[logical].items():
            for alias in aliases:
                if alias in canon_cols:
                    renamed[canon_cols[alias]] = target
                    break
        frame = frame.rename(columns=renamed)
        missing = [c for c in REQUIRED_COLUMNS[logical] if c not in frame.columns]
        if missing:
            raise ConfigurationError(
                f"{self.path.name} sheet '{sheet}' is missing required column(s) {missing}; "
                f"found {list(frame.columns)}")
        keep = [c for c in COLUMN_ALIASES[logical] if c in frame.columns]
        frame = frame[keep].fillna("").astype(str)
        frame.insert(0, "EXCEL_ROW", range(2, len(frame) + 2))
        # drop rows that are entirely blank (common at the bottom of Excel sheets)
        content = frame[keep].apply(lambda col: col.str.strip() != "")
        frame = frame[content.any(axis=1)].reset_index(drop=True)
        return frame


def _metadata_version(frame: Optional[pd.DataFrame]) -> Optional[str]:
    if frame is None or frame.empty:
        return None
    frame = frame.fillna("").astype(str)
    frame.columns = [canonical_name(c) for c in frame.columns]
    if "KEY" in frame.columns and "VALUE" in frame.columns:
        for key, value in zip(frame["KEY"], frame["VALUE"]):
            if canonical_name(key) == "VERSION" and str(value).strip():
                return str(value).strip()
    return None

"""Stage 1 of matching: cheap, deterministic text normalisation.

The same normaliser is applied to keywords, intelligence values and
transaction values, so a keyword can only be missed because of genuine
spelling differences, never because of case, punctuation or accents.

Rules (in order):
1. Unicode NFKD (only for non-ASCII input; ASCII takes a fast path).
2. Case folding.
3. Apostrophes / quote marks are deleted ("Qa'ida" -> "qaida").
4. Combining marks (accents, Arabic harakat) are deleted when strip_accents=True.
5. Every other character that is not a letter, digit or mark becomes a space
   (punctuation, '_', '/', '-', line breaks ...).
6. Whitespace is collapsed to single spaces and trimmed.

The output therefore consists of tokens separated by exactly one space, which
lets the matchers use a padded " token " representation for word boundaries.
"""
from __future__ import annotations

import math
import re
import unicodedata
from typing import Dict, List, Tuple

APOSTROPHES = "'’‘`´ʼʻ′"


class _CharMap(dict):
    """ord(char) -> replacement, filled lazily for non-ASCII characters (used by str.translate)."""

    def __init__(self, strip_accents: bool):
        super().__init__()
        self.strip_accents = strip_accents
        for code in range(128):
            ch = chr(code)
            if ch in APOSTROPHES:
                self[code] = None
            elif ch.isalnum():
                self[code] = ch.lower()
            else:
                self[code] = " "

    def __missing__(self, code: int):
        ch = chr(code)
        category = unicodedata.category(ch)
        if ch in APOSTROPHES:
            result = None
        elif category == "Mn" and self.strip_accents:
            result = None
        elif category[0] in ("L", "N", "M"):
            result = ch
        else:
            result = " "
        self[code] = result
        return result


_SPACES = re.compile(" {2,}")
_SEP = "\x00"


def _bytes_table() -> Tuple[bytes, bytes]:
    table = bytearray(256)
    for code in range(256):
        ch = chr(code)
        if code == 0:
            table[code] = 0                       # batch separator is preserved
        elif code < 128 and ch.isalnum():
            table[code] = ord(ch.lower())
        else:
            table[code] = 32                      # space
    delete = bytes(ord(c) for c in APOSTROPHES if ord(c) < 128)
    return bytes(table), delete


class TextNormalizer:
    def __init__(self, strip_accents: bool = True):
        self.strip_accents = strip_accents
        self._map = _CharMap(strip_accents)
        self._bytes_table, self._bytes_delete = _bytes_table()

    def normalize_many(self, values: List[str]) -> List[str]:
        """Normalise a whole batch with C-level string operations.

        ASCII values (the vast majority of payment data) are joined with a NUL
        separator, translated as bytes in one call, space-collapsed by one regex
        and split back. Non-ASCII values take the per-value Unicode path. The
        result is identical to [normalize(v) for v in values] (tested).
        """
        if not values:
            return []
        n = len(values)
        big = _SEP.join(values)
        special: Dict[int, str] = {}
        if not big.isascii() or big.count(_SEP) != n - 1:
            batch = list(values)
            for i, value in enumerate(values):
                if not value.isascii() or _SEP in value:
                    special[i] = self.normalize(value)
                    batch[i] = ""
            big = _SEP.join(batch)
        text = big.encode("ascii").translate(self._bytes_table, self._bytes_delete).decode("ascii")
        text = _SPACES.sub(" ", text).replace(" " + _SEP, _SEP).replace(_SEP + " ", _SEP)
        out = text.split(_SEP)
        out[0] = out[0].strip(" ")
        out[-1] = out[-1].strip(" ")
        for i, value in special.items():
            out[i] = value
        return out

    def normalize(self, value: object) -> str:
        if value is None:
            return ""
        if isinstance(value, float):
            if math.isnan(value):
                return ""
        text = value if isinstance(value, str) else str(value)
        if not text:
            return ""
        if text.isascii():
            text = text.translate(self._map)
        else:
            text = unicodedata.normalize("NFKD", text).casefold().translate(self._map)
        return " ".join(text.split())

    @staticmethod
    def compact(normalized: str) -> str:
        return normalized.replace(" ", "")

    @staticmethod
    def token_spans(normalized: str) -> List[Tuple[int, int]]:
        """Character spans of each token in a normalised string."""
        spans: List[Tuple[int, int]] = []
        if not normalized:
            return spans
        position = 0
        for token in normalized.split(" "):
            spans.append((position, position + len(token)))
            position += len(token) + 1
        return spans

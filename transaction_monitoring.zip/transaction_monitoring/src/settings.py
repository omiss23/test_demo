"""Engine settings (config/settings.yaml).

Every behaviour that a compliance or data team may need to change without a
code release lives here: chunk size, policies, country resolution, match-type
defaults, rule registry, scoring weights. Unknown keys are reported (a typo in
a policy name must never be silently ignored).
"""
from __future__ import annotations

import copy
from dataclasses import dataclass, field, fields
from pathlib import Path
from typing import Any, Dict, List, Optional

from .exceptions import ConfigurationError
from .models import MatchType, Severity, ValidationIssue
from .utils import sha256_file

DUPLICATE_POLICIES = ("WARN_AND_PROCESS", "REJECT_DUPLICATES", "FAIL_FILE")
NULL_KEY_POLICIES = ("REJECT", "FAIL_FILE")
SCHEMA_ERROR_POLICIES = ("CONTINUE_WITH_ERRORS", "FAIL_FILE")
COUNTRY_STRATEGIES = ("cli", "column", "file_pattern", "default")
CANDIDATE_BACKENDS = ("auto", "aho_corasick", "pure_python")
SPAN_POLICIES = ("CONTAINS", "OVERLAPS", "EXACT_SPAN")


@dataclass
class InputSettings:
    message_key_column: str = "MESSAGE_KEY"
    encoding: str = "auto"                       # or an explicit codec, e.g. utf-8, cp1252
    encoding_fallbacks: List[str] = field(default_factory=lambda: ["utf-8", "cp1252", "latin-1"])
    delimiter: str = ","
    reader_backend: str = "auto"                 # auto -> pyarrow if installed, else pandas
    chunk_size: int = 100_000                    # 50_000 / 100_000 / 250_000 / 500_000 ...
    prepass_chunk_size: int = 250_000            # key-only profiling pass reads 1-2 columns


@dataclass
class DataQualitySettings:
    duplicate_message_key_policy: str = "WARN_AND_PROCESS"
    null_message_key_policy: str = "REJECT"
    max_detail_rows_per_issue: int = 100_000     # cap on per-row DQ detail lines per issue code


@dataclass
class CountryResolutionSettings:
    order: List[str] = field(default_factory=lambda: ["cli", "column", "file_pattern", "default"])
    country_columns: List[str] = field(default_factory=lambda: ["COUNTRY", "COUNTRY_CODE", "CTRY", "ISO_COUNTRY_CODE"])
    file_patterns: List[Dict[str, str]] = field(default_factory=list)  # [{pattern: "india_*.csv", country: IN}]
    default_country: Optional[str] = None
    aliases: Dict[str, str] = field(default_factory=lambda: {
        "UK": "GB", "GBR": "GB", "UAE": "AE", "ARE": "AE", "IND": "IN", "USA": "US",
        "SGP": "SG", "DEU": "DE", "FRA": "FR", "ITA": "IT", "JPN": "JP",
    })
    extra_valid_codes: List[str] = field(default_factory=lambda: ["XK"])


@dataclass
class SchemaSettings:
    allow_identity_mapping: bool = True          # logical name == physical column name (exact, reported)
    canonical_header_matching: bool = True       # 'Beneficiary Name' == 'BENEFICIARY_NAME' (deterministic)
    fallback_to_default_profile: bool = True     # country profile finds nothing -> try DEFAULT aliases (reported)
    fuzzy_suggestions: bool = True               # suggestions only - never applied
    fuzzy_suggestion_threshold: float = 80.0
    schema_error_policy: str = "CONTINUE_WITH_ERRORS"


@dataclass
class MatchingSettings:
    default_match_type: str = MatchType.TOKEN
    candidate_backend: str = "auto"              # auto -> aho_corasick if installed, else pure_python
    compact_variants: bool = True                # multi-token keyword also searched without spaces
    compact_variant_min_length: int = 6
    phrase_max_gap: int = 2                      # PHRASE: max tokens allowed between keyword tokens
    fuzzy_default_threshold: float = 90.0
    fuzzy_min_keyword_length: int = 5            # shorter FUZZY keywords produce a config warning
    fuzzy_block_margin: float = 10.0             # stage-2 blocking cut-off = threshold - margin
    fuzzy_min_block_token_length: int = 4
    fuzzy_unavailable_policy: str = "FAIL"      # FAIL | DOWNGRADE_TO_TOKEN (reported) when rapidfuzz is missing
    value_cache_size: int = 250_000              # bound for classification/decision/fuzzy-token caches


@dataclass
class IndividualSettings:
    lexicon: str = "reference/individual_indicators.yaml"
    threshold: float = 0.75                      # p(individual) needed before EXCL_INDV can exclude
    name_fields: List[str] = field(default_factory=lambda: [
        "BENEFICIARY", "ORIGINATOR", "CREDITOR", "DEBTOR", "ORDERING_CUSTOMER",
        "BENEFICIARY_CUSTOMER", "PAYER", "PAYEE", "ACCOUNT_HOLDER", "PARTY_NAME",
    ])
    context_window_tokens: int = 3               # for free-text fields: tokens either side of the match


@dataclass
class ScoringSettings:
    field_weights: Dict[str, float] = field(default_factory=lambda: {
        "BENEFICIARY": 1.0, "ORIGINATOR": 1.0, "DESCRIPTION": 0.85, "ADDRESS": 0.75, "DEFAULT": 0.9,
    })
    match_type_weights: Dict[str, float] = field(default_factory=lambda: {
        "EXACT": 1.0, "TOKEN": 1.0, "PHRASE": 0.95, "FUZZY": 0.9, "SUBSTRING": 0.7,
    })


@dataclass
class OutputSettings:
    run_subdirectory: bool = True                # never overwrite a previous run's evidence
    write_transaction_rollup: bool = True        # alerted_transactions.csv (one row per alerted MESSAGE_KEY)
    write_screening_ledger: bool = False         # screened_transactions.csv (one row per input row)
    gc_every_n_chunks: int = 10                  # 0 = never force a collection (ref-counting frees chunks anyway)


DEFAULT_RULES: Dict[str, Dict[str, Any]] = {
    "EXCL_INDV": {"classifier": "individual",
                  "description": "Exclude when the matched occurrence is part of a natural person's name"},
    "EXCL_TOPONYM": {"classifier": "toponym", "list": "Toponym", "span_policy": "CONTAINS",
                     "description": "Exclude when an active Toponym value contains the matched text"},
    "EXCL_SECULAR": {"classifier": "secular", "list": "Secular", "span_policy": "CONTAINS",
                     "description": "Exclude when an active Secular value contains the matched text"},
    "EXCL_RELIGIOUS": {"classifier": "religious", "list": "Religious", "span_policy": "CONTAINS",
                       "description": "Exclude when an active Religious value contains the matched text"},
}

_SECTIONS = {
    "input": InputSettings,
    "data_quality": DataQualitySettings,
    "country_resolution": CountryResolutionSettings,
    "schema": SchemaSettings,
    "matching": MatchingSettings,
    "individual": IndividualSettings,
    "scoring": ScoringSettings,
    "output": OutputSettings,
}


@dataclass
class Settings:
    input: InputSettings = field(default_factory=InputSettings)
    data_quality: DataQualitySettings = field(default_factory=DataQualitySettings)
    country_resolution: CountryResolutionSettings = field(default_factory=CountryResolutionSettings)
    schema: SchemaSettings = field(default_factory=SchemaSettings)
    matching: MatchingSettings = field(default_factory=MatchingSettings)
    individual: IndividualSettings = field(default_factory=IndividualSettings)
    scoring: ScoringSettings = field(default_factory=ScoringSettings)
    output: OutputSettings = field(default_factory=OutputSettings)
    rules: Dict[str, Dict[str, Any]] = field(default_factory=lambda: copy.deepcopy(DEFAULT_RULES))
    auto_register_list_rules: bool = True        # EXCL_<LIST> works for any new Intelligence_Lists list
    base_dir: Path = field(default_factory=Path.cwd)
    source: str = "built-in defaults"
    sha256: str = "builtin"
    issues: List[ValidationIssue] = field(default_factory=list)

    # ------------------------------------------------------------------ #
    @classmethod
    def load(cls, path: Optional[Path] = None, base_dir: Optional[Path] = None) -> "Settings":
        """Load settings.yaml (or built-in defaults when `path` is None)."""
        settings = cls()
        if base_dir is not None:
            settings.base_dir = Path(base_dir)
        if path is None:
            settings.issues.extend(settings.validate())
            return settings
        path = Path(path)
        if not path.exists():
            raise ConfigurationError(f"Settings file not found: {path}")
        try:
            import yaml  # type: ignore
        except ImportError as exc:  # pragma: no cover
            raise ConfigurationError("PyYAML is required to read settings.yaml") from exc
        with open(path, "r", encoding="utf-8") as handle:
            raw = yaml.safe_load(handle) or {}
        if not isinstance(raw, dict):
            raise ConfigurationError(f"{path}: top level must be a mapping")
        settings.base_dir = path.parent
        settings.source = str(path)
        settings.sha256 = sha256_file(path)
        settings._apply(raw)
        settings.issues.extend(settings.validate())
        return settings

    def _apply(self, raw: Dict[str, Any]) -> None:
        for key, value in raw.items():
            if key in _SECTIONS:
                section = getattr(self, key)
                if not isinstance(value, dict):
                    self.issues.append(ValidationIssue(Severity.ERROR, "settings", "INVALID_SECTION",
                                                       f"Section '{key}' must be a mapping", field=key))
                    continue
                known = {f.name: f for f in fields(section)}
                for sub_key, sub_value in value.items():
                    if sub_key not in known:
                        self.issues.append(ValidationIssue(
                            Severity.WARNING, "settings", "UNKNOWN_SETTING",
                            f"Unknown setting '{key}.{sub_key}' ignored (check spelling)", field=f"{key}.{sub_key}"))
                        continue
                    current = getattr(section, sub_key)
                    setattr(section, sub_key, _coerce(sub_value, current, f"{key}.{sub_key}"))
            elif key == "rules":
                if value:
                    if not isinstance(value, dict):
                        raise ConfigurationError("'rules' must map rule codes to definitions")
                    self.rules = {str(code).strip().upper(): dict(defn or {}) for code, defn in value.items()}
            elif key == "auto_register_list_rules":
                self.auto_register_list_rules = bool(value)
            elif key in ("version", "description"):
                continue
            else:
                self.issues.append(ValidationIssue(Severity.WARNING, "settings", "UNKNOWN_SETTING",
                                                   f"Unknown top-level setting '{key}' ignored", field=key))

    def resolve_path(self, value: str) -> Path:
        path = Path(value)
        return path if path.is_absolute() else (self.base_dir / path)

    # ------------------------------------------------------------------ #
    def validate(self) -> List[ValidationIssue]:
        issues: List[ValidationIssue] = []

        def bad(code: str, detail: str, fld: str) -> None:
            issues.append(ValidationIssue(Severity.ERROR, "settings", code, detail, field=fld))

        dq = self.data_quality
        dq.duplicate_message_key_policy = str(dq.duplicate_message_key_policy).upper()
        if dq.duplicate_message_key_policy not in DUPLICATE_POLICIES:
            bad("INVALID_POLICY", f"duplicate_message_key_policy must be one of {DUPLICATE_POLICIES}",
                "data_quality.duplicate_message_key_policy")
        dq.null_message_key_policy = str(dq.null_message_key_policy).upper()
        if dq.null_message_key_policy not in NULL_KEY_POLICIES:
            bad("INVALID_POLICY", f"null_message_key_policy must be one of {NULL_KEY_POLICIES}",
                "data_quality.null_message_key_policy")
        self.schema.schema_error_policy = str(self.schema.schema_error_policy).upper()
        if self.schema.schema_error_policy not in SCHEMA_ERROR_POLICIES:
            bad("INVALID_POLICY", f"schema_error_policy must be one of {SCHEMA_ERROR_POLICIES}",
                "schema.schema_error_policy")
        if self.input.chunk_size < 1:
            bad("INVALID_VALUE", "chunk_size must be >= 1", "input.chunk_size")
        order = [str(s).lower() for s in self.country_resolution.order]
        unknown = [s for s in order if s not in COUNTRY_STRATEGIES]
        if unknown:
            bad("INVALID_VALUE", f"Unknown country resolution strategies {unknown}; use {COUNTRY_STRATEGIES}",
                "country_resolution.order")
        self.country_resolution.order = [s for s in order if s in COUNTRY_STRATEGIES]
        m = self.matching
        m.default_match_type = str(m.default_match_type).upper()
        if m.default_match_type not in MatchType.ALL:
            bad("INVALID_VALUE", f"default_match_type must be one of {MatchType.ALL}", "matching.default_match_type")
        m.candidate_backend = str(m.candidate_backend).lower()
        if m.candidate_backend not in CANDIDATE_BACKENDS:
            bad("INVALID_VALUE", f"candidate_backend must be one of {CANDIDATE_BACKENDS}", "matching.candidate_backend")
        m.fuzzy_unavailable_policy = str(m.fuzzy_unavailable_policy).upper()
        if m.fuzzy_unavailable_policy not in ("FAIL", "DOWNGRADE_TO_TOKEN"):
            bad("INVALID_VALUE", "fuzzy_unavailable_policy must be FAIL or DOWNGRADE_TO_TOKEN",
                "matching.fuzzy_unavailable_policy")
        if not 0 < m.fuzzy_default_threshold <= 100:
            bad("INVALID_VALUE", "fuzzy_default_threshold must be in (0, 100]", "matching.fuzzy_default_threshold")
        if not 0 < self.individual.threshold < 1:
            bad("INVALID_VALUE", "individual.threshold must be in (0, 1)", "individual.threshold")
        for code, definition in self.rules.items():
            if "classifier" not in definition:
                bad("INVALID_RULE_DEFINITION", f"Rule {code} has no 'classifier'", f"rules.{code}")
            policy = str(definition.get("span_policy", "CONTAINS")).upper()
            if policy not in SPAN_POLICIES:
                bad("INVALID_RULE_DEFINITION", f"Rule {code}: span_policy must be one of {SPAN_POLICIES}",
                    f"rules.{code}.span_policy")
        return issues


def _coerce(value: Any, current: Any, name: str) -> Any:
    """Coerce YAML values to the type of the default (int/float/bool/list/dict)."""
    if value is None:
        return current if not isinstance(current, (list, dict)) else type(current)()
    try:
        if isinstance(current, bool):
            if isinstance(value, str):
                return value.strip().lower() in ("1", "true", "yes", "y", "on")
            return bool(value)
        if isinstance(current, int) and not isinstance(current, bool):
            return int(str(value).replace("_", ""))
        if isinstance(current, float):
            return float(value)
        if isinstance(current, list):
            return list(value) if isinstance(value, (list, tuple)) else [value]
        if isinstance(current, dict):
            if not isinstance(value, dict):
                raise TypeError("expected a mapping")
            return dict(value)
    except (TypeError, ValueError) as exc:
        raise ConfigurationError(f"Invalid value for setting '{name}': {value!r} ({exc})") from exc
    return value

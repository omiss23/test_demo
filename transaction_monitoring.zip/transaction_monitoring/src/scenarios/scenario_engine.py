"""ScenarioEngine: P1 eligibility + in-memory P2 rule indexes (built once).

P1 says which RT TYPEs apply to which countries; P2 holds the ACTIVE rules.
The engine never scans P2 per transaction - it builds:

    rules_by_rt_type        RT TYPE        -> [rules]
    rules_by_keyword        keyword        -> [rules]
    rules_by_logical_field  logical field  -> [rules]
    rules_by_country        country        -> [rules]  (lazy, cached: P1 applied)

Country filtering therefore happens before any matching: a country that is
not in P1 for an RT TYPE never even has that RT TYPE's keywords compiled
into its search plan.
"""
from __future__ import annotations

from collections import defaultdict
from dataclasses import replace
from typing import Dict, List

from ..matching.keyword_registry import KeywordRegistry
from ..models import ScenarioRule
from ..validation.mapping_validator import WILDCARD, MonitoringConfig, rt_key


class ScenarioEngine:
    def __init__(self, config: MonitoringConfig, keyword_registry: KeywordRegistry):
        self.config = config
        self.keywords = keyword_registry
        self.rules: List[ScenarioRule] = [
            replace(rule, spec_id=keyword_registry.register(rule.normalized_keyword, rule.match_type,
                                                             rule.fuzzy_threshold))
            for rule in config.rules
        ]
        self.rules_by_rt_type: Dict[str, List[ScenarioRule]] = defaultdict(list)
        self.rules_by_keyword: Dict[str, List[ScenarioRule]] = defaultdict(list)
        self.rules_by_logical_field: Dict[str, List[ScenarioRule]] = defaultdict(list)
        for rule in self.rules:
            self.rules_by_rt_type[rt_key(rule.rt_type)].append(rule)
            self.rules_by_keyword[rule.normalized_keyword].append(rule)
            for logical in rule.logical_fields:
                self.rules_by_logical_field[logical].append(rule)
        self._by_country: Dict[str, List[ScenarioRule]] = {}

    def is_eligible(self, rt_type: str, country: str) -> bool:
        countries = self.config.p1.get(rt_key(rt_type), frozenset())
        return country in countries or WILDCARD in countries

    def eligible_rt_types(self, country: str) -> List[str]:
        return sorted(self.config.rt_display.get(k, k) for k, countries in self.config.p1.items()
                      if (country in countries or WILDCARD in countries) and self.rules_by_rt_type.get(k))

    def rules_for_country(self, country: str) -> List[ScenarioRule]:
        if country not in self._by_country:
            self._by_country[country] = [r for r in self.rules if self.is_eligible(r.rt_type, country)]
        return self._by_country[country]

    @property
    def rules_by_country(self) -> Dict[str, List[ScenarioRule]]:
        return dict(self._by_country)

    def used_rule_codes(self) -> set:
        return {code for rule in self.rules for code in rule.exclusion_rules}

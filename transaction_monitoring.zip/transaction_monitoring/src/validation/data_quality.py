"""Data-quality checks on the transaction file.

Pre-pass (before any screening, reads only MESSAGE_KEY [+ country column]):
  * row count, null/blank MESSAGE_KEY count
  * duplicate MESSAGE_KEY detection via 64-bit hashes (8 bytes/row: 5M rows ~ 40 MB),
    so REJECT_DUPLICATES / FAIL_FILE can be enforced before a single alert is written
  * country values present in the file (to build only the search plans needed)
  * encoding verification over the whole file (falls back if a late byte fails)

Main pass (per chunk): flags null / duplicate keys, counts empty values in the
searched columns, collects malformed records. Duplicate counts in the report are
exact: every row whose hash is a duplicate hash is re-checked by its real key.
"""
from __future__ import annotations

import time
from collections import Counter
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from ..ingestion.transaction_reader import MalformedRecord, TransactionReader
from ..models import Severity
from ..settings import Settings


@dataclass
class PrepassResult:
    total_rows: int = 0
    null_keys: int = 0
    distinct_keys: int = 0
    duplicate_hashes: np.ndarray = field(default_factory=lambda: np.empty(0, dtype=np.uint64))
    duplicate_rows: int = 0
    country_value_counts: Dict[str, int] = field(default_factory=dict)
    seconds: float = 0.0

    @property
    def has_duplicates(self) -> bool:
        return bool(self.duplicate_hashes.size)


def hash_keys(keys: pd.Series) -> np.ndarray:
    return pd.util.hash_pandas_object(keys, index=False).to_numpy(dtype=np.uint64)


class DataQualityMonitor:
    def __init__(self, settings: Settings, key_column: str):
        self.settings = settings
        self.key_column = key_column
        self.max_detail = int(settings.data_quality.max_detail_rows_per_issue)
        self.prepass_result = PrepassResult()
        self.null_rows: List[int] = []
        self.null_count = 0
        self.duplicate_occurrences: List[Tuple[str, int]] = []
        self.duplicate_key_counts: Counter = Counter()
        self.malformed: List[MalformedRecord] = []
        self.empty_counts: Counter = Counter()
        self.value_counts: Counter = Counter()
        self.summary: List[Dict] = []
        self.extra_details: List[Dict] = []

    # ------------------------------------------------------------------ #
    def prepass(self, reader: TransactionReader, key_column: str, country_column: Optional[str]) -> PrepassResult:
        started = time.perf_counter()
        usecols = [key_column] + ([country_column] if country_column and country_column != key_column else [])
        hashes: List[np.ndarray] = []
        result = PrepassResult()
        countries: Counter = Counter()
        for chunk, _ in reader.iter_chunks(usecols=usecols, chunk_size=self.settings.input.prepass_chunk_size):
            if chunk.empty:
                continue
            keys = chunk[key_column].astype(str).str.strip()
            null = (keys == "").to_numpy()
            result.total_rows += len(chunk)
            result.null_keys += int(null.sum())
            if (~null).any():
                hashes.append(hash_keys(keys[~null]))
            if country_column and country_column in chunk.columns:
                countries.update(chunk[country_column].astype(str).str.strip().str.upper().value_counts().to_dict())
        if hashes:
            all_hashes = np.concatenate(hashes)
            del hashes
            unique, counts = np.unique(all_hashes, return_counts=True)
            result.distinct_keys = int(unique.size)
            dup_mask = counts > 1
            result.duplicate_hashes = unique[dup_mask]
            result.duplicate_rows = int(counts[dup_mask].sum())
            del all_hashes, unique, counts
        result.country_value_counts = dict(countries)
        result.seconds = time.perf_counter() - started
        self.prepass_result = result
        return result

    # ------------------------------------------------------------------ #
    def check_keys(self, keys: pd.Series, row_numbers: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """Return (null_mask, duplicate_mask) for a chunk of stripped keys."""
        null_mask = (keys == "").to_numpy()
        if null_mask.any():
            self.null_count += int(null_mask.sum())
            room = self.max_detail - len(self.null_rows)
            if room > 0:
                self.null_rows.extend(row_numbers[null_mask][:room].tolist())
        dup_mask = np.zeros(len(keys), dtype=bool)
        dup_hashes = self.prepass_result.duplicate_hashes
        if dup_hashes.size:
            dup_mask = np.isin(hash_keys(keys), dup_hashes) & ~null_mask
            if dup_mask.any():
                flagged = keys.to_numpy(dtype=object)[dup_mask]
                rows = row_numbers[dup_mask]
                self.duplicate_key_counts.update(flagged.tolist())
                room = self.max_detail - len(self.duplicate_occurrences)
                if room > 0:
                    self.duplicate_occurrences.extend(zip(flagged[:room].tolist(), rows[:room].tolist()))
        return null_mask, dup_mask

    def record_column_counts(self, column: str, total: int, empty: int) -> None:
        """Values screened in a searched column and how many were empty (after normalisation)."""
        self.value_counts[column] += int(total)
        self.empty_counts[column] += int(empty)

    def record_malformed(self, records: List[MalformedRecord]) -> None:
        self.malformed.extend(records)

    def true_duplicate_keys(self) -> Dict[str, int]:
        """Exact duplicate counts by real key (filters out the rare 64-bit hash collision)."""
        return {k: c for k, c in self.duplicate_key_counts.items() if c > 1}

    def add_summary(self, check: str, status: str, severity: str, count=None, detail: str = "",
                    column: str = "", value: str = "") -> None:
        self.summary.append({"RECORD_TYPE": "SUMMARY", "CHECK": check, "STATUS": status, "SEVERITY": severity,
                             "COLUMN": column, "VALUE": value, "COUNT": "" if count is None else count,
                             "DETAIL": detail})

    def add_detail(self, check: str, severity: str, detail: str, message_key: str = "", row_number=None,
                   column: str = "", value: str = "", count=None) -> None:
        self.extra_details.append({"RECORD_TYPE": "DETAIL", "CHECK": check, "STATUS": "", "SEVERITY": severity,
                                   "MESSAGE_KEY": message_key, "ROW_NUMBER": "" if row_number is None else row_number,
                                   "COLUMN": column, "VALUE": value, "COUNT": "" if count is None else count,
                                   "DETAIL": detail})

    # ------------------------------------------------------------------ #
    def report_records(self, duplicate_policy: str, null_policy: str) -> List[Dict]:
        records: List[Dict] = list(self.summary)
        dup_keys = self.true_duplicate_keys()
        dup_rows = sum(dup_keys.values())
        status = "PASS" if not dup_keys else "WARN"
        self.summary_line(records, "MESSAGE_KEY_UNIQUE", status, Severity.INFO if not dup_keys else Severity.WARNING,
                          len(dup_keys), f"{len(dup_keys)} duplicated MESSAGE_KEY value(s) on {dup_rows} rows; "
                                         f"policy={duplicate_policy}", column=self.key_column)
        self.summary_line(records, "MESSAGE_KEY_NOT_NULL", "PASS" if not self.null_count else "FAIL",
                          Severity.INFO if not self.null_count else Severity.ERROR, self.null_count,
                          f"{self.null_count} row(s) with blank MESSAGE_KEY; policy={null_policy} "
                          f"(rows are not screened and are listed in errors.csv)", column=self.key_column)
        self.summary_line(records, "MALFORMED_RECORDS", "PASS" if not self.malformed else "WARN",
                          Severity.INFO if not self.malformed else Severity.ERROR, len(self.malformed),
                          "records with the wrong number of fields are skipped by the parser and listed here")
        for column in sorted(self.value_counts):
            total = self.value_counts[column]
            empty = self.empty_counts[column]
            pct = 100.0 * empty / total if total else 0.0
            self.summary_line(records, "SEARCHED_COLUMN_EMPTY_RATE", "PASS" if pct < 50 else "WARN",
                              Severity.INFO if pct < 50 else Severity.WARNING, empty,
                              f"{pct:.2f}% of {total} screened values are empty", column=column)
        action = {"WARN_AND_PROCESS": "PROCESSED", "REJECT_DUPLICATES": "REJECTED", "FAIL_FILE": "FILE_FAILED"}
        for key, row in self.duplicate_occurrences:
            count = dup_keys.get(key)
            if count is None:
                records.append(self._detail("HASH_COLLISION_NOT_DUPLICATE", Severity.INFO, key, row, 1,
                                            "64-bit hash collision with another key; not a real duplicate"))
                continue
            records.append(self._detail("DUPLICATE_MESSAGE_KEY", Severity.WARNING, key, row, count,
                                        f"MESSAGE_KEY occurs {count} times; action={action[duplicate_policy]}"))
        for row in self.null_rows:
            records.append(self._detail("NULL_MESSAGE_KEY", Severity.ERROR, "", row, None,
                                        "MESSAGE_KEY is blank; transaction not screened"))
        for record in self.malformed[: self.max_detail]:
            records.append(self._detail("MALFORMED_RECORD", Severity.ERROR, "", record.parser_line, None,
                                        f"{'parser line ' + str(record.parser_line) if record.parser_line >= 0 else 'parser line n/a'}: "
                                        f"{record.detail}; record skipped"))
        records.extend(self.extra_details)
        return records

    @staticmethod
    def summary_line(records, check, status, severity, count, detail, column=""):
        records.append({"RECORD_TYPE": "SUMMARY", "CHECK": check, "STATUS": status, "SEVERITY": severity,
                        "COLUMN": column, "COUNT": count, "DETAIL": detail})

    @staticmethod
    def _detail(check, severity, key, row, count, detail):
        return {"RECORD_TYPE": "DETAIL", "CHECK": check, "STATUS": "", "SEVERITY": severity, "MESSAGE_KEY": key,
                "ROW_NUMBER": row, "COUNT": "" if count is None else count, "DETAIL": detail}

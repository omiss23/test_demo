"""Schema validation report: one row per (country, logical field) the ACTIVE rules need.

Required physical columns are derived, not hard-coded:
    ACTIVE P2 rules  x  Message logical fields  x  the country's schema profile
so a file is only required to contain the columns its own scenarios search.
"""
from __future__ import annotations

from typing import Dict, List, Sequence

from ..models import Severity, ValidationIssue
from ..schema.column_resolver import STATUS_RESOLVED
from ..schema.schema_registry import SchemaRegistry


class SchemaValidator:
    def __init__(self, registry: SchemaRegistry):
        self.registry = registry

    def report_records(self, plan, header: Sequence[str], key_column: str, country_column: str,
                       duplicate_header_names: Sequence[str], registry_issues: Sequence[ValidationIssue]) -> List[Dict]:
        records: List[Dict] = []
        rules_by_res = plan.rules_by_resolution()
        for res in plan.resolution_results():
            rules = rules_by_res.get((res.country, res.logical_field), [])
            ok = res.status == STATUS_RESOLVED
            records.append({
                "COUNTRY": res.country,
                "LOGICAL_FIELD": res.logical_field,
                "STATUS": res.status,
                "SEVERITY": Severity.INFO if ok else Severity.ERROR,
                "RESOLUTION_METHOD": ",".join(sorted(set(res.methods))),
                "PROFILE_USED": res.profile_used,
                "PHYSICAL_COLUMNS": ",".join(res.physical_columns),
                "CONFIGURED_CANDIDATES": ",".join(res.configured_candidates),
                "MISSING_CANDIDATES": ",".join(res.missing_candidates),
                "SUGGESTIONS": "; ".join(res.suggestions) + (" (suggestions are never applied automatically)"
                                                             if res.suggestions else ""),
                "AFFECTED_RT_TYPES": ",".join(sorted({r.rt_type for r in rules})),
                "AFFECTED_RULE_IDS": ",".join(sorted({r.rule_id for r in rules})),
                "DETAIL": res.detail,
            })
        mapped = set()
        for res in plan.resolution_results():
            mapped.update(res.physical_columns)
        ignored = {key_column, country_column}
        for column in header:
            if column not in mapped and column not in ignored:
                records.append({"COUNTRY": "", "LOGICAL_FIELD": "", "STATUS": "UNMAPPED_COLUMN",
                                "SEVERITY": Severity.INFO, "PHYSICAL_COLUMNS": column,
                                "DETAIL": "Column present in the file but not searched by any ACTIVE rule"})
        for name in duplicate_header_names:
            records.append({"STATUS": "DUPLICATE_HEADER", "SEVERITY": Severity.WARNING, "PHYSICAL_COLUMNS": name,
                            "DETAIL": f"Header '{name}' appears more than once; later copies are read as "
                                      f"'{name}.1', '{name}.2'..."})
        for issue in registry_issues:
            records.append({"STATUS": issue.code, "SEVERITY": issue.severity, "LOGICAL_FIELD": issue.field,
                            "PHYSICAL_COLUMNS": issue.value,
                            "DETAIL": f"{issue.detail}" + (f" (row {issue.row})" if issue.row else "")})
        return records

    @staticmethod
    def error_count(records: List[Dict]) -> int:
        return sum(1 for r in records if r.get("SEVERITY") in (Severity.ERROR, Severity.CRITICAL))

"""Validate the mapping workbook and build the typed, active-only configuration.

Nothing is dropped silently: every skipped, merged or defaulted row produces a
ValidationIssue that ends up in config_validation_report.csv with its Excel
row number. Fail-safe principle: a problem in an *exclusion* setting never
suppresses a keyword - the keyword is still screened and the exclusion is
simply not applied (so the outcome is an ALERT, never a silent miss).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, FrozenSet, List, Optional, Set, Tuple

from ..ingestion.mapping_reader import RawMapping
from ..models import IntelligenceEntry, MatchType, ScenarioRule, Severity, ValidationIssue
from ..normalization.text_normalizer import TextNormalizer
from ..rules.rule_registry import RuleRegistry
from ..schema.iso_countries import ISO_ALPHA2
from ..settings import Settings
from ..utils import canonical_name, split_list

WILDCARD = "*"
_WILDCARD_TOKENS = {"*", "ALL", "ANY"}


def rt_key(value: str) -> str:
    return " ".join(str(value).split()).upper()


@dataclass
class MonitoringConfig:
    path: Path
    sha256: str
    version: str
    p1: Dict[str, FrozenSet[str]]                     # rt_key -> countries (may contain '*')
    rt_display: Dict[str, str]                        # rt_key -> display name
    rules: List[ScenarioRule]                         # ACTIVE and usable P2 rows
    intelligence: Dict[str, List[IntelligenceEntry]]  # list key -> ACTIVE entries
    intelligence_display: Dict[str, str]              # list key -> display name
    registry: RuleRegistry
    stats: Dict[str, int] = field(default_factory=dict)
    issues: List[ValidationIssue] = field(default_factory=list)


class MappingValidator:
    def __init__(self, settings: Settings, normalizer: TextNormalizer):
        self.settings = settings
        self.normalizer = normalizer
        self.issues: List[ValidationIssue] = []
        self.valid_countries = set(ISO_ALPHA2) | {c.upper() for c in settings.country_resolution.extra_valid_codes}
        self.aliases = {str(k).upper(): str(v).upper() for k, v in settings.country_resolution.aliases.items()}

    def _issue(self, severity: str, source: str, code: str, detail: str, row: Optional[int] = None,
               field_name: str = "", value: str = "") -> None:
        self.issues.append(ValidationIssue(severity, source, code, detail, row, field_name, value))

    # ------------------------------------------------------------------ #
    def validate(self, raw: RawMapping) -> MonitoringConfig:
        intelligence, display, list_keys_all, il_stats = self._intelligence(raw)
        registry = RuleRegistry(self.settings, list_keys_all)
        p1, rt_display = self._p1(raw)
        rules, p2_stats = self._p2(raw, registry, p1, rt_display)
        self._cross_checks(p1, rt_display, rules, registry, intelligence, display)
        stats = {**il_stats, **p2_stats, "p1_rt_types": len(p1)}
        return MonitoringConfig(raw.path, raw.sha256, raw.version, p1, rt_display, rules, intelligence, display,
                                registry, stats, list(self.issues))

    # ------------------------------------------------------------------ #
    def _p1(self, raw: RawMapping) -> Tuple[Dict[str, FrozenSet[str]], Dict[str, str]]:
        countries_by_rt: Dict[str, Set[str]] = {}
        display: Dict[str, str] = {}
        for row in raw.p1.to_dict("records"):
            excel_row = int(row["EXCEL_ROW"])
            rt = " ".join(row["RT_TYPE"].split())
            if not rt:
                self._issue(Severity.ERROR, "P1", "MISSING_RT_TYPE", "RT TYPE is blank; row ignored", excel_row)
                continue
            key = rt_key(rt)
            if key in countries_by_rt:
                self._issue(Severity.WARNING, "P1", "DUPLICATE_RT_TYPE",
                            f"'{rt}' appears more than once in P1; country lists are merged", excel_row, "RT TYPE", rt)
            display.setdefault(key, rt)
            bucket = countries_by_rt.setdefault(key, set())
            for token in split_list(row["COUNTRIES"], ",;|\n "):
                code = token.strip().upper()
                if code in _WILDCARD_TOKENS:
                    bucket.add(WILDCARD)
                    continue
                code = self.aliases.get(code, code)
                if code not in self.valid_countries:
                    self._issue(Severity.ERROR, "P1", "INVALID_COUNTRY_CODE",
                                f"'{token}' is not an ISO 3166-1 alpha-2 code; ignored for '{rt}'",
                                excel_row, "COUNTRIES", token)
                    continue
                if code != token.strip().upper():
                    self._issue(Severity.INFO, "P1", "COUNTRY_ALIAS_APPLIED",
                                f"'{token}' interpreted as {code}", excel_row, "COUNTRIES", token)
                bucket.add(code)
            if not bucket:
                self._issue(Severity.WARNING, "P1", "NO_COUNTRIES",
                            f"'{rt}' has no valid countries; its P2 rules can never be evaluated", excel_row)
        return {k: frozenset(v) for k, v in countries_by_rt.items()}, display

    # ------------------------------------------------------------------ #
    def _p2(self, raw: RawMapping, registry: RuleRegistry, p1, rt_display) -> Tuple[List[ScenarioRule], Dict[str, int]]:
        m = self.settings.matching
        rules: List[ScenarioRule] = []
        seen_signatures: Dict[tuple, int] = {}
        seen_ids: Set[str] = set()
        inactive = invalid = 0
        has_match_type = "MATCH_TYPE" in raw.p2.columns
        has_threshold = "FUZZY_THRESHOLD" in raw.p2.columns
        has_rule_id = "RULE_ID" in raw.p2.columns
        for row in raw.p2.to_dict("records"):
            r = int(row["EXCEL_ROW"])
            status = row["STATUS"].strip().upper()
            if status != "ACTIVE":
                if status != "INACTIVE":
                    self._issue(Severity.WARNING, "P2", "INVALID_STATUS",
                                f"Status '{row['STATUS']}' is not ACTIVE/INACTIVE; row treated as INACTIVE",
                                r, "Status", row["STATUS"])
                inactive += 1
                continue
            rt = " ".join(row["RT_TYPE"].split())
            keyword = row["KEYWORD"].strip()
            if not rt:
                self._issue(Severity.ERROR, "P2", "MISSING_RT_TYPE", "RT TYPE is blank; row ignored", r)
                invalid += 1
                continue
            if not keyword:
                self._issue(Severity.ERROR, "P2", "MISSING_KEYWORD", "Keyword is blank; row ignored", r)
                invalid += 1
                continue
            normalized = self.normalizer.normalize(keyword)
            if not normalized:
                self._issue(Severity.ERROR, "P2", "EMPTY_NORMALIZED_KEYWORD",
                            f"Keyword '{keyword}' contains no letters or digits; row ignored", r, "Keyword", keyword)
                invalid += 1
                continue
            fields = tuple(canonical_name(f) for f in split_list(row["MESSAGE"]))
            fields = tuple(f for f in fields if f)
            if not fields:
                self._issue(Severity.ERROR, "P2", "MISSING_MESSAGE_FIELDS",
                            f"No logical fields in Message for keyword '{keyword}'; row ignored", r, "Message")
                invalid += 1
                continue
            exclusions = tuple(code.strip().upper() for code in split_list(row["RULES"]))
            for code in exclusions:
                if registry.get(code) is None:
                    self._issue(Severity.ERROR, "P2", "UNKNOWN_RULE_CODE",
                                f"Rule '{code}' is not registered (settings.rules or an Intelligence_Lists list). "
                                f"The keyword is still screened; this exclusion can never apply (fail-safe ALERT)",
                                r, "Rules", code)
            match_type = m.default_match_type
            if has_match_type and row.get("MATCH_TYPE", "").strip():
                candidate = row["MATCH_TYPE"].strip().upper()
                if candidate in MatchType.ALL:
                    match_type = candidate
                else:
                    self._issue(Severity.ERROR, "P2", "INVALID_MATCH_TYPE",
                                f"Match_Type '{row['MATCH_TYPE']}' unknown; default {m.default_match_type} used",
                                r, "Match_Type", row["MATCH_TYPE"])
            threshold = None
            if match_type == MatchType.FUZZY:
                threshold = m.fuzzy_default_threshold
                raw_thr = row.get("FUZZY_THRESHOLD", "").strip() if has_threshold else ""
                if raw_thr:
                    try:
                        value = float(raw_thr)
                        if not 0 < value <= 100:
                            raise ValueError
                        threshold = value
                    except ValueError:
                        self._issue(Severity.ERROR, "P2", "INVALID_FUZZY_THRESHOLD",
                                    f"Fuzzy_Threshold '{raw_thr}' must be in (0, 100]; default {threshold} used",
                                    r, "Fuzzy_Threshold", raw_thr)
                if len(normalized.replace(" ", "")) < m.fuzzy_min_keyword_length:
                    self._issue(Severity.WARNING, "P2", "SHORT_FUZZY_KEYWORD",
                                f"FUZZY keyword '{keyword}' is shorter than {m.fuzzy_min_keyword_length} characters;"
                                f" fuzzy matching short strings raises false positives", r, "Keyword", keyword)
            rule_id = row.get("RULE_ID", "").strip() if has_rule_id else ""
            if not rule_id:
                rule_id = f"P2-R{r}"
            if rule_id in seen_ids:
                self._issue(Severity.ERROR, "P2", "DUPLICATE_RULE_ID",
                            f"Rule_ID '{rule_id}' is not unique; renamed to {rule_id}-R{r}", r, "Rule_ID", rule_id)
                rule_id = f"{rule_id}-R{r}"
            signature = (rt_key(rt), normalized, fields, exclusions, match_type, threshold)
            if signature in seen_signatures:
                self._issue(Severity.WARNING, "P2", "DUPLICATE_P2_ROW",
                            f"Same as row {seen_signatures[signature]}; ignored to avoid duplicate alerts",
                            r, "Keyword", keyword)
                continue
            seen_signatures[signature] = r
            seen_ids.add(rule_id)
            display_rt = rt_display.get(rt_key(rt), rt)
            rules.append(ScenarioRule(rule_id, display_rt, keyword, normalized, fields, exclusions, match_type,
                                      threshold, r))
        return rules, {"p2_active_rules": len(rules), "p2_inactive_rows": inactive, "p2_invalid_rows": invalid}

    # ------------------------------------------------------------------ #
    def _intelligence(self, raw: RawMapping):
        entries: Dict[str, List[IntelligenceEntry]] = {}
        display: Dict[str, str] = {}
        all_keys: Set[str] = set()
        seen: Set[Tuple[str, str]] = set()
        inactive = 0
        for row in raw.intelligence.to_dict("records"):
            r = int(row["EXCEL_ROW"])
            list_name = row["LIST"].strip()
            value = row["VALUE"].strip()
            status = row["STATUS"].strip().upper()
            if not list_name:
                self._issue(Severity.ERROR, "Intelligence_Lists", "MISSING_LIST", "List is blank; row ignored", r)
                continue
            key = canonical_name(list_name)
            all_keys.add(key)
            display.setdefault(key, list_name)
            if status != "ACTIVE":
                if status != "INACTIVE":
                    self._issue(Severity.WARNING, "Intelligence_Lists", "INVALID_STATUS",
                                f"Status '{row['STATUS']}' is not ACTIVE/INACTIVE; treated as INACTIVE",
                                r, "Status", row["STATUS"])
                inactive += 1
                continue
            if not value:
                self._issue(Severity.ERROR, "Intelligence_Lists", "MISSING_VALUE", "Value is blank; row ignored", r)
                continue
            normalized = self.normalizer.normalize(value)
            if not normalized:
                self._issue(Severity.ERROR, "Intelligence_Lists", "EMPTY_NORMALIZED_VALUE",
                            f"'{value}' contains no letters or digits; row ignored", r, "Value", value)
                continue
            if (key, normalized) in seen:
                self._issue(Severity.INFO, "Intelligence_Lists", "DUPLICATE_VALUE",
                            f"'{value}' already listed in {list_name} (after normalisation); duplicate ignored",
                            r, "Value", value)
                continue
            seen.add((key, normalized))
            entries.setdefault(key, []).append(IntelligenceEntry(display[key], value, normalized, r))
        total = sum(len(v) for v in entries.values())
        return entries, display, all_keys, {"intelligence_active_values": total, "intelligence_inactive_rows": inactive}

    # ------------------------------------------------------------------ #
    def _cross_checks(self, p1, rt_display, rules, registry, intelligence, display) -> None:
        p2_rts = {rt_key(r.rt_type) for r in rules}
        for key in sorted(p2_rts - set(p1)):
            self._issue(Severity.WARNING, "P2", "ORPHAN_RT_TYPE",
                        f"RT TYPE '{key}' has ACTIVE P2 rules but no P1 row; these rules are never evaluated",
                        field_name="RT TYPE", value=key)
        for key in sorted(set(p1) - p2_rts):
            self._issue(Severity.INFO, "P1", "RT_TYPE_WITHOUT_RULES",
                        f"RT TYPE '{rt_display.get(key, key)}' has no ACTIVE P2 rules", field_name="RT TYPE",
                        value=rt_display.get(key, key))
        used_codes = {code for rule in rules for code in rule.exclusion_rules}
        for code in sorted(used_codes):
            definition = registry.get(code)
            if definition and definition.list_key and not intelligence.get(definition.list_key):
                self._issue(Severity.WARNING, "Intelligence_Lists", "EMPTY_INTELLIGENCE_LIST",
                            f"{code} uses list '{definition.list_key}' which has no ACTIVE values; "
                            f"this exclusion can never trigger", field_name="List", value=definition.list_key)
        referenced = registry.list_keys_in_use()
        for key in sorted(set(intelligence) - referenced):
            self._issue(Severity.INFO, "Intelligence_Lists", "LIST_NOT_REFERENCED",
                        f"List '{display.get(key, key)}' is not referenced by any rule definition",
                        field_name="List", value=display.get(key, key))

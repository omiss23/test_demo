"""Small, dependency-free helpers (hashing, naming, caches, memory)."""
from __future__ import annotations

import hashlib
import os
import re
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable, List, Optional

_CANON_RE = re.compile(r"[^A-Z0-9]+")


def canonical_name(name: object) -> str:
    """Deterministic header/sheet canonicalisation, never fuzzy.

    'Beneficiary Name ' -> 'BENEFICIARY_NAME', 'RT TYPE' -> 'RT_TYPE'.
    """
    if name is None:
        return ""
    return _CANON_RE.sub("_", str(name).strip().upper()).strip("_")


def split_list(value: object, separators: str = ",;|\n") -> List[str]:
    """Split a config cell like 'IN, US;GB' -> ['IN', 'US', 'GB'] (order kept, de-duplicated)."""
    if value is None:
        return []
    text = str(value)
    primary = separators[0]
    for sep in separators[1:]:
        text = text.replace(sep, primary)
    out: List[str] = []
    seen = set()
    for part in text.split(primary):
        item = part.strip()
        if item and item not in seen:
            seen.add(item)
            out.append(item)
    return out


def sha256_file(path: Path, block_size: int = 1 << 20) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(block_size), b""):
            digest.update(block)
    return digest.hexdigest()


def sha256_paths(paths: Iterable[Path]) -> str:
    """Hash of several files (name + content), order-independent."""
    digest = hashlib.sha256()
    for path in sorted(Path(p) for p in paths):
        digest.update(path.name.encode("utf-8"))
        digest.update(sha256_file(path).encode("ascii"))
    return digest.hexdigest()


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def short_id(text: str, length: int = 16) -> str:
    """Stable identifier for a decision (same inputs -> same id across runs)."""
    return hashlib.sha1(text.encode("utf-8")).hexdigest()[:length]


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def version_label(declared: Optional[str], sha256: str) -> str:
    """'2026.10|sha256:1a2b3c4d5e6f' or 'sha256:1a2b3c4d5e6f' when no version is declared."""
    digest = f"sha256:{sha256[:12]}"
    return f"{declared}|{digest}" if declared else digest


class BoundedCache(dict):
    """A dict that empties itself when it reaches `max_size`.

    Cheaper than an LRU (no bookkeeping on reads) and gives a hard memory bound,
    which is what matters when caching per-value results over 5M rows.
    """

    def __init__(self, max_size: int):
        super().__init__()
        self.max_size = max(1, int(max_size))
        self.resets = 0

    def put(self, key, value) -> None:
        if len(self) >= self.max_size:
            self.clear()
            self.resets += 1
        self[key] = value


# --------------------------------------------------------------------------- #
# Memory measurement (works on Linux, macOS and Windows)
# --------------------------------------------------------------------------- #
def current_rss_mb() -> float:
    try:
        import psutil  # type: ignore

        return psutil.Process(os.getpid()).memory_info().rss / (1024 * 1024)
    except Exception:  # pragma: no cover - psutil missing
        return float("nan")


def peak_rss_mb() -> float:
    """Peak resident memory of this process (high-water mark).

    Linux: VmHWM from /proc (ru_maxrss is inherited across fork+exec, so a child
    started by a big parent would report the parent's peak). Windows: peak working set.
    """
    try:
        with open("/proc/self/status", "r") as handle:
            for line in handle:
                if line.startswith("VmHWM:"):
                    return int(line.split()[1]) / 1024
    except OSError:
        pass
    try:
        import psutil  # type: ignore

        info = psutil.Process(os.getpid()).memory_info()
        peak = getattr(info, "peak_wset", None)  # Windows
        if peak:
            return peak / (1024 * 1024)
    except Exception:  # pragma: no cover
        pass
    try:
        import resource  # Unix only

        usage = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        # Linux reports KiB, macOS reports bytes
        return usage / (1024 * 1024) if sys.platform == "darwin" else usage / 1024
    except Exception:  # pragma: no cover
        return current_rss_mb()

"""Exception hierarchy.

Fatal problems raise one of these; recoverable problems are recorded as
`ValidationIssue` objects and written to the validation reports instead.
"""


class MonitoringError(Exception):
    """Base class for all framework errors."""


class ConfigurationError(MonitoringError):
    """Mapping workbook, schema configuration or settings cannot be used."""


class InputFileError(MonitoringError):
    """The transaction file cannot be read (missing, unreadable, no MESSAGE_KEY ...)."""


class SchemaMappingError(MonitoringError):
    """Required logical fields could not be resolved and the policy is FAIL_FILE."""


class DataQualityError(MonitoringError):
    """A data-quality policy (e.g. duplicate MESSAGE_KEY with FAIL_FILE) stopped the file."""

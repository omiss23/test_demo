"""FUZZY: approximate token-window similarity, only for keywords configured FUZZY.

Uncontrolled fuzzy matching over 5M rows is the classic performance trap, so it
is staged:

Stage 2 - vocabulary blocking (cheap, vectorised):
    the distinct tokens of the batch are compared once with every keyword token
    (rapidfuzz.process.cdist, C++). A token similar to a keyword token is cached
    with the specs it may belong to; values containing none of those tokens are
    never touched again. Names repeat heavily, so after a few chunks almost every
    token is already cached and blocking costs close to nothing.
    Blocking cut-off = threshold - fuzzy_block_margin, because a window whose
    overall similarity is >= threshold must contain at least one token whose
    similarity is close to the threshold (the window score is a length-weighted
    average of its token scores when tokens align).

Stage 3 - verification (expensive, candidates only):
    windows of n-1 .. n+2 tokens around each blocking token are scored with
    fuzz.ratio against the whole keyword, both as written and with spaces
    removed ('LASHKAR E TAIBA' vs 'LASHKARETAIBA'). The best non-overlapping
    windows >= threshold become hits; MATCH_SCORE is the similarity.

Requires rapidfuzz. Without it, FUZZY rules raise a configuration error at
start-up (no silent downgrade).
"""
from __future__ import annotations

from collections import defaultdict
from typing import Dict, List, Sequence, Set, Tuple

import numpy as np

from ..exceptions import ConfigurationError
from ..models import Hit, KeywordSpec, MatchType
from ..settings import MatchingSettings

_MATRIX_BUDGET = 4_000_000   # cells per cdist batch (float32 -> ~16 MB)


def rapidfuzz_available() -> bool:
    try:
        import rapidfuzz  # noqa: F401

        return True
    except ImportError:
        return False


class FuzzyMatcher:
    def __init__(self, specs: Sequence[KeywordSpec], settings: MatchingSettings):
        self.specs: Dict[int, KeywordSpec] = {s.spec_id: s for s in specs if s.match_type == MatchType.FUZZY}
        self.candidates = 0
        if not self.specs:
            return
        if not rapidfuzz_available():
            raise ConfigurationError("Match type FUZZY requires the 'rapidfuzz' package. Install it or change "
                                     "Match_Type for: " + ", ".join(s.keyword for s in self.specs.values()))
        from rapidfuzz import fuzz, process

        self._fuzz = fuzz
        self._process = process
        self._block_map: Dict[str, List[Tuple[int, float]]] = defaultdict(list)
        for spec in self.specs.values():
            tokens = [t for t in spec.tokens if len(t) >= settings.fuzzy_min_block_token_length]
            if not tokens:
                tokens = [max(spec.tokens, key=len)]
            if len(spec.tokens) > 1:                     # also block on 'LASHKARETAIBA' (spaces removed)
                tokens.append("".join(spec.tokens))
            cutoff = max(0.0, float(spec.threshold) - float(settings.fuzzy_block_margin))
            for token in set(tokens):
                self._block_map[token].append((spec.spec_id, cutoff))
        self._block_tokens = list(self._block_map)
        self._min_cutoff = min(c for entries in self._block_map.values() for _, c in entries)
        # Indel ratio r = 2*matches/(l1+l2) >= c  needs  l2 in [l1*c/(200-c), l1*(200-c)/c]
        c = max(1.0, self._min_cutoff)
        lengths = [len(t) for t in self._block_tokens]
        self._len_lo = int(min(lengths) * c / (200.0 - c))
        self._len_hi = int(max(lengths) * (200.0 - c) / c) + 1
        self._numeric_keywords = any(t.isdigit() for t in self._block_tokens)
        # token caches as sets -> C-level set algebra per batch (bounded)
        self._seen: Set[str] = set()
        self._similar: Dict[str, Tuple[int, ...]] = {}
        self._cache_limit = max(20_000, settings.value_cache_size)   # tokens remembered per matcher
        self._compact = {sid: s.keyword.replace(" ", "") for sid, s in self.specs.items()}

    def __bool__(self) -> bool:
        return bool(self.specs)

    # ------------------------------------------------------------------ #
    def match_values(self, values: Sequence[str]) -> Dict[int, List[Hit]]:
        from .candidate_generator import ValueBatch

        return self.match_batch(ValueBatch(list(values)))

    def match_batch(self, batch) -> Dict[int, List[Hit]]:
        """Stage 2 + 3 for a ValueBatch (see candidate_generator.ValueBatch)."""
        if not self.specs or not batch.values:
            return {}
        vocabulary = set(batch.text.split())
        vocabulary.discard("\x00")
        if len(self._seen) > self._cache_limit:          # bounded memory
            self._seen.clear()
            self._similar.clear()
        new_tokens = vocabulary - self._seen
        if new_tokens:
            lo, hi, numeric = self._len_lo, self._len_hi, self._numeric_keywords
            remember: List[str] = []
            eligible: List[str] = []
            for token in new_tokens:
                if not numeric and token.isdigit():     # references/amounts: never cached, never similar
                    continue
                remember.append(token)
                if lo <= len(token) <= hi:
                    eligible.append(token)
            if eligible:
                self._similar.update(self._block(eligible))
            self._seen.update(remember)
        similar = self._similar
        matched = {t: similar[t] for t in vocabulary.intersection(similar)}
        if not matched:
            return {}

        results: Dict[int, List[Hit]] = {}
        for index in self._values_containing(batch, matched):
            tokens = batch.values[index].split(" ")
            positions: Dict[int, List[int]] = {}
            for t_index, token in enumerate(tokens):
                spec_ids = matched.get(token)
                if spec_ids:
                    for spec_id in spec_ids:
                        positions.setdefault(spec_id, []).append(t_index)
            if not positions:
                continue
            self.candidates += len(positions)
            hits: List[Hit] = []
            for spec_id, token_positions in positions.items():
                hits.extend(self._verify(spec_id, tokens, token_positions))
            if hits:
                results[index] = hits
        return results

    @staticmethod
    def _values_containing(batch, tokens) -> List[int]:
        """Indices of values containing any of `tokens` (as whole tokens)."""
        from .candidate_generator import KIND_TOKEN, Probe, ahocorasick_available, make_generator

        if ahocorasick_available():
            generator = make_generator([Probe(t, KIND_TOKEN, 0, 0) for t in tokens], "aho_corasick")
            return sorted({c[0] for c in generator.scan_batch(batch)})
        wanted = set(tokens)
        return [i for i, v in enumerate(batch.values) if v and not wanted.isdisjoint(v.split(" "))]

    # ------------------------------------------------------------------ #
    def _block(self, tokens: List[str]) -> Dict[str, Tuple[int, ...]]:
        found: Dict[str, Set[int]] = {}
        batch_size = max(1_000, _MATRIX_BUDGET // max(1, len(self._block_tokens)))
        for start in range(0, len(tokens), batch_size):
            batch = tokens[start:start + batch_size]
            matrix = self._process.cdist(self._block_tokens, batch, scorer=self._fuzz.ratio,
                                         score_cutoff=self._min_cutoff, dtype=np.float32, workers=-1)
            rows, cols = np.nonzero(matrix)
            for r, c in zip(rows.tolist(), cols.tolist()):
                score = float(matrix[r, c])
                for spec_id, cutoff in self._block_map[self._block_tokens[r]]:
                    if score >= cutoff:
                        found.setdefault(batch[c], set()).add(spec_id)
        return {t: tuple(sorted(ids)) for t, ids in found.items()}   # only tokens similar to a keyword token

    def _verify(self, spec_id: int, tokens: List[str], positions: List[int]) -> List[Hit]:
        spec = self.specs[spec_id]
        n = len(spec.tokens)
        threshold = float(spec.threshold)
        ratio = self._fuzz.ratio
        compact_kw = self._compact[spec_id]
        # n-1 .. n+2 tokens, plus single tokens for concatenations ('LASHKARETAIBA')
        sizes = sorted({w for w in list(range(max(1, n - 1), n + 3)) + [1] if w <= len(tokens)})
        windows = set()
        for p in positions:
            for w in sizes:
                for s in range(max(0, p - w + 1), min(p, len(tokens) - w) + 1):
                    windows.add((s, w))
        scored = []
        for s, w in windows:
            window_tokens = tokens[s:s + w]
            score = ratio(spec.keyword, " ".join(window_tokens), score_cutoff=threshold)
            compact_score = ratio(compact_kw, "".join(window_tokens), score_cutoff=threshold)
            best = max(score, compact_score)
            if best >= threshold:
                scored.append((-best, abs(w - n), s, w))
        if not scored:
            return []
        scored.sort()
        offsets = []
        pos = 0
        for t in tokens:
            offsets.append(pos)
            pos += len(t) + 1
        taken: List[Tuple[int, int]] = []
        hits: List[Hit] = []
        for neg_score, _, s, w in scored:
            e = s + w - 1
            if any(not (e < a or s > b) for a, b in taken):
                continue
            taken.append((s, e))
            hits.append(Hit(spec_id, offsets[s], offsets[e] + len(tokens[e]), round(-neg_score, 2), ""))
        return hits

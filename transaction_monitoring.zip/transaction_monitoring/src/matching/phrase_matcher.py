"""PHRASE: keyword tokens appear in order with at most `max_gap` other tokens
between consecutive keyword tokens (proximity phrase).

    keyword 'ISLAMIC STATE', max_gap 2
    'ISLAMIC STATE OF IRAQ'        -> match (score 100, contiguous)
    'ISLAMIC REVIVAL STATE'        -> match (1 intervening token, score 95)
    'STATE ISLAMIC'                -> no match (order matters)

Stage 2 only flags values containing the keyword's longest token (the anchor);
the full order/gap check below (stage 3) runs on those candidates only.
Score = 100 - 5 x intervening tokens (floor 50).
"""
from __future__ import annotations

from typing import Dict, List, Optional, Sequence, Tuple

from ..models import Hit, KeywordSpec, MatchType
from .candidate_generator import KIND_PHRASE_ANCHOR, Probe

GAP_PENALTY = 5.0


class PhraseMatcher:
    def __init__(self, specs: Sequence[KeywordSpec]):
        self.specs: Dict[int, KeywordSpec] = {s.spec_id: s for s in specs if s.match_type == MatchType.PHRASE}

    @staticmethod
    def probes(specs: Sequence[KeywordSpec]) -> List[Probe]:
        out: List[Probe] = []
        for spec in specs:
            if spec.match_type != MatchType.PHRASE:
                continue
            anchor = max(spec.tokens, key=len)          # most selective token
            out.append(Probe(anchor, KIND_PHRASE_ANCHOR, spec.spec_id, 0))
        return out

    def verify(self, value: str, spec_id: int, tokens: Optional[List[str]] = None) -> List[Hit]:
        spec = self.specs[spec_id]
        tokens = tokens if tokens is not None else value.split(" ")
        wanted = spec.tokens
        positions: Dict[str, List[int]] = {}
        wanted_set = set(wanted)
        for idx, token in enumerate(tokens):
            if token in wanted_set:
                positions.setdefault(token, []).append(idx)
        if any(t not in positions for t in wanted):
            return []
        offsets = []
        pos = 0
        for t in tokens:
            offsets.append(pos)
            pos += len(t) + 1
        hits: List[Hit] = []
        last_end_token = -1
        for first in positions[wanted[0]]:
            if first <= last_end_token:
                continue
            path = _search(positions, wanted, 1, first, spec.max_gap)
            if path is None:
                continue
            end_token, gaps = path
            score = max(50.0, 100.0 - GAP_PENALTY * gaps)
            hits.append(Hit(spec_id, offsets[first], offsets[end_token] + len(tokens[end_token]), score, ""))
            last_end_token = end_token
        return hits


def _search(positions: Dict[str, List[int]], wanted: Tuple[str, ...], k: int, prev: int,
            max_gap: int) -> Optional[Tuple[int, int]]:
    """Exact DFS: place wanted[k] after `prev` within `max_gap`; returns (last index, total gaps)."""
    if k == len(wanted):
        return prev, 0
    for p in positions[wanted[k]]:
        if p <= prev:
            continue
        gap = p - prev - 1
        if gap > max_gap:
            break
        rest = _search(positions, wanted, k + 1, p, max_gap)
        if rest is not None:
            return rest[0], rest[1] + gap
    return None

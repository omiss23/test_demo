"""ColumnMatcher: all compiled matching structures for one set of keyword specs.

Built once per file by the search plan (identical spec sets share one matcher),
then applied to the *distinct* values of a column in each chunk, as a batch:

    distinct raw values -> normalise the whole batch (stage 1, C-level string ops)
                        -> one automaton pass over the batch + exact set lookup (stage 2)
                        -> phrase / fuzzy verification on candidate values only (stage 3)

Per-value Python work happens only for values that produced a candidate, so
the cost per chunk is dominated by C code regardless of the keyword count.
"""
from __future__ import annotations

from collections import defaultdict
from typing import Dict, List, Sequence, Tuple

from ..models import Hit, KeywordSpec
from ..normalization.text_normalizer import TextNormalizer
from ..settings import MatchingSettings
from .candidate_generator import KIND_SUBSTRING, KIND_TOKEN, ValueBatch, make_generator
from .exact_matcher import ExactMatcher
from .fuzzy_matcher import FuzzyMatcher
from .phrase_matcher import PhraseMatcher
from .substring_matcher import SubstringMatcher
from .token_matcher import VARIANT_NAMES, TokenMatcher

MatchResult = Tuple[str, Tuple[Hit, ...]]   # (normalised value, hits)


class ColumnMatcher:
    def __init__(self, specs: Sequence[KeywordSpec], normalizer: TextNormalizer, settings: MatchingSettings):
        self.specs: Dict[int, KeywordSpec] = {s.spec_id: s for s in specs}
        self.normalizer = normalizer
        self.exact = ExactMatcher(specs)
        self.phrase = PhraseMatcher(specs)
        self.fuzzy = FuzzyMatcher(specs, settings)
        probes = TokenMatcher.probes(specs, settings) + PhraseMatcher.probes(specs) + SubstringMatcher.probes(specs)
        self.generator = make_generator(probes, settings.candidate_backend)
        self._needs_scan = bool(probes)
        self.last_empty: List[int] = []
        # statistics
        self.values_scanned = 0
        self.stage2_candidates = 0
        self.verified_hits = 0

    @property
    def backend_name(self) -> str:
        return self.generator.backend_name

    def match_values(self, raw_values: Sequence[str]) -> Dict[int, MatchResult]:
        """Return {index in raw_values: (normalised value, hits)} for values with at least one hit.

        `last_empty` afterwards holds the indices whose normalised value is empty (for DQ counts).
        """
        normalized = self.normalizer.normalize_many(list(raw_values))
        self.last_empty = [i for i, v in enumerate(normalized) if not v]
        self.values_scanned += len(normalized)
        hits = self._match_normalized(normalized)
        return {i: (normalized[i], tuple(h)) for i, h in hits.items()}

    def match_one(self, raw_value: str) -> MatchResult:
        result = self.match_values([raw_value])
        return result.get(0, (self.normalizer.normalize(raw_value), ()))

    def _match_normalized(self, values: List[str]) -> Dict[int, List[Hit]]:
        out: Dict[int, List[Hit]] = defaultdict(list)
        if self.exact:
            present = self.exact.keys.intersection(values)
            if present:
                for index, value in enumerate(values):
                    if value in present:
                        out[index].extend(self.exact.match(value))
        batch = ValueBatch(values) if (self._needs_scan or self.fuzzy) else None
        if self._needs_scan:
            candidates = self.generator.scan_batch(batch)
            self.stage2_candidates += len(candidates)
            phrase_ids: Dict[int, set] = defaultdict(set)
            for index, kind, ref, variant, start, end in candidates:
                if kind == KIND_TOKEN:
                    out[index].append(Hit(ref, start, end, 100.0, VARIANT_NAMES[variant]))
                elif kind == KIND_SUBSTRING:
                    out[index].append(Hit(ref, start, end,
                                          SubstringMatcher.coverage_score(values[index], start, end), ""))
                else:                                   # PHRASE anchor -> stage 3
                    phrase_ids[index].add(ref)
            for index, spec_ids in phrase_ids.items():
                value = values[index]
                tokens = value.split(" ")
                for spec_id in sorted(spec_ids):
                    found = self.phrase.verify(value, spec_id, tokens)
                    if found:
                        out[index].extend(found)
        if self.fuzzy:
            before = self.fuzzy.candidates
            for index, found in self.fuzzy.match_batch(batch).items():
                out[index].extend(found)
            self.stage2_candidates += self.fuzzy.candidates - before
        result: Dict[int, List[Hit]] = {}
        for index, hits in out.items():
            if not hits:
                continue
            if len(hits) > 1:
                hits.sort(key=lambda h: (h.start, h.end, h.spec_id, h.variant))
            self.verified_hits += len(hits)
            result[index] = hits
        return result

    def stats(self) -> Dict[str, int]:
        return {
            "values_scanned": self.values_scanned,
            "stage2_candidates": self.stage2_candidates,
            "verified_hits": self.verified_hits,
        }

"""SUBSTRING (opt-in extension): raw containment without word boundaries.

'ISIS' inside 'ISISWORLD'. Useful for concatenation evasion, noisy for short
keywords, therefore never a default. The score expresses how much of the
enclosing token(s) the keyword covers (100 = aligned with token boundaries),
so investigators can sort partial-word hits to the bottom.
"""
from __future__ import annotations

from typing import List, Sequence

from ..models import KeywordSpec, MatchType
from .candidate_generator import KIND_SUBSTRING, Probe


class SubstringMatcher:
    @staticmethod
    def probes(specs: Sequence[KeywordSpec]) -> List[Probe]:
        return [Probe(s.keyword, KIND_SUBSTRING, s.spec_id, 0) for s in specs if s.match_type == MatchType.SUBSTRING]

    @staticmethod
    def coverage_score(value: str, start: int, end: int) -> float:
        left = value.rfind(" ", 0, start) + 1
        right = value.find(" ", end)
        right = len(value) if right == -1 else right
        span = right - left
        return round(100.0 * (end - start) / span, 2) if span else 100.0

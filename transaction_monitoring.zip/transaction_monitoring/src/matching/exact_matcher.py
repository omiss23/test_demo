"""EXACT: the whole normalised value equals the normalised keyword (hash lookup, O(1))."""
from __future__ import annotations

from typing import Dict, List, Sequence

from ..models import Hit, KeywordSpec, MatchType


class ExactMatcher:
    def __init__(self, specs: Sequence[KeywordSpec]):
        self._index: Dict[str, List[int]] = {}
        for spec in specs:
            if spec.match_type == MatchType.EXACT:
                self._index.setdefault(spec.keyword, []).append(spec.spec_id)
        self.keys = frozenset(self._index)     # batch pre-filter: keys.intersection(values)

    def __bool__(self) -> bool:
        return bool(self._index)

    def match(self, value: str) -> List[Hit]:
        ids = self._index.get(value)
        if not ids:
            return []
        return [Hit(spec_id, 0, len(value), 100.0, "") for spec_id in ids]

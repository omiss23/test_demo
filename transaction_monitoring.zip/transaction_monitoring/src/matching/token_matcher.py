"""TOKEN: the keyword occurs on token boundaries (default match type).

'ABC' matches 'ABC LTD' and 'PAID TO ABC' but not 'ABCD TRADING'.
Multi-token keywords must appear as a contiguous token sequence.

Compact variant (settings.matching.compact_variants): a multi-token keyword
is also searched with its spaces removed, so 'AL QAIDA' finds 'ALQAIDA'
(a common evasion). Variants shorter than compact_variant_min_length are not
generated, to keep false positives down. Hits are flagged MATCH_VARIANT=COMPACT.
"""
from __future__ import annotations

from typing import List, Sequence

from ..models import KeywordSpec, MatchType
from ..settings import MatchingSettings
from .candidate_generator import KIND_TOKEN, Probe

VARIANT_NAMES = {0: "", 1: "COMPACT"}


class TokenMatcher:
    @staticmethod
    def probes(specs: Sequence[KeywordSpec], settings: MatchingSettings) -> List[Probe]:
        out: List[Probe] = []
        for spec in specs:
            if spec.match_type != MatchType.TOKEN:
                continue
            out.append(Probe(spec.keyword, KIND_TOKEN, spec.spec_id, 0))
            if settings.compact_variants and len(spec.tokens) > 1:
                compact = spec.keyword.replace(" ", "")
                if len(compact) >= settings.compact_variant_min_length:
                    out.append(Probe(compact, KIND_TOKEN, spec.spec_id, 1))
        return out

"""One-time keyword index: distinct (keyword, match type, parameters) specs.

10,000 P2 rows usually collapse to fewer distinct specs (the same keyword is
often used in several scenarios). Each spec is matched once per value; hits
are fanned out to every P2 rule that uses the spec via the search plan.
"""
from __future__ import annotations

from typing import Dict, List, Optional, Tuple

from ..exceptions import ConfigurationError
from ..models import KeywordSpec, MatchType, Severity, ValidationIssue
from ..settings import MatchingSettings
from .fuzzy_matcher import rapidfuzz_available


class KeywordRegistry:
    def __init__(self, settings: MatchingSettings):
        self.settings = settings
        self.specs: Dict[int, KeywordSpec] = {}
        self._by_signature: Dict[Tuple, int] = {}
        self.issues: List[ValidationIssue] = []
        self._fuzzy_ok = rapidfuzz_available()

    def register(self, normalized_keyword: str, match_type: str, threshold: Optional[float]) -> int:
        if match_type == MatchType.FUZZY and not self._fuzzy_ok:
            policy = str(self.settings.fuzzy_unavailable_policy).upper()
            if policy != "DOWNGRADE_TO_TOKEN":
                raise ConfigurationError(
                    f"Keyword '{normalized_keyword}' uses Match_Type FUZZY but the 'rapidfuzz' package is not "
                    f"installed. Install rapidfuzz, change Match_Type, or set "
                    f"matching.fuzzy_unavailable_policy: DOWNGRADE_TO_TOKEN")
            self.issues.append(ValidationIssue(
                Severity.ERROR, "P2", "FUZZY_DOWNGRADED",
                f"rapidfuzz is not installed: FUZZY keyword '{normalized_keyword}' is screened as TOKEN "
                f"(exact token match only - spelling variants will NOT be found)", field="Match_Type",
                value=normalized_keyword))
            match_type = MatchType.TOKEN
        max_gap = int(self.settings.phrase_max_gap) if match_type == MatchType.PHRASE else 0
        if match_type == MatchType.FUZZY:
            threshold = float(threshold if threshold is not None else self.settings.fuzzy_default_threshold)
        else:
            threshold = None
        signature = (normalized_keyword, match_type, threshold, max_gap)
        spec_id = self._by_signature.get(signature)
        if spec_id is None:
            spec_id = len(self.specs)
            self.specs[spec_id] = KeywordSpec(spec_id, normalized_keyword, match_type, threshold, max_gap,
                                              tuple(normalized_keyword.split(" ")))
            self._by_signature[signature] = spec_id
        return spec_id

    def counts_by_match_type(self) -> Dict[str, int]:
        out: Dict[str, int] = {}
        for spec in self.specs.values():
            out[spec.match_type] = out.get(spec.match_type, 0) + 1
        return out

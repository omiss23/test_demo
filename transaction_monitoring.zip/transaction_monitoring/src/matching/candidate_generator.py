"""Stage 2 of matching: candidate generation with a single keyword automaton.

All TOKEN / PHRASE / SUBSTRING probes for a column are compiled once into one
search structure, so scanning a value costs O(len(value) + matches) no matter
how many keywords there are. 5,000,000 rows x 10,000 keywords therefore never
becomes 50 billion comparisons.

Word boundaries without regex: values are normalised to tokens separated by a
single space, so a probe " al qaida " (padded) can only match on token
boundaries inside " <value> ".

Backends (identical results, verified by tests):
  aho_corasick  C implementation (pyahocorasick) - fastest, used when installed
  pure_python   hash-index on tokens, no third-party dependency (air-gapped fallback)
"""
from __future__ import annotations

import logging
from bisect import bisect_right
from collections import defaultdict
from typing import Dict, List, NamedTuple, Sequence, Tuple

import numpy as np

log = logging.getLogger(__name__)

# Probe kinds
KIND_TOKEN = 0           # token-boundary occurrence of the whole probe text
KIND_PHRASE_ANCHOR = 1   # token-boundary occurrence of a PHRASE keyword's anchor token
KIND_SUBSTRING = 2       # raw substring occurrence


class Probe(NamedTuple):
    text: str        # normalised probe text
    kind: int
    ref: int         # spec id (or intelligence entry index)
    variant: int     # 0 = keyword as written, 1 = compact variant


Candidate = Tuple[int, int, int, int, int]   # (kind, ref, variant, start, end) in normalised value offsets


def ahocorasick_available() -> bool:
    try:
        import ahocorasick  # noqa: F401

        return True
    except ImportError:
        return False


def make_generator(probes: Sequence[Probe], backend: str = "auto") -> "CandidateGenerator":
    backend = (backend or "auto").lower()
    if backend in ("auto", "aho_corasick") and ahocorasick_available():
        return AhoCorasickGenerator(probes)
    if backend == "aho_corasick":
        log.warning("pyahocorasick is not installed; falling back to the pure-Python token index")
    return TokenIndexGenerator(probes)


class ValueBatch:
    """All distinct normalised values of a column in one chunk, laid out in a single string.

        text = " v0 \\x00 v1 \\x00 v2 "      (each value padded by spaces, NUL between values)

    One automaton pass over `text` scans the whole chunk at C speed; a match is
    mapped back to its value with a binary search over the start offsets.
    Patterns never contain NUL, so no match can span two values.
    """

    __slots__ = ("values", "text", "starts")

    def __init__(self, values: Sequence[str]):
        self.values = values
        self.text = " " + " \x00 ".join(values) + " " if values else ""
        n = len(values)
        if n:
            lengths = np.fromiter(map(len, values), dtype=np.int64, count=n)
            starts = np.empty(n, dtype=np.int64)
            starts[0] = 1
            np.cumsum(lengths[:-1] + 3, out=starts[1:])
            starts[1:] += 1
            self.starts = starts.tolist()
        else:
            self.starts = []

    def index_of(self, text_position: int) -> int:
        return bisect_right(self.starts, text_position) - 1


BatchCandidate = Tuple[int, int, int, int, int, int]   # (value index, kind, ref, variant, start, end)


class CandidateGenerator:
    backend_name = "base"

    def __init__(self, probes: Sequence[Probe]):
        self.probe_count = len(probes)

    def scan(self, value: str) -> List[Candidate]:  # pragma: no cover - interface
        raise NotImplementedError

    def scan_batch(self, batch: ValueBatch) -> List[BatchCandidate]:
        out: List[BatchCandidate] = []
        for index, value in enumerate(batch.values):
            if value:
                for candidate in self.scan(value):
                    out.append((index,) + candidate)
        return out


class AhoCorasickGenerator(CandidateGenerator):
    backend_name = "aho_corasick"

    def __init__(self, probes: Sequence[Probe]):
        super().__init__(probes)
        import ahocorasick

        grouped: Dict[str, List[Tuple[int, int, int]]] = defaultdict(list)
        for probe in probes:
            pattern = probe.text if probe.kind == KIND_SUBSTRING else f" {probe.text} "
            grouped[pattern].append((probe.kind, probe.ref, probe.variant))
        self._automaton = None
        if grouped:
            automaton = ahocorasick.Automaton()
            for pattern, payloads in grouped.items():
                automaton.add_word(pattern, (len(pattern), tuple(payloads)))
            automaton.make_automaton()
            self._automaton = automaton

    def scan(self, value: str) -> List[Candidate]:
        if self._automaton is None or not value:
            return []
        out: List[Candidate] = []
        for end_index, (length, payloads) in self._automaton.iter(f" {value} "):
            i = end_index - length + 1          # start index in the padded text
            for kind, ref, variant in payloads:
                if kind == KIND_SUBSTRING:
                    out.append((kind, ref, variant, i - 1, i - 1 + length))
                else:
                    out.append((kind, ref, variant, i, i + length - 2))
        return out

    def scan_batch(self, batch: ValueBatch) -> List[BatchCandidate]:
        if self._automaton is None or not batch.values:
            return []
        out: List[BatchCandidate] = []
        starts = batch.starts
        for end_index, (length, payloads) in self._automaton.iter(batch.text):
            i = end_index - length + 1
            index = bisect_right(starts, i + 1) - 1
            base = starts[index]
            for kind, ref, variant in payloads:
                if kind == KIND_SUBSTRING:
                    out.append((index, kind, ref, variant, i - base, i - base + length))
                else:
                    out.append((index, kind, ref, variant, i + 1 - base, i + 1 - base + length - 2))
        return out


class TokenIndexGenerator(CandidateGenerator):
    """Dependency-free backend: first-token hash index + exact token-sequence check."""

    backend_name = "pure_python"

    def __init__(self, probes: Sequence[Probe]):
        super().__init__(probes)
        self._by_first: Dict[str, List[Tuple[Tuple[str, ...], int, int, int]]] = defaultdict(list)
        self._substrings: List[Tuple[str, int, int]] = []
        for probe in probes:
            if probe.kind == KIND_SUBSTRING:
                self._substrings.append((probe.text, probe.ref, probe.variant))
            else:
                tokens = tuple(probe.text.split(" "))
                self._by_first[tokens[0]].append((tokens, probe.kind, probe.ref, probe.variant))
        self._by_first = dict(self._by_first)

    def scan(self, value: str) -> List[Candidate]:
        if not value:
            return []
        out = self._scan_tokens(value)
        for pattern, ref, variant in self._substrings:
            start = value.find(pattern)
            while start != -1:
                out.append((KIND_SUBSTRING, ref, variant, start, start + len(pattern)))
                start = value.find(pattern, start + 1)
        return out

    def _scan_tokens(self, value: str) -> List[Candidate]:
        out: List[Candidate] = []
        by_first = self._by_first
        if not by_first:
            return out
        tokens = value.split(" ")
        offsets = None
        for i, token in enumerate(tokens):
            entries = by_first.get(token)
            if entries is None:
                continue
            if offsets is None:
                offsets = []
                pos = 0
                for t in tokens:
                    offsets.append(pos)
                    pos += len(t) + 1
            for probe_tokens, kind, ref, variant in entries:
                n = len(probe_tokens)
                if n == 1 or tuple(tokens[i:i + n]) == probe_tokens:
                    last = i + n - 1
                    out.append((kind, ref, variant, offsets[i], offsets[last] + len(tokens[last])))
        return out

    def scan_batch(self, batch: ValueBatch) -> List[BatchCandidate]:
        """Pre-filter with C-level set operations, then scan only values that can match."""
        if not batch.values:
            return []
        out: List[BatchCandidate] = []
        if self._by_first:
            firsts = set(batch.text.split()).intersection(self._by_first)
            if firsts:
                isdisjoint = firsts.isdisjoint
                for index, value in enumerate(batch.values):
                    if value and not isdisjoint(value.split(" ")):
                        for candidate in self._scan_tokens(value):
                            out.append((index,) + candidate)
        text, starts = batch.text, batch.starts
        for pattern, ref, variant in self._substrings:
            i = text.find(pattern)
            while i != -1:
                index = bisect_right(starts, i + 1) - 1
                base = starts[index]
                out.append((index, KIND_SUBSTRING, ref, variant, i - base, i - base + len(pattern)))
                i = text.find(pattern, i + 1)
        return out

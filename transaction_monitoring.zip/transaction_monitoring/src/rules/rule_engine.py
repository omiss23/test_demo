"""RuleEngine: evaluate every exclusion rule listed on a P2 row for one occurrence.

All listed rules are evaluated (not short-circuited) so the audit trail shows
the outcome of each one. Fail-safe: an unknown rule code or a classifier error
yields UNKNOWN_RULE / ERROR, which never excludes - the hit stays an ALERT and
the problem is reported.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional, Sequence

from ..context.context_engine import ContextEngine
from ..models import ClassificationResult, MatchContext, RuleStatus
from .rule_registry import RuleRegistry


@dataclass(frozen=True)
class RuleOutcome:
    rule_code: str
    status: str
    result: Optional[ClassificationResult]
    detail: str = ""

    @property
    def triggered(self) -> bool:
        return self.status == RuleStatus.TRIGGERED

    def short(self) -> str:
        if self.result is None:
            return f"{self.rule_code}={self.status}"
        return f"{self.rule_code}={self.status}({self.result.classification},{self.result.confidence:.2f})"


class RuleEngine:
    def __init__(self, registry: RuleRegistry, context_engine: ContextEngine):
        self.registry = registry
        self.context = context_engine
        self.errors = 0

    def evaluate(self, rule_codes: Sequence[str], ctx: MatchContext) -> List[RuleOutcome]:
        outcomes: List[RuleOutcome] = []
        for code in rule_codes:
            definition = self.registry.get(code)
            if definition is None:
                outcomes.append(RuleOutcome(code, RuleStatus.UNKNOWN_RULE, None,
                                            f"{code} is not a registered rule; not applied (fail-safe)"))
                continue
            try:
                result = self.context.classify(definition.classifier_key, ctx)
            except Exception as exc:  # fail-safe: never exclude on error
                self.errors += 1
                outcomes.append(RuleOutcome(code, RuleStatus.ERROR, None,
                                            f"{code} could not be evaluated ({type(exc).__name__}: {exc}); "
                                            f"not applied (fail-safe)"))
                continue
            triggered = result.matched and (definition.min_confidence is None
                                            or result.confidence >= definition.min_confidence)
            outcomes.append(RuleOutcome(code, RuleStatus.TRIGGERED if triggered else RuleStatus.NOT_TRIGGERED,
                                        result, result.reason))
        return outcomes

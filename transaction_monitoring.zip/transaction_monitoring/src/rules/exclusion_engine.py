"""ExclusionEngine: combine rule outcomes into the final decision.

A P2 row lists exclusion rules ("EXCL_INDV,EXCL_TOPONYM"). The occurrence is
EXCLUDED when at least one listed rule TRIGGERS (logical OR) - each rule
describes an independent benign explanation. Otherwise it is an ALERT.
The primary exclusion is the first triggered rule in P2 order.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional, Sequence

from ..models import Decision
from .rule_engine import RuleOutcome


@dataclass(frozen=True)
class ExclusionDecision:
    decision: str
    primary: Optional[RuleOutcome]
    triggered: List[RuleOutcome]


class ExclusionEngine:
    def decide(self, outcomes: Sequence[RuleOutcome]) -> ExclusionDecision:
        triggered = [o for o in outcomes if o.triggered]
        if triggered:
            return ExclusionDecision(Decision.EXCLUDED, triggered[0], triggered)
        return ExclusionDecision(Decision.ALERT, None, [])

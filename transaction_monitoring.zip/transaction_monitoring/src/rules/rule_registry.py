"""Rule registry: P2 rule code -> classifier configuration.

Rule codes are configuration, not code. settings.yaml declares the built-in
codes (EXCL_INDV, EXCL_TOPONYM, EXCL_SECULAR, EXCL_RELIGIOUS) and, when
`auto_register_list_rules` is on, every list that appears in the
Intelligence_Lists sheet automatically gets an EXCL_<LIST> rule. Adding a new
list such as 'Bank' with values and using EXCL_BANK in P2 therefore needs no
Python change.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, Optional

from ..exceptions import ConfigurationError
from ..settings import Settings
from ..utils import canonical_name

CLASSIFIER_TYPES = ("individual", "intelligence_list", "toponym", "secular", "religious")
DEFAULT_LIST_FOR_CLASSIFIER = {"toponym": "TOPONYM", "secular": "SECULAR", "religious": "RELIGIOUS"}


@dataclass(frozen=True)
class RuleDefinition:
    code: str
    classifier: str                 # one of CLASSIFIER_TYPES
    list_key: Optional[str]         # canonical Intelligence_Lists list name for list classifiers
    span_policy: str
    min_confidence: Optional[float]
    description: str
    origin: str                     # settings | auto

    @property
    def classifier_key(self) -> str:
        """Key used to share classifier instances (one per list / per type)."""
        if self.classifier == "individual":
            return "individual"
        return f"list:{self.list_key}:{self.span_policy}"


class RuleRegistry:
    def __init__(self, settings: Settings, list_keys: Iterable[str]):
        self.definitions: Dict[str, RuleDefinition] = {}
        for code, raw in settings.rules.items():
            code = code.strip().upper()
            classifier = str(raw.get("classifier", "")).strip().lower()
            if classifier not in CLASSIFIER_TYPES:
                raise ConfigurationError(
                    f"settings.rules.{code}: classifier '{classifier}' is not one of {CLASSIFIER_TYPES}")
            list_key = None
            if classifier != "individual":
                list_key = canonical_name(raw.get("list") or DEFAULT_LIST_FOR_CLASSIFIER.get(classifier, ""))
                if not list_key:
                    raise ConfigurationError(f"settings.rules.{code}: list classifiers need a 'list'")
            min_conf = raw.get("min_confidence")
            self.definitions[code] = RuleDefinition(
                code=code,
                classifier=classifier,
                list_key=list_key,
                span_policy=str(raw.get("span_policy", "CONTAINS")).upper(),
                min_confidence=float(min_conf) if min_conf is not None else None,
                description=str(raw.get("description", "")),
                origin="settings",
            )
        if settings.auto_register_list_rules:
            for key in sorted(set(list_keys)):
                code = f"EXCL_{key}"
                if code not in self.definitions:
                    self.definitions[code] = RuleDefinition(
                        code, "intelligence_list", key, "CONTAINS", None,
                        f"Auto-registered: exclude when an active '{key}' intelligence value contains the match",
                        "auto")

    def get(self, code: str) -> Optional[RuleDefinition]:
        return self.definitions.get(code.strip().upper())

    def known_codes(self):
        return set(self.definitions)

    def list_keys_in_use(self):
        return {d.list_key for d in self.definitions.values() if d.list_key}

"""MonitoringEngine: one-time set-up, then a single streaming pass over the file.

One-time (per engine / per file)                 Per chunk
-----------------------------------------------  -------------------------------
load + validate mapping (P1, P2, Intel lists)    read N rows (only needed columns)
normalise keywords, build keyword registry       MESSAGE_KEY checks
load intelligence lists, build their automata    country resolution + P1 filter
load schema profiles                             candidate generation + verification
read header, detect encoding                     context classification + rules
key-only pre-pass (duplicates, countries)        write outputs, release memory
resolve columns, build search plan, compile
matchers
"""
from __future__ import annotations

import gc
import logging
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from . import ENGINE_NAME, __version__
from .context.context_engine import ContextEngine
from .exceptions import (ConfigurationError, DataQualityError, InputFileError, MonitoringError,
                         SchemaMappingError)
from .ingestion.mapping_reader import MappingReader
from .ingestion.transaction_reader import TransactionReader
from .matching.candidate_generator import ahocorasick_available
from .matching.keyword_registry import KeywordRegistry
from .models import Severity, ValidationIssue
from .normalization.text_normalizer import TextNormalizer
from .output.alert_writer import AlertWriter, TransactionRollupWriter
from .output.audit_writer import AuditWriter, ErrorWriter, LedgerWriter
from .output.columns import CONFIG_COLUMNS, DATA_QUALITY_COLUMNS, SCHEMA_COLUMNS
from .output.csv_writer import write_report
from .output.exclusion_writer import ExclusionWriter
from .output.summary_writer import SummaryWriter
from .pipeline.chunk_processor import ChunkProcessor
from .pipeline.decision_maker import DecisionMaker
from .pipeline.search_plan import SearchPlan, SearchPlanBuilder
from .rules.exclusion_engine import ExclusionEngine
from .rules.rule_engine import RuleEngine
from .scenarios.scenario_engine import ScenarioEngine
from .schema.column_resolver import ColumnResolver
from .schema.country_resolver import CountryResolver
from .schema.schema_registry import load_schema_registry
from .scoring.scoring_engine import ScoringEngine
from .settings import Settings
from .utils import canonical_name, current_rss_mb, peak_rss_mb, sha256_file, utc_now_iso
from .validation.data_quality import DataQualityMonitor
from .validation.mapping_validator import MappingValidator
from .validation.schema_validator import SchemaValidator

log = logging.getLogger("tm")

STATUS_COMPLETED = "COMPLETED"
STATUS_WARNINGS = "COMPLETED_WITH_WARNINGS"
STATUS_ERRORS = "COMPLETED_WITH_ERRORS"
STATUS_VALIDATED = "VALIDATED"
STATUS_FAILED_POLICY = "FAILED_POLICY"
STATUS_FAILED = "FAILED"
EXIT_CODES = {STATUS_COMPLETED: 0, STATUS_WARNINGS: 0, STATUS_VALIDATED: 0, STATUS_ERRORS: 2,
              STATUS_FAILED_POLICY: 3, STATUS_FAILED: 1}


@dataclass
class RunResult:
    status: str
    output_dir: Path
    summary: Dict[str, Any] = field(default_factory=dict)
    error: Optional[str] = None

    @property
    def exit_code(self) -> int:
        return EXIT_CODES.get(self.status, 1)

    def path(self, name: str) -> Path:
        return self.output_dir / name


class MonitoringEngine:
    """Load and validate configuration once; `run()` can then be called for many files."""

    def __init__(self, mapping_path: Path, schema_path: Path, settings: Optional[Settings] = None,
                 settings_path: Optional[Path] = None):
        t0 = time.perf_counter()
        self.settings = settings or Settings.load(settings_path)
        self.normalizer = TextNormalizer()
        raw = MappingReader(Path(mapping_path)).read()
        self.config = MappingValidator(self.settings, self.normalizer).validate(raw)
        self.schema_registry, self.schema_issues = load_schema_registry(Path(schema_path))
        self.keywords = KeywordRegistry(self.settings.matching)
        self.scenarios = ScenarioEngine(self.config, self.keywords)
        self.context = ContextEngine.build(
            self.config.registry, self.scenarios.used_rule_codes(), self.config.intelligence,
            self.config.intelligence_display, self.settings, self.normalizer, self.config.version)
        self.rule_engine = RuleEngine(self.config.registry, self.context)
        self.exclusions = ExclusionEngine()
        self.scoring = ScoringEngine(self.settings.scoring)
        self.resolver = ColumnResolver(self.schema_registry, self.settings.schema)
        self.setup_seconds = time.perf_counter() - t0
        log.info("Configuration loaded in %.2fs: %d active P2 rules, %d keyword specs, %d intelligence values",
                 self.setup_seconds, len(self.scenarios.rules), len(self.keywords.specs),
                 sum(len(v) for v in self.config.intelligence.values()))

    # ------------------------------------------------------------------ #
    def config_issues(self) -> List[ValidationIssue]:
        return list(self.settings.issues) + list(self.config.issues) + list(self.keywords.issues)

    def build_plan(self, countries: List[str], header: List[str]) -> SearchPlan:
        return SearchPlanBuilder(self.scenarios, self.resolver, self.normalizer, self.settings.matching).build(
            countries, header)

    # ------------------------------------------------------------------ #
    def run(self, input_path: Path, output_dir: Path, country: Optional[str] = None,
            chunk_size: Optional[int] = None, validate_only: bool = False) -> RunResult:
        input_path = Path(input_path)
        settings = self.settings
        if chunk_size:
            settings.input.chunk_size = int(chunk_size)
        started_wall = datetime.now(timezone.utc)
        run_id = started_wall.strftime("%Y%m%dT%H%M%SZ") + "-" + uuid.uuid4().hex[:8]
        out_dir = Path(output_dir)
        if settings.output.run_subdirectory:
            out_dir = out_dir / f"run_{started_wall.strftime('%Y%m%d_%H%M%S')}_{input_path.stem}_{run_id[-8:]}"
        out_dir.mkdir(parents=True, exist_ok=True)
        summary_writer = SummaryWriter(out_dir)
        summary_writer.mark("_RUNNING", run_id)
        timings: Dict[str, float] = {"configuration_load": round(self.setup_seconds, 3)}
        t_run = time.perf_counter()
        summary: Dict[str, Any] = {
            "run_id": run_id, "engine": f"{ENGINE_NAME} {__version__}", "started_at": utc_now_iso(),
            "input": {"path": str(input_path)}, "output_dir": str(out_dir),
        }
        writers: Dict[str, Any] = {}
        dq: Optional[DataQualityMonitor] = None
        processor: Optional[ChunkProcessor] = None
        schema_records: List[Dict] = []
        status = STATUS_FAILED
        error_text: Optional[str] = None
        peak_sampled = current_rss_mb()
        try:
            # ---------------- input, key column, country strategy --------------
            reader = TransactionReader(input_path, settings.input)
            header = reader.header
            key_column = self._key_column(header)
            countries = CountryResolver(settings.country_resolution, header, input_path, country)
            countries.ensure_resolvable()
            dq = DataQualityMonitor(settings, key_column)
            dq.add_summary("MESSAGE_KEY_COLUMN_PRESENT", "PASS", Severity.INFO, None,
                           f"identifier column '{key_column}'", column=key_column)

            # ---------------- pre-pass (encoding verified over the whole file) ---
            t = time.perf_counter()
            prepass = self._prepass(reader, dq, key_column, countries.country_column)
            timings["prepass"] = round(time.perf_counter() - t, 3)
            dq.add_summary("FILE_ENCODING", "PASS", Severity.INFO, None, f"decoded as {reader.encoding}")
            dq.add_summary("ROW_COUNT", "PASS" if prepass.total_rows else "WARN",
                           Severity.INFO if prepass.total_rows else Severity.WARNING, prepass.total_rows,
                           f"{prepass.total_rows} data rows; {prepass.distinct_keys} distinct MESSAGE_KEY values")
            if reader.info.duplicate_header_names:
                dq.add_summary("DUPLICATE_HEADER_NAMES", "WARN", Severity.WARNING,
                               len(reader.info.duplicate_header_names),
                               "duplicate header names: " + ", ".join(reader.info.duplicate_header_names))
            summary["input"].update({
                "sha256": sha256_file(input_path), "size_bytes": reader.info.size_bytes,
                "encoding": reader.encoding, "delimiter": settings.input.delimiter, "rows": prepass.total_rows,
                "reader_backend": reader.backend,
                "message_key_column": key_column, "columns_in_file": len(header)})
            self._enforce_key_policies(prepass, dq, reader, key_column)

            # ---------------- search plan ----------------------------------------
            t = time.perf_counter()
            plan_countries = countries.countries_to_plan(prepass.country_value_counts)
            plan = self.build_plan(plan_countries, header)
            timings["search_plan"] = round(time.perf_counter() - t, 3)
            schema_records = SchemaValidator(self.schema_registry).report_records(
                plan, header, key_column, countries.country_column or "", reader.info.duplicate_header_names,
                self.schema_issues)
            summary_writer.write_text("search_plan.txt", plan.describe())
            schema_errors = SchemaValidator.error_count(schema_records)
            dq.add_summary("REQUIRED_SCHEMA_COLUMNS", "PASS" if not schema_errors else "FAIL",
                           Severity.INFO if not schema_errors else Severity.ERROR, schema_errors,
                           "logical fields needed by ACTIVE rules that could not be resolved "
                           "(details in schema_validation_report.csv)")
            if schema_errors and settings.schema.schema_error_policy == "FAIL_FILE":
                raise SchemaMappingError(f"{schema_errors} schema mapping error(s) and schema_error_policy=FAIL_FILE")
            summary["search_plan"] = self._plan_summary(plan)
            summary["country_resolution"] = countries.describe()

            if validate_only:
                status = STATUS_VALIDATED
                return self._finish(status, summary, summary_writer, out_dir, writers, dq, schema_records,
                                    processor, timings, t_run, peak_sampled, None)

            # ---------------- streaming pass -------------------------------------
            writers = self._open_writers(out_dir)
            versions = {"MAPPING_VERSION": self.config.version, "SCHEMA_VERSION": self.schema_registry.version,
                        "SETTINGS_VERSION": f"sha256:{settings.sha256[:12]}" if settings.sha256 != "builtin"
                        else "builtin-defaults", "ENGINE_VERSION": __version__}
            decisions = DecisionMaker(self.rule_engine, self.exclusions, self.scoring, self.keywords, versions,
                                      settings.matching.value_cache_size)
            processor = ChunkProcessor(plan, countries, dq, decisions, writers, key_column,
                                       settings.data_quality.duplicate_message_key_policy, run_id,
                                       settings.output.write_transaction_rollup,
                                       settings.output.write_screening_ledger)
            usecols = [key_column]
            if countries.country_column and countries.country_column not in usecols:
                usecols.append(countries.country_column)
            usecols += [c for c in plan.required_columns() if c not in usecols]
            log.info("Screening %s: %d rows, %d columns searched, chunk size %d, backend %s", input_path.name,
                     prepass.total_rows, len(plan.matchers), settings.input.chunk_size, self._backend(plan))
            t = time.perf_counter()
            read_seconds = 0.0
            row_offset = 0
            iterator = reader.iter_chunks(usecols=usecols)
            chunk_no = 0
            while True:
                t_read = time.perf_counter()
                try:
                    chunk, malformed = next(iterator)
                except StopIteration:
                    break
                read_seconds += time.perf_counter() - t_read
                processor.process(chunk, row_offset, malformed)
                row_offset += len(chunk)
                chunk_no += 1
                del chunk
                if settings.output.gc_every_n_chunks and chunk_no % settings.output.gc_every_n_chunks == 0:
                    gc.collect()
                rss = current_rss_mb()
                peak_sampled = max(peak_sampled, rss)
                elapsed = time.perf_counter() - t
                c = processor.counters
                log.info("chunk %d: %s rows | %.0f rows/s | alerts %d | exclusions %d | errors %d | RSS %.0f MB",
                         chunk_no, f"{row_offset:,}", row_offset / elapsed if elapsed else 0.0, c.alerts,
                         c.exclusions, c.errors, rss)
            timings["streaming_pass"] = round(time.perf_counter() - t, 3)
            timings["streaming_read_csv"] = round(read_seconds, 3)
            timings["streaming_process"] = round(timings["streaming_pass"] - read_seconds, 3)
            summary["input"]["chunks"] = chunk_no
            summary["input"]["chunk_size"] = settings.input.chunk_size
            self._file_level_errors(plan, processor, decisions, writers, run_id)
            status = STATUS_COMPLETED
        except (DataQualityError, SchemaMappingError) as exc:
            status, error_text = STATUS_FAILED_POLICY, str(exc)
            log.error("Policy stopped the file: %s", exc)
        except (ConfigurationError, InputFileError, MonitoringError) as exc:
            status, error_text = STATUS_FAILED, str(exc)
            log.error("Run failed: %s", exc)
        except Exception as exc:  # unexpected: keep evidence, report, re-raise after cleanup
            status, error_text = STATUS_FAILED, f"{type(exc).__name__}: {exc}"
            log.exception("Unexpected failure")
        return self._finish(status, summary, summary_writer, out_dir, writers, dq, schema_records, processor,
                            timings, t_run, peak_sampled, error_text)

    # ------------------------------------------------------------------ #
    def _key_column(self, header: List[str]) -> str:
        wanted = self.settings.input.message_key_column
        if wanted in header:
            return wanted
        matches = [h for h in header if canonical_name(h) == canonical_name(wanted)]
        if len(matches) == 1:
            return matches[0]
        raise InputFileError(f"Required identifier column '{wanted}' not found in the file header "
                             f"({len(header)} columns: {', '.join(header[:15])}{'...' if len(header) > 15 else ''})")

    def _prepass(self, reader: TransactionReader, dq: DataQualityMonitor, key_column: str,
                 country_column: Optional[str]):
        tried: List[str] = []
        while True:
            try:
                return dq.prepass(reader, key_column, country_column)
            except UnicodeDecodeError as exc:
                tried.append(reader.encoding)
                options = [e for e in self.settings.input.encoding_fallbacks + ["latin-1"] if e not in tried]
                if not options:
                    raise InputFileError(f"File cannot be decoded with {tried}: {exc}") from exc
                dq.add_summary("ENCODING_FALLBACK", "WARN", Severity.WARNING, None,
                               f"{reader.encoding} failed at byte {exc.start}; retried with {options[0]}")
                log.warning("Encoding %s failed (%s); retrying with %s", reader.encoding, exc.reason, options[0])
                reader.set_encoding(options[0])

    def _enforce_key_policies(self, prepass, dq: DataQualityMonitor, reader: TransactionReader,
                              key_column: str) -> None:
        dq_settings = self.settings.data_quality
        fail_dup = prepass.has_duplicates and dq_settings.duplicate_message_key_policy == "FAIL_FILE"
        fail_null = prepass.null_keys > 0 and dq_settings.null_message_key_policy == "FAIL_FILE"
        if not (fail_dup or fail_null):
            return
        import numpy as np

        offset = 0
        for chunk, _ in reader.iter_chunks(usecols=[key_column], chunk_size=self.settings.input.prepass_chunk_size):
            keys = chunk[key_column].astype(str).str.strip()
            dq.check_keys(keys, np.arange(offset + 1, offset + len(chunk) + 1, dtype=np.int64))
            offset += len(chunk)
        if fail_dup and dq.true_duplicate_keys():
            raise DataQualityError(f"{len(dq.true_duplicate_keys())} duplicated MESSAGE_KEY value(s) and "
                                   f"duplicate_message_key_policy=FAIL_FILE")
        if fail_null:
            raise DataQualityError(f"{prepass.null_keys} blank MESSAGE_KEY value(s) and "
                                   f"null_message_key_policy=FAIL_FILE")

    def _open_writers(self, out_dir: Path) -> Dict[str, Any]:
        writers: Dict[str, Any] = {
            "alerts": AlertWriter(out_dir / "alerts.csv"),
            "exclusions": ExclusionWriter(out_dir / "excluded_matches.csv"),
            "audit": AuditWriter(out_dir / "monitoring_audit.csv"),
            "errors": ErrorWriter(out_dir / "errors.csv"),
        }
        if self.settings.output.write_transaction_rollup:
            writers["rollup"] = TransactionRollupWriter(out_dir / "alerted_transactions.csv")
        if self.settings.output.write_screening_ledger:
            writers["ledger"] = LedgerWriter(out_dir / "screened_transactions.csv")
        return writers

    def _file_level_errors(self, plan: SearchPlan, processor: ChunkProcessor, decisions: DecisionMaker,
                           writers: Dict[str, Any], run_id: str) -> None:
        stamp = utc_now_iso()
        rows = []
        for res in plan.resolution_results():
            if res.ok or res.country not in plan.screenable_countries():
                continue
            rules = plan.rules_by_resolution().get((res.country, res.logical_field), [])
            rows.append({"ERROR_CODE": res.status, "SEVERITY": Severity.ERROR, "COUNTRY": res.country,
                         "COLUMN": res.logical_field, "RUN_ID": run_id, "PROCESSING_TIMESTAMP": stamp,
                         "DETAIL": f"{res.detail}; rules {','.join(sorted({r.rule_id for r in rules}))} did not "
                                   f"search this logical field for {res.country} rows (file-level error)"})
        for (rule_id, code, status), detail in sorted(decisions.rule_problems.items()):
            rows.append({"ERROR_CODE": f"RULE_{status}", "SEVERITY": Severity.ERROR, "COLUMN": code,
                         "RUN_ID": run_id, "PROCESSING_TIMESTAMP": stamp,
                         "DETAIL": f"P2 rule {rule_id}: {detail}"})
        if rows:
            writers["errors"].write_records(rows)
            processor.counters.errors += len(rows)

    def _backend(self, plan: SearchPlan) -> str:
        names = {m.backend_name for m in plan.matchers.values()}
        return ",".join(sorted(names)) or ("aho_corasick" if ahocorasick_available() else "pure_python")

    def _plan_summary(self, plan: SearchPlan) -> Dict[str, Any]:
        return {
            "countries": {c: {"eligible_rt_types": p.eligible_rt_types, "rules": len(p.rules),
                              "searched_columns": sorted(p.by_column)} for c, p in plan.countries.items()},
            "searched_columns": plan.required_columns(),
            "distinct_matchers": len({id(m) for m in plan.matchers.values()}),
        }

    # ------------------------------------------------------------------ #
    def _finish(self, status, summary, summary_writer, out_dir, writers, dq, schema_records, processor,
                timings, t_run, peak_sampled, error_text) -> RunResult:
        ok = status not in (STATUS_FAILED, STATUS_FAILED_POLICY)
        t = time.perf_counter()
        outputs: Dict[str, Any] = {}
        for name, writer in writers.items():
            path = writer.close(success=ok)
            outputs[path.name] = writer.rows_written
        config_issues = self.config_issues()
        outputs["config_validation_report.csv"] = write_report(
            out_dir / "config_validation_report.csv", [i.to_dict() for i in config_issues], CONFIG_COLUMNS)
        if schema_records:
            outputs["schema_validation_report.csv"] = write_report(
                out_dir / "schema_validation_report.csv", schema_records, SCHEMA_COLUMNS)
        if dq is not None:
            if processor is not None:
                countries = processor.countries
                unresolved = processor.counters.rows_country_unresolved
                dq.add_summary("COUNTRY_RESOLVED", "PASS" if not unresolved else "FAIL",
                               Severity.INFO if not unresolved else Severity.ERROR, unresolved,
                               f"rows resolved by strategy: {dict(countries.method_counts)}; "
                               f"invalid column values: {dict(countries.invalid_values.most_common(10))}")
                if countries.conflicts:
                    dq.add_summary("COUNTRY_CONFLICT", "WARN", Severity.WARNING, sum(countries.conflicts.values()),
                                   f"file-level country overrides the data's own country column: "
                                   f"{dict(countries.conflicts.most_common(10))}")
                for value, count in countries.invalid_values.most_common(50):
                    dq.add_detail("INVALID_COUNTRY_VALUE", Severity.WARNING,
                                  "value is not an ISO 3166-1 alpha-2 code or configured alias",
                                  column=countries.country_column or "", value=str(value), count=count)
            levels = [i.severity for i in config_issues]
            worst = max((Severity.ORDER[s] for s in levels), default=0)
            dq.add_summary("CONFIGURATION_P1_P2_INTELLIGENCE", ["PASS", "PASS", "WARN", "FAIL"][worst],
                           [Severity.INFO, Severity.INFO, Severity.WARNING, Severity.ERROR][worst], len(levels),
                           "configuration issues (details in config_validation_report.csv)")
            dup_policy = self.settings.data_quality.duplicate_message_key_policy
            outputs["data_quality_report.csv"] = write_report(
                out_dir / "data_quality_report.csv", dq.report_records(dup_policy,
                                                                        self.settings.data_quality.null_message_key_policy),
                DATA_QUALITY_COLUMNS)
        counters = processor.counters.as_dict() if processor is not None else {}
        if processor is not None:
            summary["country_resolution"] = processor.countries.describe()
        if processor is not None and status == STATUS_COMPLETED:
            has_errors = counters.get("errors", 0) > 0 or any(
                i.severity in (Severity.ERROR, Severity.CRITICAL) for i in config_issues) or \
                SchemaValidator.error_count(schema_records) > 0
            has_warnings = any(i.severity == Severity.WARNING for i in config_issues) or \
                (dq is not None and bool(dq.true_duplicate_keys()))
            status = STATUS_ERRORS if has_errors else (STATUS_WARNINGS if has_warnings else STATUS_COMPLETED)
        elapsed = time.perf_counter() - t_run
        timings["reports"] = round(time.perf_counter() - t, 3)
        timings["total_run"] = round(elapsed, 3)
        rows = counters.get("rows_read", 0)
        matcher_stats: Dict[str, int] = {}
        if processor is not None:
            seen = set()
            for matcher in processor.plan.matchers.values():
                if id(matcher) in seen:
                    continue
                seen.add(id(matcher))
                for k, v in matcher.stats().items():
                    matcher_stats[k] = matcher_stats.get(k, 0) + v
        summary.update({
            "status": status,
            "exit_code": EXIT_CODES[status],
            "error": error_text,
            "finished_at": utc_now_iso(),
            "versions": {"mapping_version": self.config.version, "mapping_sha256": self.config.sha256,
                         "schema_version": self.schema_registry.version, "schema_sha256": self.schema_registry.sha256,
                         "settings_source": self.settings.source, "settings_sha256": self.settings.sha256,
                         "engine_version": __version__},
            "configuration": {
                **self.config.stats,
                "rt_types": sorted(self.config.rt_display.values()),
                "keyword_specs": len(self.keywords.specs),
                "keyword_specs_by_match_type": self.keywords.counts_by_match_type(),
                "distinct_keywords": len({s.keyword for s in self.keywords.specs.values()}),
                "intelligence_values_by_list": {self.config.intelligence_display.get(k, k): len(v)
                                                for k, v in self.config.intelligence.items()},
                "config_issues_by_severity": {s: sum(1 for i in config_issues if i.severity == s)
                                              for s in (Severity.CRITICAL, Severity.ERROR, Severity.WARNING,
                                                        Severity.INFO)},
            },
            "processing": {**{k: v for k, v in counters.items() if not k.startswith("by_")},
                           "stage2_candidates": matcher_stats.get("stage2_candidates", 0),
                           "verified_hits": matcher_stats.get("verified_hits", 0),
                           "distinct_values_matched": matcher_stats.get("values_scanned", 0),
                           "context_evaluations": self.context.evaluations,
                           "context_cache_hits": self.context.cache_hits},
            "breakdown": {k: v for k, v in counters.items() if k.startswith("by_")},
            "performance": {
                "rows_per_second": round(rows / timings["streaming_pass"], 1)
                if timings.get("streaming_pass") else None,
                "end_to_end_rows_per_second": round(rows / elapsed, 1) if elapsed and rows else None,
                "peak_memory_mb": round(max(peak_rss_mb(), peak_sampled), 1),
                "peak_memory_sampled_mb": round(peak_sampled, 1),
                "candidate_backend": self._backend(processor.plan) if processor else None,
                "chunk_size": self.settings.input.chunk_size,
                "stage_seconds": timings,
            },
            "outputs": outputs,
        })
        summary_writer.write(summary)
        summary_writer.mark("_SUCCESS" if ok else "_FAILED", error_text or status)
        return RunResult(status, out_dir, summary, error_text)

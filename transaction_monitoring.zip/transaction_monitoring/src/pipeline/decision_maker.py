"""DecisionMaker: rules + exclusions + scoring + explanation for one occurrence.

Everything except the row-specific fields (MESSAGE_KEY, ROW_NUMBER, original
value, timestamp, decision id) depends only on (rule, column, country,
normalised value, hit), so the finished explanation is cached and reused for
every transaction carrying the same counterparty value.
"""
from __future__ import annotations

import json
from typing import Dict, List

from ..matching.keyword_registry import KeywordRegistry
from ..models import Decision, Hit, MatchContext, RuleStatus
from ..rules.exclusion_engine import ExclusionEngine
from ..rules.rule_engine import RuleEngine, RuleOutcome
from ..scoring.scoring_engine import ScoringEngine
from ..utils import BoundedCache
from .search_plan import RuleBinding


class DecisionMaker:
    def __init__(self, rule_engine: RuleEngine, exclusion_engine: ExclusionEngine, scoring: ScoringEngine,
                 keywords: KeywordRegistry, versions: Dict[str, str], cache_size: int = 250_000):
        self.rules = rule_engine
        self.exclusions = exclusion_engine
        self.scoring = scoring
        self.keywords = keywords
        self.versions = versions
        self._cache: BoundedCache = BoundedCache(cache_size)
        self.rule_problems: Dict[tuple, str] = {}   # (rule_id, rule code, status) -> detail

    def decide(self, binding: RuleBinding, hit: Hit, country: str, normalized_value: str,
               original_value: str) -> Dict:
        key = (binding.rule.rule_id, binding.physical_column, country, normalized_value, hit)
        cached = self._cache.get(key)
        if cached is not None:
            return cached
        rule = binding.rule
        spec = self.keywords.specs[hit.spec_id]
        logical = binding.logical_field.split("|")[0]
        ctx = MatchContext(country, rule.rt_type, spec.keyword, logical, binding.physical_column, original_value,
                           normalized_value, hit.start, hit.end)
        outcomes = self.rules.evaluate(rule.exclusion_rules, ctx)
        outcome = self.exclusions.decide(outcomes)
        confidence = self.scoring.confidence(outcome.decision, hit.score, spec.match_type, logical, outcome.primary)
        individual = next((o for o in outcomes if o.result is not None
                           and o.result.classifier == "IndividualClassifier"), None)
        primary = outcome.primary
        evidence = primary.result.evidence if primary is not None and primary.result is not None else {}
        template = {
            "COUNTRY": country,
            "RT_TYPE": rule.rt_type,
            "P2_RULE_ID": rule.rule_id,
            "KEYWORD": rule.keyword,
            "NORMALIZED_KEYWORD": spec.keyword,
            "LOGICAL_FIELD": binding.logical_field,
            "PHYSICAL_COLUMN": binding.physical_column,
            "NORMALIZED_VALUE": normalized_value,
            "MATCHED_TEXT": normalized_value[hit.start:hit.end],
            "MATCH_START": hit.start,
            "MATCH_END": hit.end,
            "MATCH_TYPE": spec.match_type,
            "MATCH_VARIANT": hit.variant,
            "MATCH_SCORE": round(float(hit.score), 2),
            "CONFIDENCE_SCORE": confidence,
            "RULES": ",".join(rule.exclusion_rules),
            "RULES_EVALUATED": ";".join(o.short() for o in outcomes) if outcomes else "NONE",
            "INDIVIDUAL_CLASSIFICATION": individual.result.classification if individual else "",
            "INDIVIDUAL_CONFIDENCE": individual.result.confidence if individual else "",
            "EXCLUSION_RULE": "|".join(o.rule_code for o in outcome.triggered),
            "INTELLIGENCE_LIST": evidence.get("intelligence_list", ""),
            "INTELLIGENCE_VALUE": evidence.get("intelligence_value", ""),
            "FINAL_DECISION": outcome.decision,
            "REASON": self._reason(binding, spec.match_type, hit, country, normalized_value, outcomes, outcome),
            "CLASSIFICATION_DETAILS": json.dumps(
                [{"rule": o.rule_code, "status": o.status, **(o.result.to_dict() if o.result else {}),
                  **({"detail": o.detail} if o.result is None else {})} for o in outcomes],
                separators=(",", ":"), ensure_ascii=False) if outcomes else "",
            **self.versions,
        }
        for o in outcomes:
            if o.status in (RuleStatus.ERROR, RuleStatus.UNKNOWN_RULE):
                problem = (rule.rule_id, o.rule_code, o.status)
                if problem not in self.rule_problems:
                    self.rule_problems[problem] = o.detail
        self._cache.put(key, template)
        return template

    @staticmethod
    def _reason(binding: RuleBinding, match_type: str, hit: Hit, country: str, value: str,
                outcomes: List[RuleOutcome], outcome) -> str:
        rule = binding.rule
        matched = value[hit.start:hit.end]
        variant = " (compact variant, spaces removed)" if hit.variant == "COMPACT" else ""
        parts = [
            f"Keyword '{rule.keyword}' matched as {match_type}{variant} in {binding.physical_column} "
            f"(logical field {binding.logical_field}): '{matched}' at [{hit.start}:{hit.end}], "
            f"score {hit.score:.0f}.",
            f"Country {country} is eligible for {rule.rt_type} (P1); P2 rule {rule.rule_id}.",
        ]
        if not outcomes:
            parts.append("No exclusion rules configured on this P2 row.")
        for o in outcomes:
            label = {"TRIGGERED": "applied", "NOT_TRIGGERED": "did not apply"}.get(o.status, o.status)
            parts.append(f"{o.rule_code} {label}: {o.detail}.")
        if outcome.decision == Decision.EXCLUDED:
            parts.append(f"Final decision EXCLUDED by {outcome.primary.rule_code}.")
        else:
            parts.append("No exclusion applied; final decision ALERT.")
        return " ".join(parts)

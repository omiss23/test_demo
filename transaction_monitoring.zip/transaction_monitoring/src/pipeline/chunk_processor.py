"""ChunkProcessor: the per-chunk pipeline.

    chunk (100K rows)
      -> MESSAGE_KEY checks (null / duplicate policy)
      -> country resolution (vectorised)            -> COUNTRY_UNRESOLVED errors
      -> P1 eligibility filter (before any matching) -> NOT_ELIGIBLE rows skipped
      -> per searched column: distinct values -> ColumnMatcher (stages 1-3)
      -> hits fanned out to P2 rule bindings -> context + rules -> decision
      -> write alerts / exclusions / audit / errors / roll-up for this chunk
      -> release the chunk (nothing transaction-level is kept between chunks)
"""
from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass, field
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

from ..ingestion.transaction_reader import MalformedRecord
from ..models import Decision, Severity
from ..schema.country_resolver import CountryResolver
from ..utils import short_id, utc_now_iso
from ..validation.data_quality import DataQualityMonitor
from .decision_maker import DecisionMaker
from .search_plan import SearchPlan


@dataclass
class RunCounters:
    rows_read: int = 0
    rows_screened: int = 0
    rows_not_eligible: int = 0
    rows_null_key: int = 0
    rows_duplicate_key: int = 0
    rows_rejected_duplicate: int = 0
    rows_country_unresolved: int = 0
    rows_not_screened_schema: int = 0
    malformed_records: int = 0
    rows_with_hits: int = 0
    decisions: int = 0
    alerts: int = 0
    exclusions: int = 0
    alerted_transactions: int = 0
    errors: int = 0
    by_rt_type: Counter = field(default_factory=Counter)
    by_rule: Counter = field(default_factory=Counter)
    by_country: Counter = field(default_factory=Counter)
    by_exclusion_rule: Counter = field(default_factory=Counter)
    by_column: Counter = field(default_factory=Counter)

    def as_dict(self) -> Dict:
        out = {k: v for k, v in self.__dict__.items() if not isinstance(v, Counter)}
        for name in ("by_rt_type", "by_rule", "by_country", "by_exclusion_rule", "by_column"):
            counter: Counter = getattr(self, name)
            nested: Dict[str, Dict[str, int]] = defaultdict(dict)
            for (group, decision), count in sorted(counter.items()):
                nested[group][decision] = count
            out[name] = dict(nested)
        return out


def _line(record: MalformedRecord) -> str:
    return f"parser line {record.parser_line}" if record.parser_line >= 0 else "parser line n/a (multi-threaded parser)"


class ChunkProcessor:
    def __init__(self, plan: SearchPlan, countries: CountryResolver, dq: DataQualityMonitor,
                 decisions: DecisionMaker, writers: Dict, key_column: str, duplicate_policy: str,
                 run_id: str, write_rollup: bool, write_ledger: bool):
        self.plan = plan
        self.countries = countries
        self.dq = dq
        self.decisions = decisions
        self.writers = writers
        self.key_column = key_column
        self.reject_duplicates = duplicate_policy == "REJECT_DUPLICATES"
        self.run_id = run_id
        self.write_rollup = write_rollup
        self.write_ledger = write_ledger
        self.counters = RunCounters()
        self.screenable = sorted(plan.screenable_countries())
        self.with_rules = sorted(c for c, p in plan.countries.items() if p.rules)
        self.unscreenable = sorted(set(self.with_rules) - set(self.screenable))

    # ------------------------------------------------------------------ #
    def process(self, chunk: pd.DataFrame, row_offset: int, malformed: List[MalformedRecord]) -> int:
        stamp = utc_now_iso()
        c = self.counters
        if malformed:
            self._malformed(malformed, stamp)
        n = len(chunk)
        if n == 0:
            return 0
        c.rows_read += n
        row_numbers = np.arange(row_offset + 1, row_offset + n + 1, dtype=np.int64)

        keys = chunk[self.key_column].astype(str).str.strip()
        null_mask, dup_mask = self.dq.check_keys(keys, row_numbers)
        c.rows_null_key += int(null_mask.sum())
        c.rows_duplicate_key += int(dup_mask.sum())
        reject = null_mask.copy()
        if self.reject_duplicates:
            reject |= dup_mask
            c.rows_rejected_duplicate += int(dup_mask.sum())

        country = self.countries.resolve_chunk(chunk)
        country_series = pd.Series(country, dtype=object, copy=False)
        unresolved = (country == "") & ~reject
        has_rules = country_series.isin(self.with_rules).to_numpy()
        screenable = country_series.isin(self.screenable).to_numpy() if self.screenable else np.zeros(n, bool)
        eligible = screenable & ~reject & ~unresolved
        schema_blocked = has_rules & ~screenable & ~reject & ~unresolved
        not_eligible = ~has_rules & ~reject & ~unresolved
        c.rows_screened += int(eligible.sum())
        c.rows_not_eligible += int(not_eligible.sum())
        c.rows_country_unresolved += int(unresolved.sum())
        c.rows_not_screened_schema += int(schema_blocked.sum())

        self._row_errors(keys, row_numbers, country, null_mask, dup_mask if self.reject_duplicates else None,
                         unresolved, schema_blocked, chunk, stamp)

        records: List[Dict] = []
        keys_array: Optional[np.ndarray] = None
        single_country = len(self.screenable) == 1
        for column, matcher in self.plan.matchers.items():
            col_countries = self.plan.column_countries[column]
            if single_country:
                mask = eligible if self.screenable[0] in col_countries else np.zeros(n, bool)
            else:
                mask = eligible & country_series.isin(col_countries).to_numpy()
            if not mask.any():
                continue
            if mask.all():
                positions = None
                values = chunk[column]
            else:
                positions = np.flatnonzero(mask)
                values = chunk[column].iloc[positions]
            codes, uniques = pd.factorize(values)
            unique_values = uniques.tolist()
            results = matcher.match_values(unique_values)
            empty = int(np.isin(codes, matcher.last_empty).sum()) if matcher.last_empty else 0
            self.dq.record_column_counts(column, len(codes), empty)
            if not results:
                continue
            if keys_array is None:
                keys_array = keys.to_numpy(dtype=object)
            hit_codes = np.fromiter(results.keys(), dtype=np.int64, count=len(results))
            selected = np.flatnonzero(np.isin(codes, hit_codes))
            for j in selected.tolist():
                p = j if positions is None else int(positions[j])
                code = int(codes[j])
                normalized, hits = results[code]
                row_country = country[p]
                bindings_by_spec = self.plan.countries[row_country].by_column.get(column)
                if not bindings_by_spec:
                    continue
                original = unique_values[code]
                message_key = keys_array[p]
                row_number = int(row_numbers[p])
                for hit in hits:
                    for binding in bindings_by_spec.get(hit.spec_id, ()):
                        template = self.decisions.decide(binding, hit, row_country, normalized, original)
                        record = dict(template)
                        record["MESSAGE_KEY"] = message_key
                        record["ROW_NUMBER"] = row_number
                        record["ORIGINAL_VALUE"] = original
                        record["PROCESSING_TIMESTAMP"] = stamp
                        record["RUN_ID"] = self.run_id
                        record["DECISION_ID"] = short_id(
                            f"{message_key}|{row_number}|{binding.rule.rule_id}|{column}|{hit.start}|{hit.end}|"
                            f"{hit.spec_id}")
                        records.append(record)
        self._write_decisions(records)
        if self.write_ledger:
            self._ledger(keys, row_numbers, country, null_mask, reject, unresolved, schema_blocked, not_eligible,
                         records)
        return n

    # ------------------------------------------------------------------ #
    def _write_decisions(self, records: List[Dict]) -> None:
        if not records:
            return
        c = self.counters
        alerts = [r for r in records if r["FINAL_DECISION"] == Decision.ALERT]
        exclusions = [r for r in records if r["FINAL_DECISION"] == Decision.EXCLUDED]
        self.writers["audit"].write_records(records)
        self.writers["alerts"].write_records(alerts)
        self.writers["exclusions"].write_records(exclusions)
        c.decisions += len(records)
        c.alerts += len(alerts)
        c.exclusions += len(exclusions)
        for r in records:
            decision = r["FINAL_DECISION"]
            c.by_rt_type[(r["RT_TYPE"], decision)] += 1
            c.by_rule[(r["P2_RULE_ID"], decision)] += 1
            c.by_country[(r["COUNTRY"], decision)] += 1
            c.by_column[(r["PHYSICAL_COLUMN"], decision)] += 1
            if r["EXCLUSION_RULE"]:
                for code in r["EXCLUSION_RULE"].split("|"):
                    c.by_exclusion_rule[(code, "TRIGGERED")] += 1
        rows = defaultdict(list)
        for r in records:
            rows[(r["MESSAGE_KEY"], r["ROW_NUMBER"])].append(r)
        c.rows_with_hits += len(rows)
        rollup = []
        for (key, row_number), items in rows.items():
            alerted = [r for r in items if r["FINAL_DECISION"] == Decision.ALERT]
            if not alerted:
                continue
            rollup.append({
                "MESSAGE_KEY": key, "ROW_NUMBER": row_number, "COUNTRY": items[0]["COUNTRY"],
                "ALERT_COUNT": len(alerted), "EXCLUSION_COUNT": len(items) - len(alerted),
                "RT_TYPES": "|".join(sorted({r["RT_TYPE"] for r in alerted})),
                "KEYWORDS": "|".join(sorted({r["KEYWORD"] for r in alerted})),
                "PHYSICAL_COLUMNS": "|".join(sorted({r["PHYSICAL_COLUMN"] for r in alerted})),
                "P2_RULE_IDS": "|".join(sorted({r["P2_RULE_ID"] for r in alerted})),
                "MAX_CONFIDENCE": max(float(r["CONFIDENCE_SCORE"]) for r in alerted),
                "RUN_ID": self.run_id,
            })
        c.alerted_transactions += len(rollup)
        if self.write_rollup and rollup:
            self.writers["rollup"].write_records(rollup)

    def _row_errors(self, keys, row_numbers, country, null_mask, rejected_dups, unresolved, schema_blocked,
                    chunk, stamp) -> None:
        frames = []

        def frame(mask, code, severity, detail, column="", key_values=None, country_values=None):
            count = int(mask.sum())
            frames.append(pd.DataFrame({
                "MESSAGE_KEY": key_values if key_values is not None else keys.to_numpy(dtype=object)[mask],
                "ROW_NUMBER": row_numbers[mask],
                "ERROR_CODE": code, "SEVERITY": severity,
                "COUNTRY": country_values if country_values is not None else country[mask],
                "COLUMN": column, "DETAIL": detail, "RUN_ID": self.run_id, "PROCESSING_TIMESTAMP": stamp,
            }, index=range(count)))

        if null_mask.any():
            frame(null_mask, "NULL_MESSAGE_KEY", Severity.ERROR,
                  "MESSAGE_KEY is blank; transaction cannot be identified and was not screened",
                  column=self.key_column, key_values="")
        if rejected_dups is not None and rejected_dups.any():
            frame(rejected_dups, "DUPLICATE_MESSAGE_KEY_REJECTED", Severity.ERROR,
                  "MESSAGE_KEY is not unique in this file; policy REJECT_DUPLICATES - not screened",
                  column=self.key_column)
        if unresolved.any():
            col = self.countries.country_column or ""
            if col and col in chunk.columns:
                raw = chunk[col].astype(str).to_numpy(dtype=object)[unresolved]
                detail = np.array([f"country value '{v}' is blank or not a valid ISO code and no fallback "
                                   f"strategy applied; not screened" for v in raw], dtype=object)
            else:
                detail = "country could not be resolved; not screened"
            frame(unresolved, "COUNTRY_UNRESOLVED", Severity.ERROR, detail, column=col, country_values="")
        if schema_blocked.any():
            frame(schema_blocked, "NOT_SCREENED_SCHEMA_ERROR", Severity.ERROR,
                  "country has eligible RT TYPEs but none of their logical fields map to a column in this file "
                  "(see schema_validation_report.csv); not screened")
        if frames:
            data = pd.concat(frames, ignore_index=True)
            self.writers["errors"].write_frame(data)
            self.counters.errors += len(data)

    def _malformed(self, malformed: List[MalformedRecord], stamp: str) -> None:
        self.dq.record_malformed(malformed)
        self.counters.malformed_records += len(malformed)
        rows = [{"MESSAGE_KEY": "", "ROW_NUMBER": "", "ERROR_CODE": "MALFORMED_RECORD", "SEVERITY": Severity.ERROR,
                 "COUNTRY": "", "COLUMN": "", "RUN_ID": self.run_id, "PROCESSING_TIMESTAMP": stamp,
                 "DETAIL": f"{_line(m)}: {m.detail}; record skipped and not screened"}
                for m in malformed]
        self.writers["errors"].write_records(rows)
        self.counters.errors += len(rows)

    def _ledger(self, keys, row_numbers, country, null_mask, reject, unresolved, schema_blocked, not_eligible,
                records) -> None:
        status = np.full(len(keys), "SCREENED_NO_HIT", dtype=object)
        status[not_eligible] = "NOT_ELIGIBLE"
        status[schema_blocked] = "NOT_SCREENED_SCHEMA_ERROR"
        status[unresolved] = "COUNTRY_UNRESOLVED"
        status[reject & ~null_mask] = "REJECTED_DUPLICATE"
        status[null_mask] = "REJECTED_NULL_KEY"
        alerts = np.zeros(len(keys), dtype=np.int64)
        excl = np.zeros(len(keys), dtype=np.int64)
        first_row = int(row_numbers[0])
        for r in records:
            i = int(r["ROW_NUMBER"]) - first_row
            if r["FINAL_DECISION"] == Decision.ALERT:
                alerts[i] += 1
            else:
                excl[i] += 1
        status[(alerts == 0) & (excl > 0)] = "ALL_HITS_EXCLUDED"
        status[alerts > 0] = "ALERTED"
        self.writers["ledger"].write_frame(pd.DataFrame({
            "MESSAGE_KEY": keys.to_numpy(dtype=object), "ROW_NUMBER": row_numbers, "COUNTRY": country,
            "SCREENING_STATUS": status, "ALERT_COUNT": alerts, "EXCLUSION_COUNT": excl, "RUN_ID": self.run_id}))

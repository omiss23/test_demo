"""Search plan: built once per file, before the first chunk is read.

For every country that can occur in the file:
    eligible RT TYPEs (P1) -> ACTIVE rules (P2) -> logical fields (Message)
    -> physical columns (ColumnResolver against the real header)

The result is an index  country -> physical column -> keyword spec -> [rule bindings]
plus one compiled ColumnMatcher per physical column (columns that need the same
keyword set share a matcher). Nothing about P2 or the schema is looked up per
row afterwards.

Example (text form written to search_plan.txt):
    IN
      Scenario 1
        ABC  [TOKEN]  rules=EXCL_INDV,EXCL_TOPONYM  (P2-R2)
          BENEFICIARY -> BENEFICIARY_NAME
          ADDRESS     -> BENEFICIARY_ADDRESS, ORIGINATOR_ADDRESS
"""
from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from typing import Dict, List, Sequence, Set, Tuple

from ..matching.keyword_registry import KeywordRegistry
from ..matching.matching_engine import ColumnMatcher
from ..models import ScenarioRule
from ..normalization.text_normalizer import TextNormalizer
from ..scenarios.scenario_engine import ScenarioEngine
from ..schema.column_resolver import ColumnResolver, ResolutionResult
from ..settings import MatchingSettings


@dataclass(frozen=True)
class RuleBinding:
    rule: ScenarioRule
    logical_field: str       # may be 'A|B' when two logical fields resolve to the same column
    physical_column: str


@dataclass
class CountrySearchPlan:
    country: str
    eligible_rt_types: List[str]
    rules: List[ScenarioRule]
    by_column: Dict[str, Dict[int, List[RuleBinding]]] = field(default_factory=dict)
    resolutions: List[Tuple[ScenarioRule, ResolutionResult]] = field(default_factory=list)

    @property
    def screenable(self) -> bool:
        return bool(self.by_column)

    def unresolved(self) -> List[Tuple[ScenarioRule, ResolutionResult]]:
        return [(rule, res) for rule, res in self.resolutions if not res.ok]


@dataclass
class SearchPlan:
    countries: Dict[str, CountrySearchPlan]
    matchers: Dict[str, ColumnMatcher]              # physical column -> matcher
    column_countries: Dict[str, Set[str]]           # physical column -> countries that search it
    keyword_registry: KeywordRegistry

    def required_columns(self) -> List[str]:
        return sorted(self.matchers)

    def screenable_countries(self) -> Set[str]:
        return {c for c, p in self.countries.items() if p.screenable}

    def resolution_results(self) -> List[ResolutionResult]:
        seen = {}
        for plan in self.countries.values():
            for _, res in plan.resolutions:
                seen[(res.country, res.logical_field)] = res
        return [seen[k] for k in sorted(seen)]

    def rules_by_resolution(self) -> Dict[Tuple[str, str], List[ScenarioRule]]:
        out: Dict[Tuple[str, str], List[ScenarioRule]] = defaultdict(list)
        for plan in self.countries.values():
            for rule, res in plan.resolutions:
                out[(res.country, res.logical_field)].append(rule)
        return out

    def describe(self) -> str:
        lines: List[str] = []
        for country in sorted(self.countries):
            plan = self.countries[country]
            lines.append(f"{country}  (eligible RT TYPEs: {', '.join(plan.eligible_rt_types) or 'none'})")
            by_rule: Dict[str, Dict[str, List[str]]] = defaultdict(lambda: defaultdict(list))
            for column, specs in plan.by_column.items():
                for bindings in specs.values():
                    for b in bindings:
                        for logical in b.logical_field.split("|"):
                            by_rule[b.rule.rule_id][logical].append(column)
            for rt in plan.eligible_rt_types:
                lines.append(f"  {rt}")
                for rule in [r for r in plan.rules if r.rt_type == rt]:
                    rules = ",".join(rule.exclusion_rules) or "-"
                    lines.append(f"    {rule.keyword}  [{rule.match_type}]  rules={rules}  ({rule.rule_id})")
                    for logical in rule.logical_fields:
                        cols = sorted(set(by_rule[rule.rule_id].get(logical, [])))
                        target = ", ".join(cols) if cols else "!! SCHEMA_MAPPING_ERROR - not searched"
                        lines.append(f"      {logical:<14} -> {target}")
            lines.append("")
        lines.append("Compiled column matchers:")
        for column in sorted(self.matchers):
            m = self.matchers[column]
            lines.append(f"  {column}: {len(m.specs)} keyword specs, backend={m.backend_name}, "
                         f"countries={','.join(sorted(self.column_countries[column]))}")
        return "\n".join(lines)


class SearchPlanBuilder:
    def __init__(self, scenarios: ScenarioEngine, resolver: ColumnResolver, normalizer: TextNormalizer,
                 settings: MatchingSettings):
        self.scenarios = scenarios
        self.resolver = resolver
        self.normalizer = normalizer
        self.settings = settings

    def build(self, countries: Sequence[str], header: Sequence[str]) -> SearchPlan:
        plans: Dict[str, CountrySearchPlan] = {}
        for country in sorted(set(countries)):
            rules = self.scenarios.rules_for_country(country)
            plan = CountrySearchPlan(country, self.scenarios.eligible_rt_types(country), rules)
            merged: Dict[Tuple[str, str], List[str]] = defaultdict(list)   # (rule_id, column) -> logical fields
            rule_by_id = {}
            for rule in rules:
                rule_by_id[rule.rule_id] = rule
                for logical in rule.logical_fields:
                    res = self.resolver.resolve_detailed(country, logical, header)
                    plan.resolutions.append((rule, res))
                    if res.ok:
                        for column in res.physical_columns:
                            if logical not in merged[(rule.rule_id, column)]:
                                merged[(rule.rule_id, column)].append(logical)
            for (rule_id, column), logicals in merged.items():
                rule = rule_by_id[rule_id]
                binding = RuleBinding(rule, "|".join(logicals), column)
                plan.by_column.setdefault(column, {}).setdefault(rule.spec_id, []).append(binding)
            plans[country] = plan

        column_specs: Dict[str, Set[int]] = defaultdict(set)
        column_countries: Dict[str, Set[str]] = defaultdict(set)
        for country, plan in plans.items():
            for column, specs in plan.by_column.items():
                column_specs[column].update(specs)
                column_countries[column].add(country)
        registry = self.scenarios.keywords
        shared: Dict[frozenset, ColumnMatcher] = {}
        matchers: Dict[str, ColumnMatcher] = {}
        for column in sorted(column_specs):
            key = frozenset(column_specs[column])
            if key not in shared:
                shared[key] = ColumnMatcher([registry.specs[s] for s in sorted(key)], self.normalizer, self.settings)
            matchers[column] = shared[key]
        return SearchPlan(plans, matchers, dict(column_countries), registry)

"""ScoringEngine: scores rank, rules decide.

Scores never change a decision (decisions are deterministic rule outcomes);
they order work for investigators and make each record self-explaining.

MATCH_SCORE       similarity of the matched text to the keyword (0-100):
                  EXACT/TOKEN 100, PHRASE 100 - 5 per intervening token,
                  FUZZY = rapidfuzz ratio, SUBSTRING = share of the enclosing word.
CONFIDENCE_SCORE  ALERT    -> match_score/100 x match-type weight x field weight
                  EXCLUDED -> confidence of the classifier that triggered the exclusion
"""
from __future__ import annotations

from typing import Optional

from ..models import Decision
from ..rules.rule_engine import RuleOutcome
from ..settings import ScoringSettings


class ScoringEngine:
    def __init__(self, settings: ScoringSettings):
        self.field_weights = {k.upper(): float(v) for k, v in settings.field_weights.items()}
        self.type_weights = {k.upper(): float(v) for k, v in settings.match_type_weights.items()}
        self.default_field_weight = self.field_weights.get("DEFAULT", 1.0)

    def confidence(self, decision: str, match_score: float, match_type: str, logical_field: str,
                   primary: Optional[RuleOutcome]) -> float:
        if decision == Decision.EXCLUDED and primary is not None and primary.result is not None:
            return round(float(primary.result.confidence), 4)
        weight = self.type_weights.get(match_type, 1.0) * self.field_weights.get(logical_field.upper(),
                                                                                 self.default_field_weight)
        return round(max(0.0, min(1.0, match_score / 100.0 * weight)), 4)

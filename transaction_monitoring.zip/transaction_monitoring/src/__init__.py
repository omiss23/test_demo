"""Configuration-driven, multi-country transaction monitoring framework.

The package is organised by responsibility (ingestion, validation, schema,
normalization, matching, context, rules, scenarios, scoring, pipeline, output).
`src.monitoring_engine.MonitoringEngine` is the single orchestration entry point.
"""

__version__ = "1.0.0"
ENGINE_NAME = "tm-framework"

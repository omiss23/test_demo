"""ColumnResolver: (country, logical field, CSV header) -> physical columns.

Resolution is controlled and explainable. In order:
  1. Explicit mapping from the country profile (inheriting from DEFAULT).
  2. Exact alias match against the header (case-sensitive, verbatim).
  3. Controlled alias match: canonical comparison only ('Beneficiary Name' ==
     'BENEFICIARY_NAME'); two header columns with the same canonical form are
     reported as AMBIGUOUS and never guessed.
  4. Identity mapping (optional): a column literally named like the logical field.
  5. Fuzzy *suggestions* for unresolved fields - reported, never applied.

A column like BENEFICIARY_ACCOUNT is never used for BENEFICIARY unless a
profile lists it explicitly: there is no prefix or fuzzy matching on names.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence, Tuple

from ..settings import SchemaSettings
from ..utils import canonical_name
from .schema_registry import DEFAULT_PROFILE, RESOLUTION_FIRST, SchemaRegistry

STATUS_RESOLVED = "RESOLVED"
STATUS_UNRESOLVED = "SCHEMA_MAPPING_ERROR"
STATUS_UNKNOWN_FIELD = "UNKNOWN_LOGICAL_FIELD"
STATUS_AMBIGUOUS = "AMBIGUOUS_COLUMN"


@dataclass
class ResolutionResult:
    country: str
    logical_field: str
    status: str
    physical_columns: List[str] = field(default_factory=list)
    methods: List[str] = field(default_factory=list)          # per physical column
    profile_used: str = ""
    configured_candidates: List[str] = field(default_factory=list)
    missing_candidates: List[str] = field(default_factory=list)
    suggestions: List[str] = field(default_factory=list)
    detail: str = ""

    @property
    def ok(self) -> bool:
        return self.status == STATUS_RESOLVED and bool(self.physical_columns)


class ColumnResolver:
    def __init__(self, registry: SchemaRegistry, settings: Optional[SchemaSettings] = None):
        self.registry = registry
        self.settings = settings or SchemaSettings()
        self._cache: Dict[Tuple[str, str, Tuple[str, ...]], ResolutionResult] = {}

    # Public API requested by the specification ------------------------------
    def resolve(self, country: str, logical_field: str, available_columns: Sequence[str]) -> List[str]:
        return list(self.resolve_detailed(country, logical_field, available_columns).physical_columns)

    # ---------------------------------------------------------------------- #
    def resolve_detailed(self, country: str, logical_field: str,
                         available_columns: Sequence[str]) -> ResolutionResult:
        header = tuple(available_columns)
        key = (country, logical_field, header)
        cached = self._cache.get(key)
        if cached is not None:
            return cached
        result = self._resolve((country or "").strip().upper(), canonical_name(logical_field), header)
        self._cache[key] = result
        return result

    def _resolve(self, country: str, logical: str, header: Tuple[str, ...]) -> ResolutionResult:
        exact = set(header)
        canonical: Dict[str, List[str]] = {}
        for column in header:
            canonical.setdefault(canonical_name(column), []).append(column)

        mapping, profile_used = self.registry.field_mapping(country, logical)
        result = ResolutionResult(country, logical, STATUS_UNRESOLVED, profile_used=profile_used)

        if mapping is None:
            # Not configured anywhere: identity mapping is the only deterministic option.
            if self.settings.allow_identity_mapping:
                found = self._lookup(logical, exact, canonical)
                if found and found[0] != "AMBIGUOUS":
                    result.status = STATUS_RESOLVED
                    result.physical_columns = [found[1]]
                    result.methods = ["IDENTITY"]
                    result.profile_used = "(identity)"
                    result.detail = (f"'{logical}' is not defined in any schema profile; the column with the same "
                                     f"name was used (identity mapping)")
                    return result
            result.status = STATUS_UNKNOWN_FIELD
            result.suggestions = self._suggest(logical, self.registry.logical_fields(), threshold_floor=70)
            result.detail = (f"Logical field '{logical}' is not defined for country {country or '?'} "
                             f"or in DEFAULT, and no column named '{logical}' exists")
            return result

        result.configured_candidates = list(mapping.candidates)
        ambiguous: List[str] = []
        for candidate in mapping.candidates:
            found = self._lookup(candidate, exact, canonical)
            if found is None:
                result.missing_candidates.append(candidate)
                continue
            if found[0] == "AMBIGUOUS":
                ambiguous.append(f"{candidate} -> {found[1]}")
                continue
            method, column = found
            if column not in result.physical_columns:
                result.physical_columns.append(column)
                result.methods.append(method)
            if mapping.resolution == RESOLUTION_FIRST:
                break

        if result.physical_columns:
            result.status = STATUS_RESOLVED
            pieces = [f"{c} ({m})" for c, m in zip(result.physical_columns, result.methods)]
            result.detail = f"{logical} -> {', '.join(pieces)} via profile {profile_used}"
            if ambiguous:
                result.detail += f"; ignored ambiguous candidates: {'; '.join(ambiguous)}"
            return result

        if ambiguous:
            result.status = STATUS_AMBIGUOUS
            result.detail = f"Candidates match several header columns after canonicalisation: {'; '.join(ambiguous)}"
            return result

        # Country profile found nothing: optionally try the DEFAULT profile's explicit aliases
        # (typical for multi-country files that use a group-wide layout). Reported, never silent.
        if self.settings.fallback_to_default_profile and profile_used not in ("", DEFAULT_PROFILE):
            default_mapping, _ = self.registry.field_mapping(DEFAULT_PROFILE, logical)
            if default_mapping is not None:
                for candidate in default_mapping.candidates:
                    found = self._lookup(candidate, exact, canonical)
                    if found is None or found[0] == "AMBIGUOUS":
                        continue
                    if found[1] not in result.physical_columns:
                        result.physical_columns.append(found[1])
                        result.methods.append(f"{found[0]}+DEFAULT_FALLBACK")
                    if default_mapping.resolution == RESOLUTION_FIRST:
                        break
                if result.physical_columns:
                    result.status = STATUS_RESOLVED
                    result.detail = (f"None of {list(mapping.candidates)} (profile {profile_used}) exist; resolved "
                                     f"through DEFAULT profile aliases -> {', '.join(result.physical_columns)}")
                    return result

        result.status = STATUS_UNRESOLVED
        result.suggestions = self._suggest_columns(mapping.candidates, header)
        result.detail = (f"None of the configured columns {list(mapping.candidates)} for {logical} "
                         f"(profile {profile_used}) exist in the file")
        return result

    def _lookup(self, name: str, exact: set, canonical: Dict[str, List[str]]):
        if name in exact:
            return ("EXACT", name)
        if self.settings.canonical_header_matching:
            hits = canonical.get(canonical_name(name), [])
            if len(hits) == 1:
                return ("CANONICAL", hits[0])
            if len(hits) > 1:
                return ("AMBIGUOUS", ", ".join(hits))
        return None

    # ---------------------------------------------------------------------- #
    def _suggest_columns(self, candidates: Sequence[str], header: Sequence[str]) -> List[str]:
        if not self.settings.fuzzy_suggestions:
            return []
        scored: Dict[str, float] = {}
        for candidate in candidates:
            for column, score in _similar(canonical_name(candidate), [canonical_name(h) for h in header], header):
                if score >= self.settings.fuzzy_suggestion_threshold:
                    scored[column] = max(score, scored.get(column, 0.0))
        return [f"{col} ({score:.0f})" for col, score in sorted(scored.items(), key=lambda kv: -kv[1])[:5]]

    def _suggest(self, name: str, options: Sequence[str], threshold_floor: float = 70) -> List[str]:
        if not self.settings.fuzzy_suggestions or not options:
            return []
        threshold = min(self.settings.fuzzy_suggestion_threshold, threshold_floor)
        out = [(opt, score) for opt, score in _similar(name, list(options), list(options)) if score >= threshold]
        return [f"{opt} ({score:.0f})" for opt, score in sorted(out, key=lambda kv: -kv[1])[:5]]


def _similar(query: str, canon_options: List[str], display: Sequence[str]):
    """Yield (display_option, similarity 0-100). rapidfuzz if present, difflib otherwise."""
    try:
        from rapidfuzz import fuzz  # type: ignore

        for canon, shown in zip(canon_options, display):
            yield shown, float(fuzz.ratio(query, canon))
    except ImportError:  # pragma: no cover - exercised only without rapidfuzz
        import difflib

        for canon, shown in zip(canon_options, display):
            yield shown, 100.0 * difflib.SequenceMatcher(None, query, canon).ratio()

"""Resolve the country of every transaction with a configurable strategy order.

Strategies (settings.country_resolution.order, first one that yields a valid
ISO code wins, row by row):
  cli           --country IN on the command line (file-level constant)
  column        a country column in the file (row-level, e.g. COUNTRY)
  file_pattern  file-name patterns, e.g. india_*.csv -> IN (file-level constant)
  default       settings default_country (file-level constant)

Country values are normalised (trim, upper case, aliases such as UK -> GB)
and validated against ISO 3166-1 alpha-2. Rows that no strategy can resolve
are reported as COUNTRY_UNRESOLVED errors - they are never silently skipped.
"""
from __future__ import annotations

import fnmatch
from collections import Counter
from pathlib import Path
from typing import Dict, List, Optional, Sequence

import numpy as np
import pandas as pd

from ..exceptions import ConfigurationError
from ..settings import CountryResolutionSettings
from ..utils import canonical_name
from .iso_countries import ISO_ALPHA2


class CountryResolver:
    def __init__(self, settings: CountryResolutionSettings, header: Sequence[str],
                 input_path: Optional[Path] = None, cli_country: Optional[str] = None):
        self.settings = settings
        self.order = [s.lower() for s in settings.order]
        self.valid = set(ISO_ALPHA2) | {c.strip().upper() for c in settings.extra_valid_codes}
        self.aliases = {str(k).strip().upper(): str(v).strip().upper() for k, v in settings.aliases.items()}

        self.cli_country = self._require_valid(cli_country, "--country") if cli_country else None
        self.file_country = self._match_file_pattern(input_path) if input_path else None
        self.default_country = (self._require_valid(settings.default_country, "default_country")
                                if settings.default_country else None)
        self.country_column = self._find_column(header) if "column" in self.order else None

        # run statistics
        self.invalid_values: Counter = Counter()
        self.conflicts: Counter = Counter()
        self.method_counts: Counter = Counter()

    # ------------------------------------------------------------------ #
    def normalize_code(self, raw: object) -> str:
        """'in ' -> 'IN', 'UK' -> 'GB', invalid -> ''."""
        code = str(raw or "").strip().upper()
        code = self.aliases.get(code, code)
        return code if code in self.valid else ""

    def _require_valid(self, raw: object, origin: str) -> str:
        code = self.normalize_code(raw)
        if not code:
            raise ConfigurationError(f"{origin} value '{raw}' is not a valid ISO 3166-1 alpha-2 country code")
        return code

    def _match_file_pattern(self, path: Path) -> Optional[str]:
        name = Path(path).name.lower()
        for entry in self.settings.file_patterns or []:
            pattern = str(entry.get("pattern", "")).lower()
            if pattern and fnmatch.fnmatch(name, pattern):
                return self._require_valid(entry.get("country"), f"file pattern '{pattern}'")
        return None

    def _find_column(self, header: Sequence[str]) -> Optional[str]:
        header = list(header)
        for wanted in self.settings.country_columns:
            if wanted in header:
                return wanted
        canon = {canonical_name(h): h for h in header}
        for wanted in self.settings.country_columns:
            if canonical_name(wanted) in canon:
                return canon[canonical_name(wanted)]
        return None

    # ------------------------------------------------------------------ #
    def available_strategies(self) -> List[str]:
        out = []
        for strategy in self.order:
            if (strategy == "cli" and self.cli_country) or (strategy == "column" and self.country_column) or \
               (strategy == "file_pattern" and self.file_country) or (strategy == "default" and self.default_country):
                out.append(strategy)
        return out

    def ensure_resolvable(self) -> None:
        if not self.available_strategies():
            raise ConfigurationError(
                "The transaction country cannot be determined: pass --country, add a country column "
                f"({', '.join(self.settings.country_columns)}), configure country_resolution.file_patterns "
                "or set country_resolution.default_country")

    def constant_for(self, strategy: str) -> Optional[str]:
        return {"cli": self.cli_country, "file_pattern": self.file_country,
                "default": self.default_country}.get(strategy)

    def is_file_level(self) -> bool:
        """True when a constant strategy wins before any row-level column strategy."""
        for strategy in self.available_strategies():
            return strategy != "column"
        return False

    def countries_to_plan(self, column_value_counts: Optional[Dict[str, int]] = None) -> List[str]:
        """Countries that can occur in this file (from the pre-pass), for building search plans."""
        countries = set()
        strategies = self.available_strategies()
        if not strategies:
            return []
        if strategies[0] != "column":
            return [self.constant_for(strategies[0])]
        for raw in (column_value_counts or {}):
            code = self.normalize_code(raw)
            if code:
                countries.add(code)
        for strategy in strategies[1:]:   # fallbacks fill blank / invalid column values
            const = self.constant_for(strategy)
            if const:
                countries.add(const)
                break
        return sorted(countries)

    def describe(self) -> Dict[str, object]:
        return {
            "strategy_order": self.order,
            "available_strategies": self.available_strategies(),
            "cli_country": self.cli_country,
            "country_column": self.country_column,
            "file_pattern_country": self.file_country,
            "default_country": self.default_country,
            "rows_resolved_by": dict(self.method_counts),
            "invalid_column_values": dict(self.invalid_values.most_common(50)),
            "conflicts_with_column": dict(self.conflicts.most_common(50)),
        }

    # ------------------------------------------------------------------ #
    def resolve_chunk(self, chunk: pd.DataFrame) -> np.ndarray:
        """Vectorised row-level resolution -> object array of ISO codes ('' = unresolved)."""
        n = len(chunk)
        result = np.full(n, "", dtype=object)
        unresolved = np.ones(n, dtype=bool)
        column_codes = None
        if self.country_column and self.country_column in chunk.columns:
            raw = chunk[self.country_column].astype(str).str.strip().str.upper()
            mapped = raw.map(lambda v: self.aliases.get(v, v))
            valid_mask = mapped.isin(self.valid).to_numpy()
            column_codes = mapped.to_numpy(dtype=object)
            invalid = raw[(~valid_mask) & (raw != "").to_numpy()]
            if len(invalid):
                self.invalid_values.update(invalid.value_counts().to_dict())
        for strategy in self.available_strategies():
            if not unresolved.any():
                break
            if strategy == "column":
                if column_codes is None:
                    continue
                take = unresolved & valid_mask
                result[take] = column_codes[take]
            else:
                take = unresolved
                result[take] = self.constant_for(strategy)
            count = int(take.sum())
            if count:
                self.method_counts[strategy] += count
            unresolved &= ~take
        # Report disagreement between a winning constant and the data's own country column
        if column_codes is not None and self.is_file_level():
            disagree = valid_mask & (column_codes != result)
            if disagree.any():
                pairs = pd.Series(column_codes[disagree]).value_counts().to_dict()
                for code, count in pairs.items():
                    self.conflicts[f"{code}->{self.constant_for(self.available_strategies()[0])}"] += int(count)
        return result

"""Country schema profiles: which physical columns implement each logical field.

The registry is storage-agnostic. Loaders exist for:
  * Excel / CSV tables   COUNTRY | LOGICAL_FIELD | PHYSICAL_COLUMN | [PRIORITY] | [RESOLUTION] | [STATUS]
  * a SQL table          same columns (any DB-API connection, e.g. sqlite3, pyodbc)
  * YAML / JSON profiles one file per country (or a single file with a `profiles` list)

All loaders produce the same `SchemaRegistry`, so the engine never knows where
the mapping came from. A profile can inherit from DEFAULT: a country profile
overrides DEFAULT field-by-field (a field defined in the country profile
replaces the DEFAULT definition entirely - candidates are not merged).
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

import pandas as pd

from ..exceptions import ConfigurationError
from ..models import Severity, ValidationIssue
from ..utils import canonical_name, sha256_file, sha256_paths, version_label

DEFAULT_PROFILE = "DEFAULT"
RESOLUTION_ALL = "ALL"      # search every configured column that exists (default - favours recall)
RESOLUTION_FIRST = "FIRST"  # search only the highest-priority column that exists
_DEFAULT_ALIASES = {"*", "DEFAULT", "ALL", "ANY"}


@dataclass(frozen=True)
class FieldMapping:
    logical_field: str
    candidates: Tuple[str, ...]          # physical column names in priority order
    resolution: str = RESOLUTION_ALL
    source: str = ""


@dataclass
class SchemaProfile:
    profile_id: str                      # ISO country code or DEFAULT
    fields: Dict[str, FieldMapping] = field(default_factory=dict)
    extends: Optional[str] = DEFAULT_PROFILE
    version: str = ""


class SchemaRegistry:
    def __init__(self, profiles: Dict[str, SchemaProfile], source: str, sha256: str,
                 declared_version: Optional[str] = None):
        self.profiles = profiles
        self.source = source
        self.sha256 = sha256
        self.version = version_label(declared_version, sha256)

    def field_mapping(self, country: str, logical_field: str) -> Tuple[Optional[FieldMapping], str]:
        """Return (mapping, profile_used) following the inheritance chain."""
        visited = set()
        profile_id: Optional[str] = country if country in self.profiles else DEFAULT_PROFILE
        while profile_id and profile_id not in visited:
            visited.add(profile_id)
            profile = self.profiles.get(profile_id)
            if profile is None:
                break
            if logical_field in profile.fields:
                return profile.fields[logical_field], profile_id
            profile_id = profile.extends if profile_id != DEFAULT_PROFILE else None
        return None, ""

    def logical_fields(self) -> List[str]:
        names = set()
        for profile in self.profiles.values():
            names.update(profile.fields)
        return sorted(names)

    def all_physical_columns(self) -> List[str]:
        cols = set()
        for profile in self.profiles.values():
            for mapping in profile.fields.values():
                cols.update(mapping.candidates)
        return sorted(cols)

    def has_profile(self, country: str) -> bool:
        return country in self.profiles


# --------------------------------------------------------------------------- #
# Loaders
# --------------------------------------------------------------------------- #
def load_schema_registry(path: Path) -> Tuple[SchemaRegistry, List[ValidationIssue]]:
    """Pick the loader from the path: directory -> YAML/JSON profiles; file -> by extension."""
    path = Path(path)
    if not path.exists():
        raise ConfigurationError(f"Schema configuration not found: {path}")
    if path.is_dir():
        files = sorted([p for p in path.iterdir() if p.suffix.lower() in (".yaml", ".yml", ".json")])
        if not files:
            raise ConfigurationError(f"No .yaml/.yml/.json schema profiles in {path}")
        return ProfileFileLoader(files, sha256_paths(files), str(path)).load()
    suffix = path.suffix.lower()
    if suffix in (".xlsx", ".xlsm", ".xls"):
        return ExcelSchemaLoader(path).load()
    if suffix == ".csv":
        return TableSchemaLoader(pd.read_csv(path, dtype=str, keep_default_na=False), str(path),
                                 sha256_file(path)).load()
    if suffix in (".yaml", ".yml", ".json"):
        return ProfileFileLoader([path], sha256_file(path), str(path)).load()
    if suffix in (".db", ".sqlite", ".sqlite3"):
        import sqlite3

        with sqlite3.connect(str(path)) as conn:
            return SqlSchemaLoader(conn, source=str(path), sha256=sha256_file(path)).load()
    raise ConfigurationError(f"Unsupported schema configuration format: {path}")


class TableSchemaLoader:
    """Shared parser for tabular sources (Excel sheet, CSV, SQL result)."""

    REQUIRED = ("COUNTRY", "LOGICAL_FIELD", "PHYSICAL_COLUMN")

    def __init__(self, frame: pd.DataFrame, source: str, sha256: str, declared_version: Optional[str] = None,
                 row_offset: int = 2):
        self.frame = frame
        self.source = source
        self.sha256 = sha256
        self.declared_version = declared_version
        self.row_offset = row_offset   # Excel: header is row 1, first data row is 2

    def load(self) -> Tuple[SchemaRegistry, List[ValidationIssue]]:
        issues: List[ValidationIssue] = []
        frame = self.frame.copy()
        frame.columns = [canonical_name(c) for c in frame.columns]
        missing = [c for c in self.REQUIRED if c not in frame.columns]
        if missing:
            raise ConfigurationError(f"{self.source}: schema table is missing columns {missing}")
        frame = frame.fillna("").astype(str)
        groups: Dict[Tuple[str, str], List[Tuple[float, int, str, str]]] = {}
        resolutions: Dict[Tuple[str, str], set] = {}
        for idx, row in enumerate(frame.to_dict("records")):
            row_no = idx + self.row_offset
            status = row.get("STATUS", "").strip().upper() or "ACTIVE"
            if status != "ACTIVE":
                continue
            country = _profile_id(row["COUNTRY"])
            logical = canonical_name(row["LOGICAL_FIELD"])
            physical = row["PHYSICAL_COLUMN"].strip()
            if not country or not logical or not physical:
                issues.append(ValidationIssue(Severity.ERROR, "schema", "INCOMPLETE_SCHEMA_ROW",
                                              "COUNTRY, LOGICAL_FIELD and PHYSICAL_COLUMN are all required",
                                              row=row_no))
                continue
            priority_raw = row.get("PRIORITY", "").strip()
            try:
                priority = float(priority_raw) if priority_raw else float(row_no)
            except ValueError:
                issues.append(ValidationIssue(Severity.WARNING, "schema", "INVALID_PRIORITY",
                                              f"PRIORITY '{priority_raw}' is not numeric; row order used",
                                              row=row_no, value=priority_raw))
                priority = float(row_no)
            key = (country, logical)
            groups.setdefault(key, []).append((priority, row_no, physical, f"{self.source}:row {row_no}"))
            resolution = row.get("RESOLUTION", "").strip().upper()
            if resolution:
                resolutions.setdefault(key, set()).add(resolution)

        profiles: Dict[str, SchemaProfile] = {}
        for (country, logical), entries in groups.items():
            entries.sort()
            seen = set()
            candidates = []
            for _, row_no, physical, _ in entries:
                if physical in seen:
                    issues.append(ValidationIssue(Severity.WARNING, "schema", "DUPLICATE_SCHEMA_ROW",
                                                  f"{country}/{logical} lists {physical} more than once",
                                                  row=row_no, value=physical))
                    continue
                seen.add(physical)
                candidates.append(physical)
            res_values = resolutions.get((country, logical), set())
            resolution = RESOLUTION_ALL
            if len(res_values) > 1:
                issues.append(ValidationIssue(Severity.ERROR, "schema", "CONFLICTING_RESOLUTION",
                                              f"{country}/{logical} has conflicting RESOLUTION values {sorted(res_values)};"
                                              f" using ALL", field=logical))
            elif res_values:
                resolution = res_values.pop()
                if resolution not in (RESOLUTION_ALL, RESOLUTION_FIRST):
                    issues.append(ValidationIssue(Severity.ERROR, "schema", "INVALID_RESOLUTION",
                                                  f"{country}/{logical}: RESOLUTION must be ALL or FIRST; using ALL",
                                                  field=logical, value=resolution))
                    resolution = RESOLUTION_ALL
            profile = profiles.setdefault(country, SchemaProfile(country))
            profile.fields[logical] = FieldMapping(logical, tuple(candidates), resolution, entries[0][3])
        if DEFAULT_PROFILE in profiles:
            profiles[DEFAULT_PROFILE].extends = None
        return SchemaRegistry(profiles, self.source, self.sha256, self.declared_version), issues


class ExcelSchemaLoader:
    """Excel workbook: first sheet named like 'Schema'/'Schema_Mapping', else the first sheet.

    An optional 'Metadata' sheet (KEY | VALUE) can declare VERSION.
    """

    def __init__(self, path: Path):
        self.path = Path(path)

    def load(self) -> Tuple[SchemaRegistry, List[ValidationIssue]]:
        try:
            book = pd.read_excel(self.path, sheet_name=None, dtype=str, keep_default_na=False)
        except Exception as exc:  # pragma: no cover - depends on file
            raise ConfigurationError(f"Cannot read schema workbook {self.path}: {exc}") from exc
        sheets = {canonical_name(name): frame for name, frame in book.items()}
        frame = None
        for wanted in ("SCHEMA_MAPPING", "COUNTRY_SCHEMA_MAPPING", "SCHEMA", "MAPPING"):
            if wanted in sheets:
                frame = sheets[wanted]
                break
        if frame is None:
            frame = next(iter(book.values()))
        declared = _metadata_version(sheets.get("METADATA"))
        return TableSchemaLoader(frame, str(self.path), sha256_file(self.path), declared).load()


class SqlSchemaLoader:
    """Read the same table layout from a database (DB-API connection or SQLAlchemy engine)."""

    def __init__(self, connection: Any, query: str = "SELECT * FROM schema_mapping",
                 source: str = "database", sha256: Optional[str] = None, declared_version: Optional[str] = None):
        self.connection = connection
        self.query = query
        self.source = source
        self.sha256 = sha256
        self.declared_version = declared_version

    def load(self) -> Tuple[SchemaRegistry, List[ValidationIssue]]:
        frame = pd.read_sql_query(self.query, self.connection).astype(str)
        digest = self.sha256
        if digest is None:
            from ..utils import sha256_text

            digest = sha256_text(frame.to_csv(index=False))
        return TableSchemaLoader(frame, self.source, digest, self.declared_version, row_offset=1).load()


class ProfileFileLoader:
    """YAML/JSON profiles.

    Accepted shapes (per file):
        country: IN            # or profile: DEFAULT
        version: "2026.10"     # optional
        extends: DEFAULT       # optional (default DEFAULT)
        fields:
          BENEFICIARY: [BENEFICIARY_NAME, BENE_NAME]
          ADDRESS: {columns: [ADDR1, ADDR2, CITY], resolution: ALL}
    or a single file with `profiles: [ {...}, {...} ]`.
    """

    def __init__(self, files: Iterable[Path], sha256: str, source: str):
        self.files = list(files)
        self.sha256 = sha256
        self.source = source

    def load(self) -> Tuple[SchemaRegistry, List[ValidationIssue]]:
        issues: List[ValidationIssue] = []
        profiles: Dict[str, SchemaProfile] = {}
        versions = set()
        for path in self.files:
            documents = self._read(path)
            for doc in documents:
                profile_id = _profile_id(doc.get("country") or doc.get("profile") or path.stem)
                if profile_id in profiles:
                    issues.append(ValidationIssue(Severity.ERROR, "schema", "DUPLICATE_PROFILE",
                                                  f"Profile {profile_id} defined more than once ({path.name})",
                                                  value=profile_id))
                    continue
                extends = doc.get("extends", DEFAULT_PROFILE if profile_id != DEFAULT_PROFILE else None)
                profile = SchemaProfile(profile_id, extends=_profile_id(extends) if extends else None,
                                        version=str(doc.get("version", "") or ""))
                if profile.version:
                    versions.add(profile.version)
                raw_fields = doc.get("fields") or {}
                if not isinstance(raw_fields, dict):
                    raise ConfigurationError(f"{path}: 'fields' must be a mapping of logical field -> columns")
                for logical_raw, spec in raw_fields.items():
                    logical = canonical_name(logical_raw)
                    resolution = RESOLUTION_ALL
                    if isinstance(spec, dict):
                        columns = spec.get("columns") or []
                        resolution = str(spec.get("resolution", RESOLUTION_ALL)).upper()
                    elif isinstance(spec, str):
                        columns = [spec]
                    else:
                        columns = list(spec or [])
                    if resolution not in (RESOLUTION_ALL, RESOLUTION_FIRST):
                        issues.append(ValidationIssue(Severity.ERROR, "schema", "INVALID_RESOLUTION",
                                                      f"{profile_id}/{logical}: resolution must be ALL or FIRST",
                                                      field=logical, value=resolution))
                        resolution = RESOLUTION_ALL
                    cleaned: List[str] = []
                    for col in columns:
                        col = str(col).strip()
                        if col and col not in cleaned:
                            cleaned.append(col)
                    if not cleaned:
                        issues.append(ValidationIssue(Severity.ERROR, "schema", "EMPTY_FIELD_MAPPING",
                                                      f"{profile_id}/{logical} lists no physical columns",
                                                      field=logical))
                        continue
                    profile.fields[logical] = FieldMapping(logical, tuple(cleaned), resolution, f"{path.name}")
                profiles[profile_id] = profile
        declared = "+".join(sorted(versions)) if versions else None
        return SchemaRegistry(profiles, self.source, self.sha256, declared), issues

    @staticmethod
    def _read(path: Path) -> List[Dict[str, Any]]:
        with open(path, "r", encoding="utf-8") as handle:
            if path.suffix.lower() == ".json":
                data = json.load(handle)
            else:
                import yaml  # type: ignore

                data = yaml.safe_load(handle)
        if data is None:
            return []
        if isinstance(data, dict) and "profiles" in data:
            data = data["profiles"]
        if isinstance(data, dict):
            return [data]
        if isinstance(data, list):
            return [d for d in data if isinstance(d, dict)]
        raise ConfigurationError(f"{path}: unsupported schema profile structure")


def _profile_id(value: object) -> str:
    text = str(value or "").strip().upper()
    return DEFAULT_PROFILE if text in _DEFAULT_ALIASES else text


def _metadata_version(frame: Optional[pd.DataFrame]) -> Optional[str]:
    if frame is None or frame.empty:
        return None
    frame = frame.fillna("").astype(str)
    cols = [canonical_name(c) for c in frame.columns]
    frame.columns = cols
    if "KEY" in cols and "VALUE" in cols:
        for key, value in zip(frame["KEY"], frame["VALUE"]):
            if canonical_name(key) == "VERSION" and value.strip():
                return value.strip()
    return None

"""Run-level outputs: run_summary.json / run_summary.csv, search_plan.txt and status markers."""
from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any, Dict, List, Tuple


class SummaryWriter:
    def __init__(self, output_dir: Path):
        self.output_dir = Path(output_dir)

    def write(self, summary: Dict[str, Any]) -> Tuple[Path, Path]:
        json_path = self.output_dir / "run_summary.json"
        with open(json_path, "w", encoding="utf-8") as handle:
            json.dump(summary, handle, indent=2, default=str, ensure_ascii=False)
        csv_path = self.output_dir / "run_summary.csv"
        with open(csv_path, "w", encoding="utf-8", newline="") as handle:
            writer = csv.writer(handle, lineterminator="\n")
            writer.writerow(["METRIC", "VALUE"])
            for key, value in _flatten(summary):
                writer.writerow([key, value])
        return json_path, csv_path

    def write_text(self, name: str, text: str) -> Path:
        path = self.output_dir / name
        with open(path, "w", encoding="utf-8") as handle:
            handle.write(text)
        return path

    def mark(self, status: str, detail: str = "") -> Path:
        for stale in ("_SUCCESS", "_FAILED", "_RUNNING"):
            p = self.output_dir / stale
            if p.exists():
                p.unlink()
        path = self.output_dir / status
        path.write_text(detail, encoding="utf-8")
        return path


def _flatten(data: Any, prefix: str = "") -> List[Tuple[str, Any]]:
    items: List[Tuple[str, Any]] = []
    if isinstance(data, dict):
        for key, value in data.items():
            items.extend(_flatten(value, f"{prefix}.{key}" if prefix else str(key)))
    elif isinstance(data, list) and data and all(isinstance(x, (str, int, float)) for x in data):
        items.append((prefix, ", ".join(str(x) for x in data)))
    elif isinstance(data, list):
        for i, value in enumerate(data):
            items.extend(_flatten(value, f"{prefix}[{i}]"))
    else:
        items.append((prefix, data))
    return items

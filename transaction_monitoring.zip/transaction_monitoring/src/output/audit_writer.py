"""monitoring_audit.csv (every decision), errors.csv and the optional screening ledger."""
from __future__ import annotations

from .columns import DECISION_COLUMNS, ERROR_COLUMNS, LEDGER_COLUMNS
from .csv_writer import IncrementalCsvWriter


class AuditWriter(IncrementalCsvWriter):
    """Every ALERT and EXCLUDED decision with full evidence and config versions."""

    columns = DECISION_COLUMNS


class ErrorWriter(IncrementalCsvWriter):
    """Transactions that could not be screened (null key, rejected duplicate, unresolved country,
    malformed record, schema mapping error) - each with MESSAGE_KEY where one exists."""

    columns = ERROR_COLUMNS


class LedgerWriter(IncrementalCsvWriter):
    """Optional proof of coverage: one row per input transaction with its screening status."""

    columns = LEDGER_COLUMNS

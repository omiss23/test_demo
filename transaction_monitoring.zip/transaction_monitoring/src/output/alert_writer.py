"""alerts.csv - one row per keyword occurrence x P2 rule whose final decision is ALERT."""
from __future__ import annotations

from .columns import DECISION_COLUMNS, ROLLUP_COLUMNS
from .csv_writer import IncrementalCsvWriter


class AlertWriter(IncrementalCsvWriter):
    columns = DECISION_COLUMNS


class TransactionRollupWriter(IncrementalCsvWriter):
    """alerted_transactions.csv - one investigation record per alerted MESSAGE_KEY."""

    columns = ROLLUP_COLUMNS

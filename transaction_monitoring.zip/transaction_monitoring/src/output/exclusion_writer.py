"""excluded_matches.csv - keyword occurrences suppressed by an exclusion rule (with the evidence)."""
from __future__ import annotations

from .columns import DECISION_COLUMNS
from .csv_writer import IncrementalCsvWriter


class ExclusionWriter(IncrementalCsvWriter):
    columns = DECISION_COLUMNS

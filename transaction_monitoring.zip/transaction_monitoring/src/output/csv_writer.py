"""Incremental CSV writer: opened once, header written exactly once, appended per chunk.

Files are written as '<name>.part' and renamed only when the run completes, so
a half-written alerts.csv can never be mistaken for a finished one.
"""
from __future__ import annotations

import csv
import os
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence

import pandas as pd


class IncrementalCsvWriter:
    columns: List[str] = []

    def __init__(self, path: Path, columns: Optional[Sequence[str]] = None):
        self.final_path = Path(path)
        self.part_path = self.final_path.with_name(self.final_path.name + ".part")
        self.columns = list(columns or self.columns)
        self.rows_written = 0
        self._handle = open(self.part_path, "w", encoding="utf-8", newline="")
        self._writer = csv.writer(self._handle, quoting=csv.QUOTE_MINIMAL, lineterminator="\n")
        self._writer.writerow(self.columns)          # header: once, at open

    def write_records(self, records: Iterable[Dict]) -> int:
        cols = self.columns
        rows = [[_cell(r.get(c, "")) for c in cols] for r in records]
        if rows:
            self._writer.writerows(rows)
            self.rows_written += len(rows)
        return len(rows)

    def write_frame(self, frame: pd.DataFrame) -> int:
        if frame is None or frame.empty:
            return 0
        frame = frame.reindex(columns=self.columns)
        frame.to_csv(self._handle, header=False, index=False, lineterminator="\n")
        self.rows_written += len(frame)
        return len(frame)

    def flush(self) -> None:
        self._handle.flush()

    def close(self, success: bool = True) -> Path:
        if not self._handle.closed:
            self._handle.close()
        if success:
            os.replace(self.part_path, self.final_path)
            return self.final_path
        return self.part_path


def _cell(value):
    if value is None:
        return ""
    if isinstance(value, float):
        if value != value:   # NaN
            return ""
        return f"{value:.4f}".rstrip("0").rstrip(".") if not value.is_integer() else str(int(value))
    return value


def write_report(path: Path, records: Iterable[Dict], columns: Sequence[str]) -> int:
    """Small whole-file reports (validation, data quality) - written once at the end."""
    writer = IncrementalCsvWriter(path, columns)
    count = writer.write_records(records)
    writer.close(True)
    return count

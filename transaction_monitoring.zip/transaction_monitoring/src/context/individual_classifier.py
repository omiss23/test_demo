"""IndividualClassifier: is the matched occurrence part of a natural person's name? (EXCL_INDV)

Transparent, weighted-evidence model (no black box). Every signal comes from
a configurable lexicon (config/reference/individual_indicators.yaml) and is
listed in the reason, so an investigator can see exactly why a hit was or was
not excluded.

Signals (weights are configurable):
  + title at the start of the name / just before the match   (MR, MRS, DR, SHRI, SMT, SHEIKH ...)
  + relationship marker                                      (S/O, D/O, W/O, BIN, BINT, IBN ...)
  + the matched keyword itself is a known given name/surname (e.g. JIHAD)
  + other known given names / surnames in the value
  + 2-4 token name shape, initials ('R K SHARMA')
  - organisation suffixes (LTD, LLC, GMBH, PVT ...) - strong
  - organisation keywords (TRUST, FOUNDATION, RELIEF, BANK, TRADING ...)
  - digits, single-token values, long values
  - free-text field (DESCRIPTION, ADDRESS ...): only the words around the match are
    considered and strong person evidence (title / relationship marker) is required

score = bias + sum(weights);  p(individual) = logistic(score)
  INDIVIDUAL       p >= threshold (default 0.75), confidence p      -> EXCL_INDV may exclude
  BUSINESS_ENTITY  p < 0.5 with organisation evidence, conf. 1 - p
  NOT_INDIVIDUAL   p < 0.5 without organisation evidence, conf. 1 - p
  UNKNOWN          0.5 <= p < threshold (leans person, not enough), confidence p -> never excluded

A bare "first name + last name" shape alone stays below the threshold by
design: shape is supporting evidence, never sufficient on its own.
Country-specific titles/markers come from `country_overrides` in the lexicon.
An optional NER model can be plugged in through `extra_signal_providers`.
"""
from __future__ import annotations

import math
from pathlib import Path
from typing import Callable, Dict, Iterable, List, Optional, Sequence, Set, Tuple

from ..exceptions import ConfigurationError
from ..models import ClassificationResult, MatchContext
from ..normalization.text_normalizer import TextNormalizer
from ..settings import IndividualSettings
from ..utils import sha256_file, version_label
from .base import ContextClassifier

DEFAULT_WEIGHTS: Dict[str, float] = {
    "bias": -1.0,
    "organisation_suffix": -6.0,
    "organisation_keyword": -3.5,
    "title": 3.0,
    "relationship_marker": 2.5,
    "keyword_is_known_name": 1.5,
    "known_name_token": 1.0,
    "known_name_token_cap": 2.0,
    "name_shape": 1.0,
    "initials": 0.5,
    "single_token": -0.5,
    "long_value": -1.5,
    "digits": -2.0,
    "non_name_field": -1.5,
}

Signal = Tuple[str, float, str]
SignalProvider = Callable[[MatchContext, List[str]], Iterable[Signal]]


class _Lexicon:
    def __init__(self, normalizer: TextNormalizer, data: Dict[str, Iterable[str]]):
        def phrases(key: str) -> Set[Tuple[str, ...]]:
            out = set()
            for item in data.get(key) or []:
                norm = normalizer.normalize(item)
                if norm:
                    out.add(tuple(norm.split(" ")))
            return out

        self.titles = _index(phrases("titles"))
        self.markers = _index(phrases("relationship_markers"))
        self.suffixes = _index(phrases("organisation_suffixes"))
        self.terminal_suffixes = _index(phrases("organisation_suffixes_terminal"))
        org = phrases("organisation_keywords")
        self.org_keywords = {p[0] for p in org if len(p) == 1}
        self.org_keyword_phrases = _index({p for p in org if len(p) > 1})
        self.given_names = {p[0] for p in phrases("given_names") if len(p) == 1}
        self.surnames = {p[0] for p in phrases("surnames") if len(p) == 1}
        self.known_names = self.given_names | self.surnames


PhraseIndex = Dict[str, List[Tuple[str, ...]]]


def _index(phrases: Set[Tuple[str, ...]]) -> PhraseIndex:
    """first token -> phrases starting with it (longest first)."""
    index: PhraseIndex = {}
    for phrase in sorted(phrases, key=len, reverse=True):
        index.setdefault(phrase[0], []).append(phrase)
    return index


def _find_phrases(tokens: Sequence[str], index: PhraseIndex, lo: int, hi: int) -> List[Tuple[int, int]]:
    """Positions (start, end inclusive) of lexicon phrases within tokens[lo:hi+1]."""
    found = []
    for i in range(lo, hi + 1):
        for phrase in index.get(tokens[i], ()):
            n = len(phrase)
            if i + n - 1 <= hi and tuple(tokens[i:i + n]) == phrase:
                found.append((i, i + n - 1))
                break
    return found


class IndividualClassifier(ContextClassifier):
    name = "IndividualClassifier"

    def __init__(self, lexicon: Dict, normalizer: TextNormalizer, settings: Optional[IndividualSettings] = None,
                 lexicon_label: str = "inline", extra_signal_providers: Optional[List[SignalProvider]] = None):
        self.settings = settings or IndividualSettings()
        self.threshold = float(self.settings.threshold)
        self.name_fields = {f.strip().upper() for f in self.settings.name_fields}
        self.window = int(self.settings.context_window_tokens)
        self.normalizer = normalizer
        self.weights = dict(DEFAULT_WEIGHTS)
        self.weights.update({k: float(v) for k, v in (lexicon.get("weights") or {}).items()})
        self.lexicon_label = lexicon_label
        self.extra_signal_providers = list(extra_signal_providers or [])
        base_keys = ("titles", "relationship_markers", "organisation_suffixes", "organisation_suffixes_terminal",
                     "organisation_keywords", "given_names", "surnames")
        base = {k: list(lexicon.get(k) or []) for k in base_keys}
        self._base = _Lexicon(normalizer, base)
        self._by_country: Dict[str, _Lexicon] = {}
        for country, extra in (lexicon.get("country_overrides") or {}).items():
            merged = {k: base[k] + list((extra or {}).get(k) or []) for k in base_keys}
            self._by_country[str(country).strip().upper()] = _Lexicon(normalizer, merged)

    @classmethod
    def from_file(cls, path: Path, normalizer: TextNormalizer, settings: IndividualSettings) -> "IndividualClassifier":
        path = Path(path)
        if not path.exists():
            raise ConfigurationError(f"Individual lexicon not found: {path} (needed by EXCL_INDV)")
        import yaml  # type: ignore

        with open(path, "r", encoding="utf-8") as handle:
            data = yaml.safe_load(handle) or {}
        label = f"{path.name} {version_label(str(data.get('version') or '') or None, sha256_file(path))}"
        return cls(data, normalizer, settings, label)

    def lexicon_for(self, country: str) -> _Lexicon:
        return self._by_country.get(country, self._base)

    # ------------------------------------------------------------------ #
    def classify(self, ctx: MatchContext) -> ClassificationResult:
        lex = self.lexicon_for(ctx.country)
        w = self.weights
        tokens = ctx.normalized_value.split(" ") if ctx.normalized_value else []
        spans = TextNormalizer.token_spans(ctx.normalized_value)
        match_tokens = [i for i, (s, e) in enumerate(spans) if s < ctx.end and e > ctx.start]
        if not tokens or not match_tokens:
            return ClassificationResult(self.name, "UNKNOWN", False, 0.5, "No tokens to classify",
                                        self._source("NONE"), {})
        first, last = match_tokens[0], match_tokens[-1]
        field_mode = ctx.logical_field.upper() in self.name_fields
        mode = "FIELD" if field_mode else "WINDOW"
        lo, hi = (0, len(tokens) - 1) if field_mode else (max(0, first - self.window),
                                                          min(len(tokens) - 1, last + self.window))
        signals: List[Signal] = [("bias", w["bias"], "prior")]
        consumed: Set[int] = set()

        # Organisation evidence -------------------------------------------------
        suffixes = []
        for s, e in _find_phrases(tokens, lex.suffixes, lo, hi):          # unambiguous: LTD, LLC, GMBH ...
            suffixes.append(" ".join(tokens[s:e + 1]))
            consumed.update(range(s, e + 1))
        for s, e in _find_phrases(tokens, lex.terminal_suffixes, lo, hi):  # ambiguous: CO, SA, AG - only at the end
            if e == hi:
                suffixes.append(" ".join(tokens[s:e + 1]))
                consumed.update(range(s, e + 1))
        if suffixes:
            signals.append(("organisation_suffix", w["organisation_suffix"], f"organisation suffix '{suffixes[0]}'"))
        org_words = []
        for i in range(lo, hi + 1):
            if tokens[i] in lex.org_keywords and i not in match_tokens:
                org_words.append(tokens[i])
                consumed.add(i)
        for s, e in _find_phrases(tokens, lex.org_keyword_phrases, lo, hi):
            org_words.append(" ".join(tokens[s:e + 1]))
            consumed.update(range(s, e + 1))
        if org_words:
            signals.append(("organisation_keyword", w["organisation_keyword"],
                            f"organisation word(s) {', '.join(sorted(set(org_words))[:3])}"))

        # Person evidence --------------------------------------------------------
        titles = _find_phrases(tokens, lex.titles, lo, hi)
        if field_mode:
            title_hit = [t for t in titles if t[0] <= 1]
        else:
            title_hit = [t for t in titles if t[1] in (first - 1, first - 2)]
        if title_hit:
            s, e = title_hit[0]
            consumed.update(range(s, e + 1))
            signals.append(("title", w["title"], f"title '{' '.join(tokens[s:e + 1])}'"))
        markers = _find_phrases(tokens, lex.markers, lo, hi)
        if markers:
            s, e = markers[0]
            consumed.update(range(s, e + 1))
            signals.append(("relationship_marker", w["relationship_marker"],
                            f"relationship marker '{' '.join(tokens[s:e + 1])}'"))
        matched_words = [tokens[i] for i in match_tokens]
        if all(t in lex.known_names for t in matched_words):
            signals.append(("keyword_is_known_name", w["keyword_is_known_name"],
                            f"matched word(s) '{' '.join(matched_words)}' are known personal names"))
        others = [tokens[i] for i in range(lo, hi + 1)
                  if i not in match_tokens and i not in consumed and tokens[i] in lex.known_names]
        if others:
            weight = min(w["known_name_token_cap"], w["known_name_token"] * len(others))
            signals.append(("known_name_token", weight, f"known name token(s) {', '.join(others[:4])}"))

        # Shape evidence ---------------------------------------------------------
        region = [tokens[i] for i in range(lo, hi + 1)]
        if any(any(ch.isdigit() for ch in t) for t in region):
            signals.append(("digits", w["digits"], "contains digits"))
        if field_mode:
            core = [tokens[i] for i in range(len(tokens)) if i not in consumed]
            n = len(core)
            if n == 1:
                signals.append(("single_token", w["single_token"], "single-word value"))
            elif 2 <= n <= 4:
                signals.append(("name_shape", w["name_shape"], f"{n}-word name shape"))
            elif n >= 6:
                signals.append(("long_value", w["long_value"], f"{n} words (long for a personal name)"))
            initials = [t for i, t in enumerate(tokens) if len(t) == 1 and t.isalpha() and i not in consumed]
            if initials and n <= 5:
                signals.append(("initials", w["initials"], f"initial(s) {' '.join(initials[:3])}"))
        else:
            signals.append(("non_name_field", w["non_name_field"],
                            f"{ctx.logical_field} is not a party-name field; only ±{self.window} words considered"))

        for provider in self.extra_signal_providers:   # e.g. an NER model, if one is approved later
            signals.extend(provider(ctx, tokens))

        score = sum(weight for _, weight, _ in signals)
        p = 1.0 / (1.0 + math.exp(-score))
        has_org = any(name in ("organisation_suffix", "organisation_keyword") for name, _, _ in signals)
        if p >= self.threshold:
            label, matched, confidence = "INDIVIDUAL", True, p
        elif p < 0.5:
            label = "BUSINESS_ENTITY" if has_org else "NOT_INDIVIDUAL"
            matched, confidence = False, 1.0 - p
        else:   # leaning towards a person but below the exclusion threshold -> never excluded
            label, matched, confidence = "UNKNOWN", False, p
        evidence = "; ".join(f"{detail} ({weight:+.1f})" for name, weight, detail in signals if name != "bias")
        reason = (f"{label}: p(individual)={p:.2f} vs threshold {self.threshold:.2f} "
                  f"[{evidence or 'no evidence'}] mode={mode}")
        return ClassificationResult(
            self.name, label, matched, round(confidence, 4), reason, self._source(mode),
            {"p_individual": round(p, 4), "mode": mode,
             "signals": [{"signal": n, "weight": round(wt, 2), "detail": d} for n, wt, d in signals]})

    def _source(self, mode: str) -> str:
        return f"IndividualClassifier(lexicon={self.lexicon_label}; mode={mode})"

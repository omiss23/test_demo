"""Context classifier interface.

A classifier answers one question about a keyword occurrence (e.g. "is this
occurrence part of a person's name?") and always returns a
ClassificationResult with classification, confidence, reason and source.
Classifiers receive the logical field and value - never physical-column
semantics - so they work unchanged for every country schema.
"""
from __future__ import annotations

from ..models import ClassificationResult, MatchContext


class ContextClassifier:
    name = "ContextClassifier"

    def classify(self, ctx: MatchContext) -> ClassificationResult:  # pragma: no cover - interface
        raise NotImplementedError

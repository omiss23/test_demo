"""ToponymClassifier: is the occurrence part of an active Toponym (place name)?"""
from __future__ import annotations

from .intelligence_classifier import IntelligenceListClassifier


class ToponymClassifier(IntelligenceListClassifier):
    name = "ToponymClassifier"
    default_list = "Toponym"

"""SecularClassifier: is the occurrence part of an active Secular value (e.g. a brand)?"""
from __future__ import annotations

from .intelligence_classifier import IntelligenceListClassifier


class SecularClassifier(IntelligenceListClassifier):
    name = "SecularClassifier"
    default_list = "Secular"

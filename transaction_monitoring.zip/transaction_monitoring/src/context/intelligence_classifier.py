"""Generic intelligence-list classifier (Toponym, Secular, Religious, or any new list).

Question answered: "is the matched keyword occurrence part of an ACTIVE value
of list L in the same field value?"

All active values of the list are compiled into one automaton (same engine as
keyword candidate generation), so checking an occurrence is a single scan of
the value - cached per distinct value. The span policy decides what counts:

  CONTAINS   (default) an intelligence occurrence fully contains the keyword match.
             'ABC' in '12 ABC NAGAR, PUNE' is covered by toponym 'ABC NAGAR'
             -> excluded, while 'ABC TRADING, ABC NAGAR' still alerts on the first ABC.
  EXACT_SPAN the intelligence occurrence is exactly the matched text.
  OVERLAPS   any overlap (looser: more exclusions, higher false-negative risk).

Exclusions suppress alerts, so CONTAINS is the conservative default: a keyword
is only excluded when the whole occurrence is explained by the list value.
"""
from __future__ import annotations

from typing import List, Sequence, Tuple

from ..models import ClassificationResult, IntelligenceEntry, MatchContext
from ..utils import BoundedCache
from ..matching.candidate_generator import KIND_TOKEN, Probe, make_generator
from .base import ContextClassifier

Occurrence = Tuple[int, int, int]   # (entry index, start, end)


class IntelligenceListClassifier(ContextClassifier):
    name = "IntelligenceListClassifier"
    default_list = ""

    def __init__(self, entries: Sequence[IntelligenceEntry], list_key: str = "", list_display: str = "",
                 span_policy: str = "CONTAINS", backend: str = "auto", cache_size: int = 100_000,
                 mapping_version: str = ""):
        self.entries: List[IntelligenceEntry] = list(entries)
        self.list_key = list_key or self.default_list.upper()
        self.list_display = list_display or (self.entries[0].list_name if self.entries else self.list_key.title())
        self.span_policy = span_policy.upper()
        self.mapping_version = mapping_version
        probes = [Probe(e.normalized_value, KIND_TOKEN, i, 0) for i, e in enumerate(self.entries)]
        self.generator = make_generator(probes, backend)
        self._cache: BoundedCache = BoundedCache(cache_size)
        self.label = self.list_key.upper()

    def occurrences(self, normalized_value: str) -> List[Occurrence]:
        cached = self._cache.get(normalized_value)
        if cached is None:
            cached = [(ref, start, end) for _, ref, _, start, end in self.generator.scan(normalized_value)]
            self._cache.put(normalized_value, cached)
        return cached

    def _covers(self, occ_start: int, occ_end: int, start: int, end: int) -> bool:
        if self.span_policy == "EXACT_SPAN":
            return occ_start == start and occ_end == end
        if self.span_policy == "OVERLAPS":
            return occ_start < end and start < occ_end
        return occ_start <= start and end <= occ_end   # CONTAINS

    def classify(self, ctx: MatchContext) -> ClassificationResult:
        source = f"Intelligence_Lists[{self.list_display}] ({len(self.entries)} active values; {self.mapping_version})"
        occurrences = self.occurrences(ctx.normalized_value)
        covering = [o for o in occurrences if self._covers(o[1], o[2], ctx.start, ctx.end)]
        if covering:
            ref, start, end = max(covering, key=lambda o: (o[2] - o[1], -o[1]))
            entry = self.entries[ref]
            relation = {"CONTAINS": "contains", "EXACT_SPAN": "equals", "OVERLAPS": "overlaps"}[self.span_policy]
            reason = (f"Active {self.list_display} value '{entry.value}' (Intelligence_Lists row {entry.source_row}) "
                      f"{relation} the matched text '{ctx.matched_text}' in {ctx.physical_column}")
            return ClassificationResult(self.name, self.label, True, 1.0, reason, source,
                                        {"intelligence_list": self.list_display, "intelligence_value": entry.value,
                                         "intelligence_row": entry.source_row, "span": [start, end]})
        if occurrences:
            ref, start, end = occurrences[0]
            reason = (f"{self.list_display} value '{self.entries[ref].value}' occurs at [{start}:{end}] but does not "
                      f"{'contain' if self.span_policy == 'CONTAINS' else 'cover'} the match at "
                      f"[{ctx.start}:{ctx.end}]")
        else:
            reason = f"No active {self.list_display} value occurs in {ctx.physical_column}"
        return ClassificationResult(self.name, f"NOT_{self.label}", False, 1.0, reason, source, {})

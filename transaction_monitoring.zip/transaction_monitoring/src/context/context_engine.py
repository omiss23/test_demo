"""ContextEngine: owns the classifier instances and caches their results.

The same counterparty value ('JIHAD AHMED KHAN', '12 ABC NAGAR PUNE') appears
on many transactions; each (classifier, country, logical field, value, span)
is classified once and reused.
"""
from __future__ import annotations

from typing import Dict, Optional

from ..models import ClassificationResult, MatchContext
from ..normalization.text_normalizer import TextNormalizer
from ..rules.rule_registry import RuleDefinition, RuleRegistry
from ..settings import Settings
from ..utils import BoundedCache
from .base import ContextClassifier
from .individual_classifier import IndividualClassifier
from .intelligence_classifier import IntelligenceListClassifier
from .religious_classifier import ReligiousClassifier
from .secular_classifier import SecularClassifier
from .toponym_classifier import ToponymClassifier

_LIST_CLASSES = {
    "toponym": ToponymClassifier,
    "secular": SecularClassifier,
    "religious": ReligiousClassifier,
    "intelligence_list": IntelligenceListClassifier,
}


class ContextEngine:
    def __init__(self, classifiers: Dict[str, ContextClassifier], cache_size: int = 250_000):
        self.classifiers = classifiers
        self._cache: BoundedCache = BoundedCache(cache_size)
        self.evaluations = 0
        self.cache_hits = 0

    @classmethod
    def build(cls, registry: RuleRegistry, used_codes, intelligence: Dict[str, list],
              intelligence_display: Dict[str, str], settings: Settings, normalizer: TextNormalizer,
              mapping_version: str, individual: Optional[IndividualClassifier] = None) -> "ContextEngine":
        """Instantiate only the classifiers that ACTIVE P2 rules actually use."""
        classifiers: Dict[str, ContextClassifier] = {}
        for code in sorted(used_codes):
            definition: Optional[RuleDefinition] = registry.get(code)
            if definition is None or definition.classifier_key in classifiers:
                continue
            if definition.classifier == "individual":
                classifiers[definition.classifier_key] = individual or IndividualClassifier.from_file(
                    settings.resolve_path(settings.individual.lexicon), normalizer, settings.individual)
            else:
                entries = intelligence.get(definition.list_key, [])
                klass = _LIST_CLASSES[definition.classifier]
                classifiers[definition.classifier_key] = klass(
                    entries, definition.list_key, intelligence_display.get(definition.list_key, definition.list_key),
                    definition.span_policy, settings.matching.candidate_backend, mapping_version=mapping_version)
        return cls(classifiers, settings.matching.value_cache_size)

    def classify(self, classifier_key: str, ctx: MatchContext) -> ClassificationResult:
        key = (classifier_key, ctx.country, ctx.logical_field, ctx.normalized_value, ctx.start, ctx.end)
        cached = self._cache.get(key)
        if cached is not None:
            self.cache_hits += 1
            return cached
        result = self.classifiers[classifier_key].classify(ctx)
        self.evaluations += 1
        self._cache.put(key, result)
        return result

"""ReligiousClassifier: is the occurrence part of an active Religious value?"""
from __future__ import annotations

from .intelligence_classifier import IntelligenceListClassifier


class ReligiousClassifier(IntelligenceListClassifier):
    name = "ReligiousClassifier"
    default_list = "Religious"

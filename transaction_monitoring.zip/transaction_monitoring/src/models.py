"""Shared, immutable domain objects.

Everything that crosses a module boundary is defined here so that modules
depend on plain data rather than on each other.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Dict, NamedTuple, Optional, Tuple


# --------------------------------------------------------------------------- #
# Enumerations (plain string constants keep CSV output and YAML config simple)
# --------------------------------------------------------------------------- #
class MatchType:
    EXACT = "EXACT"          # whole normalised field equals the keyword
    TOKEN = "TOKEN"          # keyword appears on token boundaries (default)
    PHRASE = "PHRASE"        # keyword tokens in order, small gaps allowed
    FUZZY = "FUZZY"          # approximate token-window similarity (rapidfuzz)
    SUBSTRING = "SUBSTRING"  # raw containment, no boundaries (opt-in only)

    ALL = (EXACT, TOKEN, PHRASE, FUZZY, SUBSTRING)


class Decision:
    ALERT = "ALERT"
    EXCLUDED = "EXCLUDED"


class Severity:
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"

    ORDER = {INFO: 0, WARNING: 1, ERROR: 2, CRITICAL: 3}


class RuleStatus:
    TRIGGERED = "TRIGGERED"
    NOT_TRIGGERED = "NOT_TRIGGERED"
    ERROR = "ERROR"              # classifier raised; fail-safe = no exclusion
    UNKNOWN_RULE = "UNKNOWN_RULE"  # rule code not registered; fail-safe = no exclusion


# --------------------------------------------------------------------------- #
# Configuration objects
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class ScenarioRule:
    """One ACTIVE row of the P2 sheet, normalised once at start-up."""

    rule_id: str                       # e.g. P2-R2 (Excel row) or the optional Rule_ID column
    rt_type: str                       # display form, e.g. "Scenario 1"
    keyword: str                       # as typed in P2
    normalized_keyword: str
    logical_fields: Tuple[str, ...]    # from the "Message" column, e.g. ("BENEFICIARY", "ADDRESS")
    exclusion_rules: Tuple[str, ...]   # from the "Rules" column, e.g. ("EXCL_INDV",)
    match_type: str
    fuzzy_threshold: Optional[float]
    source_row: int                    # Excel row number in P2 (header = row 1)
    spec_id: int = -1                  # assigned by the keyword registry


@dataclass(frozen=True)
class IntelligenceEntry:
    """One ACTIVE row of the Intelligence_Lists sheet."""

    list_name: str          # canonical display form, e.g. "Toponym"
    value: str              # as typed
    normalized_value: str
    source_row: int


@dataclass(frozen=True)
class KeywordSpec:
    """A distinct (keyword, match type, parameters) combination to search for.

    Several P2 rules can share one spec (same keyword in two scenarios); the
    keyword is matched once and the hit is fanned out to every rule.
    """

    spec_id: int
    keyword: str            # normalised
    match_type: str
    threshold: Optional[float]
    max_gap: int
    tokens: Tuple[str, ...]


class Hit(NamedTuple):
    """A verified keyword occurrence inside one normalised value."""

    spec_id: int
    start: int        # character offsets in the normalised value
    end: int
    score: float      # 0-100 similarity of the matched text to the keyword
    variant: str      # "" or "COMPACT" (e.g. AL QAIDA found as ALQAIDA)


# --------------------------------------------------------------------------- #
# Validation issues (config, schema and data quality all use the same shape)
# --------------------------------------------------------------------------- #
@dataclass
class ValidationIssue:
    severity: str
    source: str           # P1 | P2 | Intelligence_Lists | schema | settings | input | ...
    code: str             # machine-readable, e.g. UNKNOWN_RULE_CODE
    detail: str
    row: Optional[int] = None
    field: str = ""
    value: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "SEVERITY": self.severity,
            "SOURCE": self.source,
            "ROW": "" if self.row is None else self.row,
            "FIELD": self.field,
            "ISSUE_CODE": self.code,
            "VALUE": self.value,
            "DETAIL": self.detail,
        }


# --------------------------------------------------------------------------- #
# Context classification
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class MatchContext:
    """Everything a context classifier may look at for one keyword occurrence.

    Classifiers never see physical-column semantics: they get the logical field,
    the physical column (for explanations only) and the value.
    """

    country: str
    rt_type: str
    keyword: str              # normalised keyword
    logical_field: str
    physical_column: str
    original_value: str
    normalized_value: str
    start: int
    end: int

    @property
    def matched_text(self) -> str:
        return self.normalized_value[self.start:self.end]


@dataclass(frozen=True)
class ClassificationResult:
    """Output of a context classifier (always with confidence, reason and source)."""

    classifier: str
    classification: str        # e.g. INDIVIDUAL, BUSINESS_ENTITY, UNKNOWN, TOPONYM, NOT_TOPONYM
    matched: bool              # does the condition the rule asks about hold?
    confidence: float          # 0..1 confidence in `classification`
    reason: str
    source: str
    evidence: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["confidence"] = round(float(self.confidence), 4)
        return d
